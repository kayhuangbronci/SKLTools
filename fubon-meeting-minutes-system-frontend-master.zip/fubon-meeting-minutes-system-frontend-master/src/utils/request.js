import axios from "axios";
import store from "@/store";
import router from "@/router";
import { Message } from "element-ui";
import { getToken } from "@/utils/auth";

// create an axios instance
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API, // url = base url + request url
});

// request interceptor
service.interceptors.request.use(
  (config) => {
    if (store.getters.token) {
      config.headers["Authorization"] = `Bearer ${getToken()}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

function message(message) {
  Message({
    message: message,
    type: "error",
    duration: 5 * 1000,
  });
}

// response interceptor
service.interceptors.response.use(
  (response) => {
    const res = response.data;

    const successCode = [200, 202]; // http success status code

    if (!successCode.includes(res.code)) {
      if (res.code === 42210) {
        message("帳號或密碼錯誤");
      } else if (res.code === 42211) {
        message("帳號已停用");
      } else if (res.code === 42212) {
        message("帳號已過期");
      } else if (res.code === 42213) {
        message("帳號已過期");
      } else {
        message(res.message || res.error || "Error");
      }

      return Promise.reject(new Error(res.error || res.message || "Error"));
    } else {
      return res;
    }
  },
  (error) => {
    if (error.response && error.response.status === 401) {
      store
        .dispatch("user/resetToken")
        .then(console.log)
        .catch(console.error)
        .finally(() => {
          router.push({ path: "/", params: { reload: true } });
        });

      return Promise.reject("登入資料過期");
    }

    if (!error.message) {
      Message({
        message: "登入過久或帳號有誤，請重新登入",
        type: "error",
        duration: 5 * 1000,
      });

      store
        .dispatch("user/resetToken")
        .then(console.log)
        .catch(console.error)
        .finally(() => {
          router.push({ path: "/", params: { reload: true } });
        });
    }

    return Promise.reject(error);
  }
);

export default service;
