import dayjs from "dayjs";

const formatDate = (time) => {
  return dayjs(time).format("YYYY/MM/DD HH:mm");
};

export default formatDate;
