const constants = {
  speakers: 10,
  taskExpiredNotificationDays: 3,
  version: "1.3.9",
  tokenName: "Fubon-token",
};

export default constants;
