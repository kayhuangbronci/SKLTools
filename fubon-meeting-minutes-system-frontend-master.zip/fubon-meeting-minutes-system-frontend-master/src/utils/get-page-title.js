const title = "富邦";

const getPageTitle = (pageTitle) => {
  if (pageTitle) {
    return `${title} - ${pageTitle}`;
  }
  return title;
};

export default getPageTitle;
