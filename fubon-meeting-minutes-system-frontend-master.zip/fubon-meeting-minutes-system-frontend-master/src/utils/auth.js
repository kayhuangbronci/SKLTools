import Cookies from "js-cookie";
import constants from "./constants";

const { tokenName } = constants;

export function getToken() {
  return Cookies.get(tokenName);
}

export function setToken(token, expires) {
  return Cookies.set(tokenName, token, { expires });
}

export function removeToken() {
  return Cookies.remove(tokenName);
}
