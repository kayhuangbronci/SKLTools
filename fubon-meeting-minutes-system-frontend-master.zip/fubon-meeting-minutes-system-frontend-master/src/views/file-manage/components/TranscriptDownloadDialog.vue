<template>
  <el-dialog
    title="逐字稿下載"
    width="500px"
    :visible.sync="dialogVisible"
    :before-close="handleClose"
    class="transcript-download-dialog"
  >
    <el-form>
      <el-form-item label="檔案格式">
        <el-select v-model="form.fileType">
          <el-option :value="1" label="txt"></el-option>
          <el-option :value="2" label="Word(.docx)"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="檔案樣式">
        <div class="file-type-block-group">
          <div class="file-type-block">
            <div class="file-type-inner-main-block">
              <label for="">
                <div class="file-type-inner-block">
                  <input type="radio" v-model="form.fileStyle" :value="1" />
                  <span class="label-title">語者分段逐字稿</span>
                </div>
              </label>

              <div class="file-type-inner-sub-block">
                <div>檔案項目(請勾選)</div>

                <div>
                  <label for="">
                    <input
                      type="radio"
                      v-model="form.category"
                      :value="1"
                      :disabled="form.fileStyle !== 1"
                    />
                    <span>語者</span>
                  </label>
                  <label for="">
                    <input
                      type="radio"
                      v-model="form.category"
                      :value="2"
                      :disabled="form.fileStyle !== 1"
                    />
                    <span>語者及時間</span>
                  </label>
                </div>
              </div>
            </div>

            <div class="image-block">
              <img
                src="../../../assets/download-transcription-image-1.png"
                alt="下載圖式"
              />
            </div>
          </div>

          <div class="file-type-block second">
            <div class="file-type-inner-main-block">
              <label for="">
                <div class="file-type-inner-block">
                  <input type="radio" v-model="form.fileStyle" :value="2" />
                  <span class="label-title">不分段逐字稿</span>
                </div>
              </label>
            </div>

            <div class="image-block">
              <img
                src="../../../assets/download-transcription-image-2.png"
                alt="下載圖式"
              />
            </div>
          </div>
        </div>
      </el-form-item>
    </el-form>

    <span slot="footer">
      <el-button @click="handleClose">取消</el-button>
      <el-button class="primary-button" @click="handleSubmit" :loading="loading"
        >確認</el-button
      >
    </span>
  </el-dialog>
</template>

<script>
import { downloadTaskTranscriptFile } from "@/api/file-manage";
import axios from "axios";

export default {
  name: "TranscriptDownloadDialog",
  props: {
    dialogVisible: {
      type: Boolean,
      required: true,
      default: false,
    },
    id: {
      type: Number,
      required: true,
    },
    fileName: {
      type: String,
      required: true,
    },
    showFeedbackDialog: {
      type: Boolean,
      required: true,
      default: false,
    },
  },
  data() {
    return {
      form: {
        fileType: 1, // 1 -> txt, 2 -> docx
        fileStyle: 1,
        category: 1,
      },
      loading: false,
    };
  },
  computed: {
    token() {
      return this.$store.getters.token;
    },
  },
  methods: {
    handleClose() {
      this.$emit("close");
    },
    async handleSubmit() {
      let targetType = null;

      // txt
      if (this.form.fileType === 1) {
        if (this.form.fileStyle === 1) {
          if (this.form.category === 1) {
            targetType = "dia.ntc.txt";
          } else {
            targetType = "dia.regular.txt";
          }
        } else {
          targetType = "dia.script.txt";
        }
        // docx
      } else {
        if (this.form.fileStyle === 1) {
          if (this.form.category === 1) {
            targetType = "dia.ntc.docx";
          } else {
            targetType = "dia.regular.docx";
          }
        } else {
          targetType = "dia.script.docx";
        }
      }

      this.loading = true;

      const { data } = await downloadTaskTranscriptFile(this.id, {
        targetType,
      });

      const { url } = data[0];
      await this.handleDownload(url);
      this.loading = false;

      if (this.showFeedbackDialog) {
        this.$emit("open-feedback-dialog");
      }
    },
    async handleDownload(url) {
      try {
        url = `${url}?token=${encodeURIComponent(this.token)}`;

        await axios({
          url,
          method: "get",
        });
        window.open(url, "__blank");
      } catch (error) {
        console.log(error);
      }

      this.loading = false;
    },
  },
};
</script>

<style lang="scss" scoped>
::v-deep.transcript-download-dialog {
  .el-dialog__body {
    padding-top: 10px;
  }

  .el-dialog__title {
    color: #000000;
    font-weight: 700;
  }
}

.file-type-block {
  display: flex;
  border: 1px solid #d7d7d9;
  border-radius: 8px;
  padding: 10px;
  width: 80%;
  gap: 20px;
  align-items: flex-start;

  .file-type-inner-main-block {
    width: 188px;
  }

  &.second {
    margin-left: 68px;
    margin-top: 12px;
  }

  .label-title {
    color: #579ec6;
    font-weight: bold;
  }

  input[type="radio"] {
    -webkit-appearance: none;
    appearance: none;
    margin: 0;
    border-radius: 3px;
    width: 20px;
    height: 20px;
    border: 1px solid black;
    position: relative;

    &::before {
      transition: all 0.3s;
      content: "";
      position: absolute;
      width: 14px;
      height: 14px;
      transform: translate(-50%, -50%);
      top: 50%;
      left: 50%;
      cursor: pointer;
    }

    &:disabled {
      border: 1px solid #d7d7d9;

      &:checked {
        &::before {
          background-color: #d7d7d9;
        }
      }
    }

    &:checked {
      &::before {
        background: black;
      }
    }
  }

  .file-type-inner-block {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 188px;
  }

  .file-type-inner-sub-block {
    padding-left: 28px;
    display: flex;
    flex-wrap: wrap;

    > :first-child {
      width: 100%;
    }

    > :last-child {
      label {
        display: flex;
        align-items: center;
        gap: 4px;
      }
    }
  }
}
</style>
