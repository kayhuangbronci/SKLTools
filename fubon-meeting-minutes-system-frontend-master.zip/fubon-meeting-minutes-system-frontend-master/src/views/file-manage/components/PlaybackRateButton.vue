<template>
  <div class="playback-rate-block">
    <div class="playback-rate-icon" />
    <select
      id="js-playback-rate"
      v-model="playbackRate"
      @change="handleChangePlaybackRate"
    >
      <option v-for="(rate, index) in playbackRates" :key="index" :value="rate">
        {{ rate }}x
      </option>
    </select>
  </div>
</template>

<script>
export default {
  name: "PlaybackRateButton",
  data() {
    return {
      playbackRate: 1,
      playbackRates: [0.5, 1, 1.25, 1.5, 2],
    };
  },
  methods: {
    handleChangePlaybackRate() {
      this.$emit("change", this.playbackRate);
    },
  },
};
</script>

<style lang="scss" scoped>
.playback-rate-block {
  font-size: 18px;
  color: var(--main-font-color);
  display: flex;
  align-items: center;

  .playback-rate-icon {
    width: 30px;
    height: 26px;
    background-image: url("../../../assets/playback-rate-btn.png");
  }

  #js-playback-rate {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    text-indent: 1px;
    border: none;
    background-color: inherit;
    outline: none;
    cursor: pointer;
    font-size: 14px;
    color: var(--main-font-color);
  }
}
</style>
