<template>
  <el-dialog
    class="speaker-dialog"
    title="語者編輯"
    width="600px"
    :visible.sync="dialogVisible"
    :before-close="handleClose"
  >
    <!-- Need to build with el-form for validation -->
    <el-form class="list-wrapper" :model="form" ref="formRef">
      <el-form-item
        v-for="({ id, speaker }, index) in form.speakerList"
        :key="id"
        :rules="[
          { required: true, message: '語者名稱不可為空', trigger: 'blur' },
          {
            validator: (rule, value, callback) =>
              handleValidateName(rule, value, callback, index),
            trigger: ['blur', 'change'],
          },
        ]"
        :prop="`speakerList[${index}].speaker`"
      >
        <div class="list-item">
          <span class="index">{{ `${index + 1}.` }}</span>
          <el-color-picker
            v-model="form.speakerList[index].color"
          ></el-color-picker>
          <el-input
            v-model="form.speakerList[index].speaker"
            maxlength="20"
            show-word-limit
          ></el-input>
          <el-button
            class="remove-button"
            @click="handleRemove(index)"
            icon="el-icon-error"
            type="text"
            :title="
              !!usedSpeakers.find((spk) => spk === speaker)
                ? '已使用中，無法刪除'
                : '刪除'
            "
            :disabled="!!usedSpeakers.find((spk) => spk === speaker)"
          ></el-button>
        </div>
      </el-form-item>
    </el-form>

    <span slot="footer" class="dialog-footer">
      <el-button class="add-speaker-button" @click="handleAdd"
        >新增語者</el-button
      >

      <div>
        <el-button @click="handleClose">取消</el-button>
        <el-button
          @click="handleSubmit"
          class="primary-button"
          :loading="loading"
          >儲存設定</el-button
        >
      </div>
    </span>
  </el-dialog>
</template>

<script>
import { DEFAULT_COLOR } from "../utils/speaker-colors";

export default {
  name: "EditSpeakerDialog",
  props: {
    dialogVisible: {
      type: Boolean,
      required: true,
      default: false,
    },
    speakers: {
      type: Array,
      required: true,
      default: () => [],
    },
    usedSpeakers: {
      type: Array,
      required: true,
      default: () => [],
    },
  },
  data() {
    const handleValidateName = (_rule, value, callback, index) => {
      if (value.length === 0) return callback();

      // 檢查是否名稱有重複
      const duplicate = this.form.speakerList.some(
        (speaker, i) => speaker.speaker === value && i !== index
      );

      duplicate ? callback(new Error("語者名稱不可重複")) : callback();
    };

    return {
      form: {
        speakerList: [],
      },
      handleValidateName,
      loading: false,
    };
  },
  computed: {
    taskId() {
      return this.$route.params.id;
    },
  },
  created() {
    this.form.speakerList = JSON.parse(JSON.stringify([...this.speakers]));
  },
  methods: {
    handleRemove(index) {
      if (this.form.speakerList.length === 1) {
        this.$message({
          message: "至少要有一名語者",
          type: "warning",
          duration: 1000,
        });
        return;
      }

      this.form.speakerList.splice(index, 1);
    },
    handleAdd() {
      const max = Math.max(...this.form.speakerList.map(({ id }) => id));
      const formSpeakerLength = this.form.speakerList.length;

      this.form.speakerList.push({
        id: max + 1,
        speaker: "",
        color:
          formSpeakerLength > DEFAULT_COLOR.length - 2
            ? "#000000"
            : DEFAULT_COLOR[formSpeakerLength],
      });
    },
    handleClose() {
      this.$emit("close");
    },
    handleSubmit() {
      this.$refs.formRef.validate((valid) => {
        if (valid) {
          this.loading = true;

          const speakers = [];
          if (this.form.speakerList.length >= this.speakers.length) {
            this.form.speakerList.forEach(({ speaker, id, color }) => {
              const s = this.speakers.find((item) => item.id === id);

              if (s) {
                // 若 speaker 或 color 有變更，則 push
                if (s.speaker !== speaker || s.color !== color) {
                  speakers.push({
                    id,
                    speaker,
                    color,
                  });
                }
              } else {
                // 若找不到該 speaker 表示是新增的，直接 push
                speakers.push({
                  id,
                  speaker,
                  color,
                });
              }
            });
          } else {
            // 代表有刪除語者
            this.speakers.forEach(({ id, speaker, color }) => {
              const s = this.form.speakerList.find((item) => item.id === id);

              // 若找不到該 speaker 表示是刪除的，直接 push
              if (!s) {
                speakers.push({
                  id,
                  speaker,
                  color,
                  remove: true,
                });
              } else {
                if (s.speaker !== speaker || s.color !== color) {
                  speakers.push({
                    id,
                    speaker: s.speaker,
                    color: s.color,
                  });
                }
              }
            });
          }

          if (speakers.length === 0) {
            this.$message({
              type: "success",
              message: "儲存成功",
              duration: 1000,
            });
            this.$emit("close");
            return;
          }

          this.$emit("store", {
            speakers,
            callback: () => (this.loading = false),
          });
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
::v-deep.speaker-dialog {
  .el-dialog__title {
    color: #000000;
    font-weight: 700;
  }

  .el-color-picker {
    display: flex;
    justify-content: center;
    align-items: center;

    .el-color-picker__trigger {
      border: none;
      width: 42px;
      height: 28px;
      border-radius: 4px;

      .el-color-picker__color {
        border: none;
      }

      .el-color-picker__icon {
        display: none;
      }
    }
  }

  .el-form-item__error {
    left: 80px;
  }
}

.speaker-dialog {
  .list-wrapper {
    height: 480px;
    overflow-y: auto;
    position: relative;

    &::-webkit-scrollbar {
      display: none;
      width: 0px;
    }

    /* Track */
    &::-webkit-scrollbar-track {
      background: #f1f1f1;
    }

    /* Handle */
    &::-webkit-scrollbar-thumb {
      background: #888;
    }

    /* Handle on hover */
    &::-webkit-scrollbar-thumb:hover {
      background: #555;
    }

    .list-item {
      display: flex;
      align-items: center;
      flex-wrap: nowrap;
      gap: 8px;

      .index {
        font-weight: 800;
        min-width: 20px;
        width: 30px;
      }

      .remove-button {
        color: #606266;
        font-size: 20px;
      }
    }
  }

  .dialog-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .add-speaker-button {
    color: var(--main-color-green);
  }
}
</style>
