<template>
  <el-dialog
    class="feedback-dialog"
    title="使用者回饋"
    :visible.sync="dialogVisible"
    width="480px"
    :before-close="handleClose"
  >
    <div class="content">
      <p>
        感謝您的使用，如果想要幫助我們更加完善此網站，請點選下方連結填寫問卷給予我們寶貴建議。
      </p>
      <a href="https://survey.fubon.com/s/AMOvR" target="_blank"
        >點此前往填寫問卷</a
      >
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose" class="primary-button">確認</el-button>
    </span>
  </el-dialog>
</template>

<script>
export default {
  name: "FeedbackDialog",
  props: {
    dialogVisible: {
      type: Boolean,
      required: true,
      default: false,
    },
  },
  methods: {
    handleClose() {
      this.$emit("close", false);
    },
  },
};
</script>

<style lang="scss" scoped>
::v-deep.feedback-dialog {
  .content {
    p {
      line-height: 24px;
    }

    a {
      margin-top: 10px;
      display: inline-block;
      color: #3e8ab5;
      position: relative;
      padding-bottom: 6px;
      transition: all 0.3s;
      font-weight: bold;

      &::before {
        content: "";
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        border-bottom: 1px solid #3e8ab5;
      }

      &:hover {
        color: #60acd7;

        &::before {
          border-bottom: 1px solid #60acd7;
        }
      }
    }
  }

  .el-dialog__body {
    padding-top: 10px;
    padding-bottom: 10px;
  }

  .el-dialog__title {
    color: #000000;
    font-weight: 700;
  }
}
</style>
