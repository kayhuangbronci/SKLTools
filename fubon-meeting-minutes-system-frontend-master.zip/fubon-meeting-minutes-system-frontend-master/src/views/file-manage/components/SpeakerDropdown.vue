<template>
  <div
    class="speaker-dropdown"
    :style="{ top: top + 'px', left: left - paddingLeft + 'px' }"
  >
    <ul>
      <slot></slot>
    </ul>
  </div>
</template>

<script>
export default {
  name: "SpeakerDropdown",
  props: {
    top: {
      type: Number,
      required: true,
      default: 0,
    },
    left: {
      type: Number,
      required: true,
      default: 0,
    },
  },
  data() {
    return {
      paddingLeft: 4,
    };
  },
};
</script>

<style lang="scss" scoped>
.speaker-dropdown {
  position: absolute;
  background-color: #ffffff;
  border: 1px solid #afc5e8;
  border-radius: 5px;

  li {
    padding: 4px 8px;
    cursor: pointer;
    transition: backgroundColor 0.3s;

    &:hover {
      background-color: #cccccc;
    }

    .label {
      display: inline-block;
      width: 18px;
      height: 18px;
      text-align: center;
      line-height: 18px;
      color: white;
      border-radius: 50%;
    }
  }
}
</style>
