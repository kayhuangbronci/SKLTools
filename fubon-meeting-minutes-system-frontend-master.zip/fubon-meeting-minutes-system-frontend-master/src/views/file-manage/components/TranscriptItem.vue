<template>
  <div
    class="content"
    :class="[
      activeId === source.id && 'active',
      source.id === firstId && 'first',
    ]"
  >
    <div
      v-if="source.id === firstId && showAddDeleteColumn"
      class="first-add-block"
      @click="handleAdd(-1)"
    >
      +
    </div>
    <div class="speaker-block flex-center">
      <button
        class="select-button"
        @click.stop="handleChangeSpeaker(source.id, $event)"
      >
        <span
          :style="{
            backgroundColor: currentSpeaker?.color || '#000000',
          }"
          class="icon"
          >{{ currentSpeaker?.id || "" }}</span
        >
        <span class="name" :title="currentSpeaker?.speaker">{{
          currentSpeaker?.speaker || ""
        }}</span>
      </button>
    </div>

    <div class="time-wrapper">
      <div
        class="time"
        :class="[source.timeError && 'error']"
        contenteditable="true"
        :data-id="`${source.id}-st`"
        v-text="source.st"
        @input="handleTimeInput(source.id, $event, 'st')"
      ></div>
      <div
        class="time"
        :class="[source.timeError && 'error']"
        contenteditable="true"
        :data-id="`${source.id}-et`"
        v-text="source.et"
        @input="handleTimeInput(source.id, $event, 'et')"
      ></div>
    </div>

    <div class="play-audio">
      <button class="play-button" @click="handlePlay(source.st, source.et)">
        <i class="el-icon-video-play"></i>
      </button>
    </div>
    <div
      :class="['transcript', source.text.length === 0 && 'error']"
      contenteditable="true"
      :data-id="`${source.id}-transcript`"
      @keydown="handleTranscriptKeydown(index, $event)"
      @blur="handleTranscriptBlur(source.id, $event)"
    >
      <span>{{ source.text }}</span>
    </div>
    <div v-show="showAddDeleteColumn" class="button-group">
      <button
        type="text"
        class="add-button"
        icon="el-icon-plus"
        @click="handleAdd(index)"
        :disabled="source.timeError"
      >
        <i class="el-icon-plus"></i>
      </button>
      <button type="text" class="delete-button" @click="handleDelete(index)">
        <i class="el-icon-error"></i>
      </button>
    </div>

    <speaker-dropdown
      v-if="showDropdown && currentId === source.id"
      ref="speakerDropdownRef"
      :top="dropdownPosition.top"
      :left="dropdownPosition.left"
    >
      <li
        v-for="({ color, speaker, id }, index) in speakers"
        :key="index"
        class="speaker-list"
        @click="handleConfirmSpeaker(id)"
      >
        <span class="label" :style="{ backgroundColor: color || '#000000' }">{{
          id
        }}</span>
        {{ speaker }}
      </li>
    </speaker-dropdown>
  </div>
</template>

<script>
import SpeakerDropdown from "./SpeakerDropdown.vue";

export default {
  name: "TranscriptItem",
  components: {
    SpeakerDropdown,
  },
  props: {
    index: {
      type: Number,
    },
    source: {
      type: Object,
      default() {
        return {};
      },
    },
    speakers: {
      type: Array,
    },
    activeId: {
      type: String,
    },
    showAddDeleteColumn: {
      type: Boolean,
      default: false,
    },
    showDropdown: {
      type: Boolean,
      default: false,
    },
    dropdownPosition: {
      type: Object,
    },
    handleChangeSpeaker: {
      type: Function,
    },
    handleConfirmSpeaker: {
      type: Function,
    },
    handleTimeInput: {
      type: Function,
    },
    handlePlay: {
      type: Function,
    },
    handleTranscriptKeydown: {
      type: Function,
    },
    handleTranscriptBlur: {
      type: Function,
    },
    handleAdd: {
      type: Function,
    },
    handleDelete: {
      type: Function,
    },
    firstId: {
      type: String,
    },
    lastId: {
      type: String,
    },
    currentId: {
      type: String,
    },
  },
  computed: {
    currentSpeaker() {
      return this.speakers.find(
        ({ speaker }) => speaker === this.source.speaker
      );
    },
  },
};
</script>

<style lang="scss" scoped>
.content {
  display: flex;
  gap: 12px;
  margin: 8px;

  &.active {
    background-color: #ebf5f5;

    .transcript {
      color: #58aaac;
    }
  }

  &.first {
    padding-top: 10px;
  }

  .first-add-block {
    position: absolute;
    top: -4px;
    left: 0;
    width: 100%;
    height: 14px;
    background-color: #517399;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 8px;
    padding-top: 1px;
    line-height: 14px;
    color: #ffffff;

    &:hover {
      opacity: 0.6;
    }
  }

  .speaker-block {
    padding: 8px;
    width: 120px;

    &.flex-center {
      justify-content: flex-start;
    }

    .select-button {
      outline: none;
      background-color: inherit;
      border: none;
      gap: 4px;
      cursor: pointer;
      display: flex;
      align-items: center;

      .icon {
        display: block;
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background-color: #3f8cbf;
        line-height: 18px;
        color: #ffffff;
      }

      .name {
        display: block;
        line-height: 18px;
        font-size: 14px;
        height: 18px;
        color: var(--main-font-color);
        width: 76px;
        text-align: left;
        padding-top: 1px;
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
      }
    }
  }

  .time-wrapper {
    display: flex;
    gap: 8px;

    .time {
      font-size: 14px;
      line-height: 16px;
      padding: 4px 8px;
      color: #7a7a7a;
      user-select: text;
      width: 90px;
      margin-top: auto;
      margin-bottom: auto;
      display: flex;
      flex-wrap: nowrap;
      overflow: hidden;
      border-radius: 5px;

      &:focus {
        outline: 1px solid var(--main-color-green);
      }

      &.error {
        outline: 1px solid #f56c6c;
      }
    }
  }

  .play-audio {
    width: 42px;
    padding: 8px;
    display: flex;
    align-items: center;

    .play-button {
      display: flex;
      align-items: center;
      border: none;
      background-color: inherit;
      font-size: 18px;
      color: var(--main-color-green);
      cursor: pointer;
      transition: all 0.3s;
      opacity: 0;

      &:hover {
        opacity: 0.6;
      }
    }
  }

  &:hover {
    .play-button {
      opacity: 1;
    }
  }

  .transcript {
    width: 700px;
    padding: 8px;
    display: table-cell;
    white-space: pre-wrap;
    user-select: text;
    color: #3f3f3f;
    font-size: 14px;
    line-height: 20px;
    max-height: 100px;
    overflow-y: auto;

    &.error {
      border-radius: 5px;
      outline: 1px solid #b32518 !important;
    }

    &::-webkit-scrollbar {
      display: none;
      width: 0px;
    }

    /* Track */
    &::-webkit-scrollbar-track {
      background: #f1f1f1;
    }

    /* Handle */
    &::-webkit-scrollbar-thumb {
      background: #888;
    }

    /* Handle on hover */
    &::-webkit-scrollbar-thumb:hover {
      background: #555;
    }

    ::v-deep .highlight {
      background-color: #f6fe7e;
    }

    &:focus {
      border-radius: 5px;
      outline: 1px solid var(--main-color-green);
    }
  }

  .button-group {
    width: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    padding: 8px;

    button {
      padding: 0;
      font-size: 16px;
      width: 20px;
      height: 20px;
      border: none;
      background-color: inherit;
      cursor: pointer;
    }

    .add-button {
      color: var(--main-color-green);

      &:disabled {
        color: #b3b3b3;
        cursor: not-allowed;
      }
    }

    .delete-button {
      color: #b32518;

      &:disabled {
        color: #b3b3b3;
        cursor: not-allowed;
      }
    }
  }

  .speaker-list {
    font-size: 14px;
  }
}
</style>
