<template>
  <div class="search-form-block">
    <div class="title">
      <span>搜尋條件</span>
    </div>

    <el-form class="form" label-position="left">
      <el-row :gutter="20">
        <el-col :span="10">
          <el-form-item label-width="60px">
            <template #label>
              <span class="label">時間</span>
            </template>
            <div class="time-block">
              <el-date-picker
                :value="search.start"
                type="date"
                placeholder="請選擇"
                @input="handleSearchChange($event, 'start')"
              />
              <span class="separator">至</span>
              <el-date-picker
                :value="search.end"
                type="date"
                placeholder="請選擇"
                @input="handleSearchChange($event, 'end')"
              />
            </div>
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <div class="button-group">
            <el-button
              type="text"
              class="time-button"
              @click="handleTimeChange('clear')"
              >清除</el-button
            >
            <el-button
              type="text"
              class="time-button"
              @click="handleTimeChange('today')"
              >今日</el-button
            >
            <el-button
              type="text"
              class="time-button"
              @click="handleTimeChange('month')"
              >30天內</el-button
            >
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="13">
          <el-form-item label-width="60px">
            <template #label>
              <span class="label">標題</span>
            </template>
            <el-input
              :value="search.title"
              @input="handleSearchChange($event, 'title')"
            />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label-width="60px">
            <template #label>
              <span class="label">狀態</span>
            </template>
            <el-select
              v-if="taskStatus.length"
              :value="search.taskStatus"
              style="width: 100%"
              @change="handleSearchChange($event, 'taskStatus')"
            >
              <el-option
                v-for="{ value, label } in taskStatus"
                :key="label"
                :value="value"
                :label="label"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="3">
          <el-button
            type="info"
            icon="el-icon-search"
            :disabled="loading"
            @click="handleSearch"
            >查詢</el-button
          >
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { getTaskStatus } from "@/api/file-manage";
import dayjs from "dayjs";

export default {
  name: "SearchForm",
  props: {
    search: {
      type: Object,
      default: () => ({}),
      required: true,
    },
    loading: {
      type: Boolean,
      default: false,
      required: true,
    },
  },
  data() {
    return {
      taskStatus: [],
      visibility: {
        questionDialog: false,
      },
    };
  },
  created() {
    this.handleGetTaskStatus();
  },
  methods: {
    async handleGetTaskStatus() {
      const { data } = await getTaskStatus();
      const { status } = data[0];

      Object.keys(status).forEach((key) => {
        if (key === "ongoing" || key === "ended") return;

        if (key === "standby") {
          this.taskStatus.push({
            label: "等待處理逐字稿",
            value: key,
          });
          return;
        }

        if (key === "processing") {
          this.taskStatus.push({
            label: "逐字稿處理中",
            value: key,
          });
          return;
        }

        this.taskStatus.push({
          label: status[key],
          value: key,
        });
      });
    },
    handleSearchChange(value, type) {
      if (type === "end") {
        value = dayjs(value)
          .set("hours", 23)
          .set("minute", 59)
          .set("second", 59)
          .toDate();
      }

      this.$emit("update", { type, value });
    },
    handleTimeChange(mode) {
      switch (mode) {
        case "clear":
          this.$emit("update", { type: ["start", "end"], value: ["", ""] });
          break;
        case "today": {
          const start = dayjs()
            .set("hours", 0)
            .set("minute", 0)
            .set("second", 0)
            .toDate();
          const end = dayjs()
            .set("hours", 23)
            .set("minute", 59)
            .set("second", 59)
            .toDate();
          this.$emit("update", { type: ["start", "end"], value: [start, end] });
          break;
        }
        case "month": {
          const end = dayjs()
            .set("hours", 23)
            .set("minute", 59)
            .set("second", 59)
            .toDate();
          const start = dayjs()
            .subtract(1, "month")
            .set("hours", 0)
            .set("minute", 0)
            .set("second", 0)
            .toDate();
          this.$emit("update", { type: ["start", "end"], value: [start, end] });
          break;
        }
        default:
          break;
      }
    },
    handleSearch() {
      this.$emit("search");
    },
  },
};
</script>

<style lang="scss" scoped>
.search-form-block {
  margin-bottom: 16px;

  .title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 14px;
    color: var(--main-font-color);
    margin-bottom: 16px;
  }

  .form {
    background-color: var(--main-color-gray);
    padding: 20px;
  }

  .label {
    color: var(--main-font-color);
    font-weight: bold;
  }

  .time-block {
    display: flex;
    align-items: center;
    gap: 12px;

    .separator {
      font-weight: normal;
    }
  }

  .button-group {
    button {
      position: relative;
      color: #959697;
      margin-right: 12px;
      font-weight: 400;

      &::before {
        content: "";
        position: absolute;
        top: 50%;
        right: -12px;
        transform: translateY(-50%);
        width: 1px;
        height: 12px;
        background-color: var(--main-font-color);
      }

      &:last-child::before {
        display: none;
      }
    }
  }
}
</style>
