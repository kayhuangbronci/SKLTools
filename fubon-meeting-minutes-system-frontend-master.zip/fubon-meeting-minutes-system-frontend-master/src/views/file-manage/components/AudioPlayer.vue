<template>
  <div class="audio-block">
    <input
      v-model="progress"
      type="range"
      min="0"
      max="100"
      class="progress-bar"
      :style="{ backgroundSize: `${progress}% 100%` }"
      @input="handleProgressChange"
      @change="handleProgressChange"
    />
    <div class="time-block">
      <div class="current-time">{{ formatCurrentTime }}</div>
      <div class="duration">{{ formatDuration }}</div>
    </div>

    <div class="controller">
      <playback-rate-button
        @change="handleChangePlaybackRate"
      ></playback-rate-button>

      <div class="play-pause-button-group">
        <button
          class="audio-button prev"
          @mousedown="handleButtonStyle('down', $event)"
          @mouseup="handleButtonStyle('up', $event)"
          @click="handleChangeTime(-audioStepTime)"
        ></button>
        <button
          class="audio-button play"
          :class="[status === 'pause' && 'is-paused']"
          @mousedown="handleButtonStyle('down', $event)"
          @mouseup="handleButtonStyle('up', $event)"
          @click="handlePlay"
        ></button>
        <button
          class="audio-button next"
          @mousedown="handleButtonStyle('down', $event)"
          @mouseup="handleButtonStyle('up', $event)"
          @click="handleChangeTime(audioStepTime)"
        ></button>
      </div>

      <!-- this div is for style purpose -->
      <div></div>
    </div>

    <audio
      ref="audioRef"
      :src="audioUrl"
      style="display: none"
      controls
      crossorigin="anonymous"
    ></audio>
  </div>
</template>

<script>
import PlaybackRateButton from "./PlaybackRateButton.vue";

const AUDIO_STEP_TIME = 5;

export default {
  name: "AudioPlayer",
  components: {
    PlaybackRateButton,
  },
  props: {
    currentAudioTime: {
      type: Number,
      required: true,
      default: 0,
    },
    stopAudioTime: {
      type: Number,
      required: true,
      default: 0,
    },
    audioUrl: {
      type: String,
      required: true,
      default: "",
    },
  },
  data() {
    return {
      progress: 0,
      currentTime: 0,
      duration: 0,
      status: "pause",
      audioStepTime: AUDIO_STEP_TIME,
    };
  },
  computed: {
    formatCurrentTime() {
      const secs = parseInt((this.currentTime % 60).toString(), 10)
        .toString()
        .padStart(2, "0");
      const mins = parseInt(((this.currentTime / 60) % 60).toString(), 10)
        .toString()
        .padStart(2, "0");
      const hours = parseInt((this.currentTime / 3600).toString(), 10)
        .toString()
        .padStart(2, "0");

      return `${hours}:${mins}:${secs}`;
    },
    formatDuration() {
      const secs = parseInt((this.duration % 60).toString(), 10)
        .toString()
        .padStart(2, "0");
      const mins = parseInt(((this.duration / 60) % 60).toString(), 10)
        .toString()
        .padStart(2, "0");
      const hours = parseInt((this.duration / 3600).toString(), 10)
        .toString()
        .padStart(2, "0");

      return `${hours}:${mins}:${secs}`;
    },
  },
  watch: {
    currentAudioTime(newVal) {
      if (newVal === -1) return;

      this.$refs.audioRef.currentTime = newVal;

      if (this.$refs.audioRef.paused) {
        this.$refs.audioRef.play();
        this.status = "play";
      }
    },
  },
  mounted() {
    this.$refs.audioRef.addEventListener(
      "loadedmetadata",
      this.handleLoadMetaData
    );
    this.$refs.audioRef.addEventListener("timeupdate", this.handleTimeUpdate);
  },
  beforeDestroy() {
    this.$refs.audioRef.removeEventListener(
      "loadedmetadata",
      this.handleLoadMetaData
    );
    this.$refs.audioRef.removeEventListener(
      "timeupdate",
      this.handleTimeUpdate
    );
  },
  methods: {
    handleLoadMetaData() {
      if (this.$refs.audioRef) {
        this.duration = this.$refs.audioRef.duration;
        this.currentTime = this.$refs.audioRef.currentTime;
      }
    },
    handleTimeUpdate(e) {
      const target = e.target;
      this.progress = (target.currentTime / target.duration) * 100;
      this.currentTime = target.currentTime;

      this.$emit("timeupdate", this.currentTime);

      // 播放到最後停止
      if (this.$refs.audioRef.paused && this.currentTime === this.duration) {
        this.status = "pause";
      }
    },
    handleProgressChange(e) {
      this.progress = Number(e.target.value);
      this.$refs.audioRef.currentTime =
        (this.$refs.audioRef.duration / 100) * this.progress;

      if (this.$refs.audioRef.paused) {
        this.$refs.audioRef.play();
        this.status = "play";
      }
    },
    handlePlay() {
      if (this.$refs.audioRef.paused) {
        this.$refs.audioRef.play();
        this.status = "play";
      } else {
        this.$refs.audioRef.pause();
        this.status = "pause";
      }

      this.$emit("changeStopTime");
    },
    handleButtonStyle(direction, event) {
      const audioButton = event.target;

      if (!audioButton.classList.contains("audio-button")) return;

      if (direction === "down") {
        audioButton.style.transform = "scale(0.9)";
      } else {
        audioButton.style.transform = "scale(1)";
      }
    },
    handleChangeTime(time) {
      this.currentTime += time;

      if (this.currentTime < 0) {
        this.currentTime = 0;
      } else if (this.currentTime > this.duration) {
        this.currentTime = this.duration;
      }

      this.$refs.audioRef.currentTime = this.currentTime;
    },
    handleChangePlaybackRate(value) {
      this.$refs.audioRef.playbackRate = value;
    },
  },
};
</script>

<style lang="scss" scoped>
.audio-block {
  height: 120px;
  padding: 8px 12px;
  border-radius: 4px;
  background-color: #ebf5f5;

  .progress-bar {
    -webkit-appearance: none;
    appearance: none;
    width: 100%;
    height: 6px;
    background-color: #cacccc;
    border-radius: 5px;
    background-image: linear-gradient(
      to right,
      var(--main-color-green) 0%,
      var(--main-color-green) 100%
    );
    background-size: 0 100%;
    background-repeat: no-repeat;
    margin-bottom: 8px;
    cursor: pointer;

    &::-webkit-slider-thumb {
      -webkit-appearance: none;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: transparent;
      cursor: pointer;
    }

    &::-webkit-slider-runnable-track {
      -webkit-appearance: none;
      box-shadow: none;
      border: none;
      background: transparent;
      cursor: pointer;
    }
  }

  .time-block {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 14px;
    color: var(--main-font-color);
  }

  .controller {
    display: flex;
    align-items: center;
    justify-content: space-between;

    .play-pause-button-group {
      display: flex;
      align-items: flex-end;
      justify-content: space-between;
      gap: 8px;

      .audio-button {
        background-color: inherit;
        border: none;
        cursor: pointer;
        background-size: contain;

        &.play {
          width: 60px;
          height: 60px;
          background-image: url("../../../assets/pause-btn.png");

          &.is-paused {
            background-image: url("../../../assets/play-btn.png");
          }
        }

        &.prev {
          width: 30px;
          height: 26px;
          background-image: url("../../../assets/prev-five-second-btn.png");
          margin-bottom: 8px;
        }

        &.next {
          width: 30px;
          height: 26px;
          background-image: url("../../../assets/next-five-second-btn.png");
          margin-bottom: 8px;
        }
      }
    }
  }
}
</style>
