<template>
  <div class="result-table-block">
    <div class="pagination-block">
      <el-pagination
        background
        :page-size="pageSize"
        layout="prev,slot,next,jumper"
        :total="total"
        :current-page="page + 1"
        @prev-click="handleChangePage"
        @next-click="handleChangePage"
        @current-change="handleChangePage"
        :disabled="loading"
      >
        <div class="pagination-button">{{ page + 1 }}</div>
      </el-pagination>
    </div>

    <div class="total">檔案總數量: {{ total }}</div>
    <div class="expired-time-info" v-if="!systemLoading">
      檔案系統僅留存{{
        taskPreservedDay
      }}日(含假日)，刪除3日前以「<BiExclamationTriangleFill
      ></BiExclamationTriangleFill>」提醒；超過時間將自動刪除
    </div>
    <div v-else style="height: 16px; margin-bottom: 16px"></div>

    <el-table
      ref="tableRef"
      :data="data"
      v-loading="loading"
      element-loading-text="載入中..."
    >
      <el-table-column width="60">
        <template #default="{ row }">
          <div class="icon-group">
            <div title="檔案已快過期" class="flex-center">
              <BiExclamationTriangleFill
                v-if="
                  row.taskExpiredTime &&
                  handleCheckExpiredTime(row.taskExpiredTime)
                "
              ></BiExclamationTriangleFill>
            </div>
            <div
              class="circle-icon"
              v-if="
                row.subtitleStatus !== 'edited' &&
                row.subtitleStatus !== 'cached' &&
                row.status === 3
              "
              title="尚未編輯逐字稿"
            ></div>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="標題" prop="title">
        <template #header>
          <div class="flex-center">標題</div>
        </template>
        <template #default="{ row }">
          <el-popover placement="right" trigger="hover" width="240">
            <ul class="popover-content">
              <li>
                <div class="title">標題</div>
                <div class="detail">{{ row.title }}</div>
              </li>
              <li>
                <div class="title">描述</div>
                <div class="detail">{{ row.description || "-" }}</div>
              </li>
              <li>
                <div class="title">最後編輯時間</div>
                <div class="detail">
                  {{
                    !row.lastEditTime
                      ? "尚未處理"
                      : $formatDate(row.lastEditTime)
                  }}
                </div>
              </li>
              <li>
                <div class="title">檔案保留時間</div>
                <div class="detail">
                  {{
                    row.taskExpiredTime === null
                      ? "無期限"
                      : $formatDate(row.taskExpiredTime)
                  }}
                </div>
              </li>
              <li>
                <div class="title">處理時間</div>
                <div class="detail">
                  {{ handleFormatProcessTime(row.processTime) }}
                </div>
              </li>
            </ul>
            <div
              slot="reference"
              class="text-overflow text-center"
              style="color: var(--main-color-green)"
            >
              {{ row.title }}
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column label="狀態" width="158">
        <template #header>
          <div class="flex-center">狀態</div>
        </template>
        <template #default="{ row }">
          <div class="flex-center" style="flex-direction: column">
            <div
              :class="
                row.status === 0 ||
                row.status === 3 ||
                row.status === 11 ||
                row.status === 13
                  ? ''
                  : row.status === 4 || row.status === 5
                  ? 'color-fail'
                  : row.status === 12
                  ? 'color-pending'
                  : 'color-progress'
              "
            >
              {{ handleStatus(row.status) }}
            </div>
            <div class="progressbar-wrapper" v-if="row.status === 13">
              <el-progress
                :percentage="row.progress"
                :color="handleProgressColor"
              />
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="創建時間" prop="createTime">
        <template #header>
          <div class="flex-center">創建時間</div>
        </template>
        <template #default="{ row }">
          <div class="flex-center">
            {{ $formatDate(row.createTime) }}
          </div>
        </template>
      </el-table-column>
      <el-table-column label="語音長度">
        <template #header>
          <div class="flex-center">語音長度</div>
        </template>
        <template #default="{ row }">
          <div class="flex-center">
            {{ handleFormatAudioTime(row.audioLength) }}
          </div>
        </template>
      </el-table-column>
      <el-table-column label="逐字稿下載">
        <template #header>
          <div class="flex-center">逐字稿下載</div>
        </template>
        <template #default="{ row }">
          <div class="flex-center">
            <button
              :disabled="row.status !== 3"
              class="download-button"
              @click="handleClickDownloadButton(row)"
            ></button>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="逐字稿編輯">
        <template #header>
          <div class="flex-center">逐字稿編輯</div>
        </template>
        <template #default="{ row }">
          <div class="flex-center">
            <button
              class="edit-button"
              :disabled="row.status !== 3"
              @click="handleEdit(row.id)"
            ></button>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="刪除/取消" width="100">
        <template #header>
          <div class="flex-center">刪除/取消</div>
        </template>
        <template #default="{ row }">
          <div class="flex-center">
            <button
              class="delete-button"
              @click="handleDisableOrDelete(row)"
            ></button>
          </div>
        </template>
      </el-table-column>
    </el-table>

    <transcript-download-dialog
      v-if="visibility.transcriptDownloadDialog && currentData"
      :id="currentData.id"
      :file-name="currentData.title"
      :dialog-visible="visibility.transcriptDownloadDialog"
      :show-feedback-dialog="false"
      @close="
        () => {
          currentData = null;
          visibility.transcriptDownloadDialog = false;
        }
      "
    ></transcript-download-dialog>
  </div>
</template>

<script>
import TranscriptDownloadDialog from "./TranscriptDownloadDialog.vue";
import handleFormatAudioTime from "../utils/format-audio-time";
import BiExclamationTriangleFill from "@/components/Icon/BiExclamationTriangleFill.vue";
import { getTaskResourceWithSpeakerInfo } from "@/api/file-manage";
import dayjs from "dayjs";
import { getSystemSetting } from "@/api/system";
import constants from "@/utils/constants";

export default {
  name: "ResultTable",
  components: {
    TranscriptDownloadDialog,
    BiExclamationTriangleFill,
  },
  props: {
    data: {
      type: Array,
      default: () => [],
      required: true,
    },
    total: {
      type: Number,
      default: 0,
      required: true,
    },
    page: {
      type: Number,
      default: 1,
      required: true,
    },
    pageSize: {
      type: Number,
      default: 20,
      required: true,
    },
    loading: {
      type: Boolean,
      default: false,
      required: true,
    },
  },
  watch: {
    loading(val) {
      if (val) this.$refs.tableRef.bodyWrapper.scrollTop = 0;
    },
  },
  data() {
    return {
      visibility: {
        transcriptDownloadDialog: false,
      },
      currentData: null,
      taskPreservedDay: "",
      systemLoading: true,
    };
  },
  created() {
    this.handleGetSystemSetting();
  },
  methods: {
    async handleGetSystemSetting() {
      const { data } = await getSystemSetting();
      if (data) {
        this.taskPreservedDay = data[0].taskPreservedDay;
      }

      this.systemLoading = false;
    },
    handleFormatAudioTime,
    handleFormatProcessTime(duration) {
      let result = "";
      const hours = Math.floor(duration / 3600);
      if (hours > 0) {
        result += `${hours}時`;
      }
      duration %= 3600;
      const minutes = Math.floor(duration / 60);
      if (minutes > 0) {
        result += `${minutes}分`;
      }
      const seconds = duration % 60;
      result += `${seconds}秒`;

      return result;
    },
    handleStatus(status) {
      let word = "";
      switch (status) {
        case 0:
          word = "等待確認檔案";
          break;
        case 3:
          word = "成功";
          break;
        case 4:
          word = "失敗";
          break;
        case 5:
          word = "已取消";
          break;
        case 11:
          word = "等待處理逐字稿";
          break;
        case 12:
          word = "檔案下載中";
          break;
        case 13:
          word = "逐字稿處理中";
          break;
        default:
          word = "未定義狀態";
          break;
      }
      return word;
    },
    handleProgressColor() {
      return "#919398";
    },
    handleChangePage(page) {
      this.$emit("change-page", page);
    },
    handleDisableOrDelete({ status, id }) {
      if (status === 3 || status === 4 || status === 5) {
        this.$emit("delete-task", { id });
      } else {
        this.$emit("disable-task", { id });
      }
    },
    handleCheckExpiredTime(taskExpiredTimeStr) {
      return !dayjs(taskExpiredTimeStr)
        .subtract(constants.taskExpiredNotificationDays, "day")
        .isAfter(dayjs());
    },
    async handleEdit(id) {
      const { extra: speakerInfo } = await getTaskResourceWithSpeakerInfo(id, {
        editor: 1,
        category: "dia",
      });

      if (!speakerInfo) {
        this.$message({
          type: "error",
          message: "該檔案無法編輯，未產出語者 dia 檔，請聯繫管理員",
          duration: 3000,
        });
        return;
      }

      this.$router.push({ name: "TranscriptEdit", params: { id } });
    },
    handleClickDownloadButton(row) {
      this.currentData = row;
      this.visibility.transcriptDownloadDialog = true;
    },
  },
};
</script>

<style lang="scss" scoped>
.result-table-block {
  margin-bottom: 32px;

  .pagination-block {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 16px;
  }

  .pagination-button {
    display: inline-block;
    text-align: center;
    min-width: 30px;
    color: #ffffff;
    margin: 0 5px;
    border-radius: 2px;
    background-color: var(--main-color-green);
    font-size: 13px;
    height: 28px;
    line-height: 28px;
    vertical-align: top;
  }

  .total {
    color: #585858;
    font-size: 14px;
    margin-bottom: 4px;
  }

  .expired-time-info {
    font-size: 14px;
    color: #585858;
    margin-bottom: 16px;
  }

  .color-success {
    color: var(--main-color-green);
  }

  .color-pending {
    color: #f6ca6c;
  }

  .color-progress {
    color: #3f8cbf;
  }

  .color-fail {
    color: #c7707f;
  }

  .color-info {
    color: #909399;
  }

  .progressbar-wrapper {
    width: 120px;
    margin-left: 46px;
  }

  .download-button {
    width: 16px;
    height: 16px;
    background-image: url("../../../assets/download-icon.png");
    background-size: 100%;
    background-repeat: no-repeat;
    background-position: center;
    background-color: inherit;
    border: none;
    cursor: pointer;

    &:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
  }

  .edit-button {
    width: 16px;
    height: 16px;
    background-image: url("../../../assets/edit-icon.png");
    background-size: 100%;
    background-repeat: no-repeat;
    background-position: center;
    background-color: inherit;
    border: none;
    cursor: pointer;

    &:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
  }

  .delete-button {
    width: 16px;
    height: 16px;
    background-image: url("../../../assets/delete-icon.png");
    background-size: 100%;
    background-repeat: no-repeat;
    background-position: center;
    background-color: inherit;
    border: none;
    cursor: pointer;
  }

  ::v-deep .el-table__header {
    tr {
      th {
        background-color: var(--main-color-green);
        color: #ffffff;
      }
    }
  }

  ::v-deep .el-table__cell {
    padding: 20px 0;
  }

  ::v-deep .el-progress__text {
    font-size: 12px !important;
  }
  ::v-deep .el-progress-bar__outer {
    height: 4px !important;
  }

  .icon-group {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 4px;
    width: 100%;

    .circle-icon {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: var(--main-color-green);
    }
  }
}

::v-deep.popover-content {
  li {
    margin-bottom: 8px;
  }

  .title {
    color: #4e4f51;
    padding-bottom: 4px;
  }

  .detail {
    color: #c3c4c6;
  }
}
</style>
