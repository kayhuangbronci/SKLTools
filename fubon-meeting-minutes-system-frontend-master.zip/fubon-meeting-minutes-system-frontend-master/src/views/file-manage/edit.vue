<template>
  <div class="transcript-edit-block">
    <div class="container">
      <breadcrumb>
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ name: 'FileManage' }"
            >檔案管理</el-breadcrumb-item
          >
          <el-breadcrumb-item>逐字稿編輯</el-breadcrumb-item>
        </el-breadcrumb>

        <template #right>
          <el-button
            type="text"
            class="el-icon-question question-button"
            @click="visibility.questionDialog = true"
          />
        </template>
      </breadcrumb>

      <div class="title-block">
        <div class="title text-overflow">標題：{{ title }}</div>

        <div>
          <el-button
            v-if="dataError"
            class="danger-button"
            @click="handleScrollToErrorItem"
            >發現錯誤</el-button
          >
          <el-button
            class="secondary-button"
            :disabled="dataError || loading"
            :loading="loading"
            @click="
              handleStoreResourceWithSpeaker({
                category: 'dia',
                type: 'edited',
              })
            "
            >儲存編輯</el-button
          >
          <el-button
            class="primary-button"
            :disabled="dataError || loading"
            @click="handleOpenDownloadDialog"
            >逐字稿下載</el-button
          >
        </div>
      </div>

      <div class="info-block">
        <el-row>
          <el-col :span="2">
            <div class="info-title">創建時間</div>
          </el-col>
          <el-col :span="22">
            <div class="info">{{ $formatDate(createdTime) }}</div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="2">
            <div class="info-title">語音長度</div>
          </el-col>
          <el-col :span="22">
            <div class="info">{{ handleFormatAudioTime(duration) }}</div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="2">
            <div class="info-title">參與者</div>
          </el-col>
          <el-col :span="22">
            <div class="info-group">
              <el-button
                type="info"
                size="mini"
                style="align-self: flex-start"
                :disabled="dataError || loading"
                @click="!dataError && (visibility.editSpeakerDialog = true)"
                >語者編輯</el-button
              >
              <ul class="info-list">
                <li
                  v-for="{ color: backgroundColor, speaker, id } in speakers"
                  :key="speaker"
                  class="item"
                >
                  <span
                    class="icon"
                    :style="{
                      backgroundColor,
                    }"
                    >{{ id }}</span
                  >
                  <span class="name">{{ speaker }}</span>
                </li>
              </ul>
            </div>
          </el-col>
        </el-row>
      </div>

      <div
        class="transcript-block"
        v-loading="loading"
        element-loading-text="載入中..."
      >
        <div class="transcript-title-block">
          <div class="title">逐字稿</div>

          <div class="control">
            <el-input
              v-model="search"
              placeholder="關鍵字搜尋"
              @input="handleSearchDebounce"
              @keyup.native.enter="handleSearch"
            />
            <el-button
              type="info"
              @click="showAddDeleteColumn = !showAddDeleteColumn"
              >新增刪除</el-button
            >
          </div>
        </div>

        <div class="editor" ref="scrollerRef">
          <VirtualList
            ref="virtualListRef"
            :data-key="'id'"
            :data-sources="data"
            :data-component="itemComponent"
            :keep="200"
            :extra-props="{
              speakers,
              activeId,
              showAddDeleteColumn,
              showDropdown,
              handleChangeSpeaker,
              handleTimeInput,
              handlePlay,
              handleTranscriptKeydown,
              handleTranscriptBlur,
              handleAdd,
              handleDelete,
              dropdownPosition,
              handleConfirmSpeaker,
              firstId,
              lastId,
              currentId,
            }"
            class="scroller"
            @scroll="handleVirtualListScroll"
          >
          </VirtualList>

          <audio-player
            :audio-url="audioUrl"
            :current-audio-time="updatedTime"
            :stop-audio-time="updatedEndTime"
            @timeupdate="handleTimeUpdate"
            @changeStopTime="updatedEndTime = -1"
          ></audio-player>
        </div>
      </div>
    </div>

    <edit-speaker-dialog
      v-if="visibility.editSpeakerDialog"
      :dialog-visible="visibility.editSpeakerDialog"
      :speakers="speakers"
      :used-speakers="usedSpeakers"
      @close="handleCloseDialog"
      @store="handleStoreSpeaker"
    ></edit-speaker-dialog>

    <transcript-download-dialog
      v-if="visibility.transcriptDownloadDialog"
      :id="taskId"
      :file-name="title"
      :dialog-visible="visibility.transcriptDownloadDialog"
      :show-feedback-dialog="true"
      @close="
        () => {
          visibility.transcriptDownloadDialog = false;
        }
      "
      @open-feedback-dialog="
        () => {
          visibility.transcriptDownloadDialog = false;
          visibility.feedbackDialog = true;
        }
      "
    ></transcript-download-dialog>

    <feedback-dialog
      v-if="visibility.feedbackDialog"
      :dialog-visible="visibility.feedbackDialog"
      @close="visibility.feedbackDialog = $event"
    ></feedback-dialog>

    <question-dialog
      v-if="visibility.questionDialog"
      title="新增刪除句子"
      width="520px"
      :dialog-visible="visibility.questionDialog"
      @close="handleCloseDialog"
    >
      <template #content>
        <ul class="question-dialog-content">
          <li class="detail">
            <span class="circle"></span>
            <span class="title">儲存編輯：</span
            >需點擊「儲存編輯」鍵儲存編輯後內容，系統將不進行自動儲存作業
          </li>
          <li class="detail">
            <span class="circle"></span>
            <span class="title">語者編輯：</span
            >系統最多辨識10位語者，超過10位語者時需以人工方式進行語者編輯，可新增之語者人數無上限
          </li>
          <li class="detail">
            <span class="circle"></span>
            <span class="title">錯誤字回報：</span
            >系統辨識文字如需建議修正，請至「使用者回饋＞錯誤字回報」提交回饋，我們將斟酌參考您留下的回饋進行模型修正
          </li>
        </ul>
      </template>
    </question-dialog>
  </div>
</template>

<script>
import {
  AudioPlayer,
  EditSpeakerDialog,
  TranscriptItem,
  TranscriptDownloadDialog,
  FeedbackDialog,
} from "./components";
import {
  getTaskResource,
  getTaskResourceWithSpeakerInfo,
  updateTaskResourceWithSpeakerInfo,
  getTask,
} from "@/api/file-manage";
import VirtualList from "vue-virtual-scroll-list";
import debounce from "lodash.debounce";
import handleFormatAudioTime from "./utils/format-audio-time";
import { v4 as uuidv4 } from "uuid";
import { DEFAULT_COLOR } from "./utils/speaker-colors";

const STORE_CACHE_TIMER = 15000;

export default {
  name: "TranscriptEdit",
  components: {
    AudioPlayer,
    EditSpeakerDialog,
    TranscriptDownloadDialog,
    FeedbackDialog,
    VirtualList,
  },
  data() {
    return {
      itemComponent: TranscriptItem,
      title: "",
      createdTime: new Date(),
      duration: 0,
      data: [],
      speakers: [],
      showDropdown: false,
      dropdownPosition: {
        top: 0,
        left: 0,
      },
      currentId: "",
      updatedTime: -1,
      updatedEndTime: -1,
      currentAudioTime: 0,
      search: "",
      showAddDeleteColumn: false,
      visibility: {
        editSpeakerDialog: false,
        questionDialog: false,
        transcriptDownloadDialog: false,
        feedbackDialog: false,
      },
      audioUrl: "",
      loading: true,
    };
  },
  computed: {
    firstId() {
      return this.data[0]?.id || "";
    },
    lastId() {
      return this.data.at(-1)?.id || "";
    },
    taskId() {
      return +this.$route.params.id;
    },
    activeId() {
      const index = this.data.findIndex(({ st }) => {
        const time = this.handleFormatTime(st);
        return time >= this.currentAudioTime;
      });

      if (index === -1 && this.data.length > 0) {
        const lastData = this.data.at(-1);
        const lastStartTime = this.handleFormatTime(lastData.st);

        if (this.currentAudioTime >= lastStartTime) {
          return lastData.id;
        }
      }

      if (index !== -1) {
        return this.data[index - 1]?.id || null;
      }

      return null;
    },
    dataError() {
      return this.data.some(
        ({ timeError, text }) => timeError || text.length === 0
      );
    },
    token() {
      return this.$store.getters.token;
    },
    usedSpeakers() {
      return [...new Set(this.data.map(({ speaker }) => speaker))];
    },
  },
  watch: {
    activeId() {
      this.$nextTick(() => {
        if (!this.handleStopAutoScroll()) return;

        const activeElement = this.$refs.scrollerRef.querySelector(".active");
        if (activeElement) {
          activeElement.scrollIntoView({
            behavior: "smooth",
            block: "center",
          });
        } else {
          const index = this.data.findIndex(({ id }) => id === this.activeId);

          if (index !== -1) {
            this.$refs.virtualListRef?.scrollToIndex(index);
          }
        }
      });
    },
  },
  async created() {
    await this.handleGetResourceWithSpeaker();

    await this.handleGatTask();
    await this.handleGetAudioResource();
    this.loading = false;

    this.handleCronjobCacheStore();

    document.addEventListener("click", this.handleClick);
  },
  beforeDestroy() {
    document.removeEventListener("click", this.handleClick);
  },
  methods: {
    handleFormatAudioTime,
    async handleGatTask() {
      if (!this.taskId) return;

      const { data } = await getTask(this.taskId);
      const { title, createTime, audioLength } = data[0];

      this.title = title;
      this.createdTime = createTime;
      this.duration = audioLength;
    },
    async handleGetResourceWithSpeaker() {
      if (!this.taskId) return;

      // extra -> speakerInfo
      const { data, extra: speakerInfo } = await getTaskResourceWithSpeakerInfo(
        this.taskId,
        {
          editor: 1,
          category: "dia",
        }
      );

      if (!speakerInfo) {
        this.$message({
          type: "error",
          message: "該檔案無法編輯，未產出語者 dia 檔，請聯繫管理員",
          duration: 3000,
        });
        this.$router.push({ name: "FileManage" });

        return;
      }

      // assign speaker info
      this.speakers = speakerInfo.map((item, index) => {
        if (item.color) {
          return item;
        } else if (DEFAULT_COLOR[index]) {
          return {
            ...item,
            color: DEFAULT_COLOR[index],
          };
        }

        return {
          ...item,
          color: "#000000",
        };
      });

      this.data = data.map((item) => {
        const st = item.startTime?.split(".")[0].trim();
        const et = item.endTime?.split(".")[0].trim();

        const { startTime, endTime, text, speaker } = item;

        return {
          speaker,
          st,
          et,
          timeError: false,
          id: uuidv4(),
          startTime,
          endTime,
          text,
        };
      });
    },
    handleCronjobCacheStore() {
      const timer = setInterval(async () => {
        await this.handleStoreResourceWithSpeaker({
          category: "dia",
          type: "cached",
        });
      }, STORE_CACHE_TIMER);

      this.$once("hook:beforeDestroy", () => {
        clearInterval(timer);
      });
    },
    async handleGetAudioResource() {
      if (!this.taskId) return;

      const { data } = await getTaskResource(this.taskId, {
        need_subtitle_content: 0, // 不需要 subtitle 相關的資訊
      });
      this.audioUrl = `${data[0].audioUrl}?token=${this.token}`;
    },
    async handleStoreResourceWithSpeaker({
      category = "dia",
      type = "edited",
    }) {
      if (
        !this.taskId ||
        this.dataError ||
        this.data.length === 0 ||
        this.speakers.length === 0 ||
        this.handleCheckSpeakersNameDuplicate()
      )
        return;

      const data = {
        category,
        type,
        subtitle: this.data.map(
          ({ speaker, st, text, endTime, startTime, et }, index) => ({
            id: index,
            speaker,
            startTime:
              startTime?.split(".")[0] === st ? startTime : `${st}.000`, // 確認是否有修改過，如果有修改過就用修改過的st且加上.000毫秒
            endTime: endTime?.split(".")[0] === et ? endTime : `${et}.000`, // 確認是否有修改過，如果有修改過就用修改過的st且加上.000毫秒
            text,
          })
        ),
        speakers: this.speakers,
      };

      this.loading = type === "edited";
      const { code } = await updateTaskResourceWithSpeakerInfo(
        this.taskId,
        data
      );
      this.loading = false;

      if (type === "edited") {
        if (code === 200) {
          this.$message({
            message: "儲存成功",
            type: "success",
            duration: 1000,
          });
        } else {
          this.$message({
            message: "儲存失敗",
            type: "error",
            duration: 3000,
          });
        }
      }
    },
    handleCheckSpeakersNameDuplicate() {
      const speakersName = this.speakers.map(({ speaker }) => speaker);
      const speakersNameSet = new Set(speakersName);

      return speakersName.length !== speakersNameSet.size;
    },
    async handleOpenDownloadDialog() {
      await this.handleStoreResourceWithSpeaker({
        category: "dia",
        type: "edited",
      });
      this.visibility.transcriptDownloadDialog = true;
    },
    handleClick(e) {
      // hide dropdown when click outside
      const target = e.target;
      if (
        target &&
        target.closest(".select-button") === null &&
        this.showDropdown
      ) {
        this.showDropdown = false;
      }
    },
    handleTimeInput(id, e, type = "st") {
      const index = this.handleFindDataIndex(id);
      if (index === -1) return;

      const dom = document.querySelector(`[data-id="${id}-${type}"]`);
      const text = dom.innerText;

      // 長度須為8(HH:MM:SS)，若不是8則為錯誤
      if (text.length !== 8) {
        this.handleUpdateTimeError(index);
        return;
      }

      // change time error according text time format is not a number
      const checkTimeErrorFormat = isNaN(this.handleFormatTime(text));
      if (checkTimeErrorFormat) {
        this.handleUpdateTimeError(index);
        return;
      }

      if (type === "st") {
        const prevEndTime = this.data[index - 1]?.et;
        if (
          prevEndTime &&
          this.handleFormatTime(prevEndTime) > this.handleFormatTime(text)
        ) {
          this.handleUpdateTimeError(index);
          return;
        }

        const nextStartTime = this.data[index + 1]?.st;
        if (
          nextStartTime &&
          this.handleFormatTime(nextStartTime) < this.handleFormatTime(text)
        ) {
          this.handleUpdateTimeError(index);
          return;
        }
      } else {
        const currentStartTime = this.data[index]?.st;
        if (
          currentStartTime &&
          this.handleFormatTime(currentStartTime) >= this.handleFormatTime(text)
        ) {
          this.handleUpdateTimeError(index);
          return;
        }

        const nextStartTime = this.data[index + 1]?.st;
        if (
          nextStartTime &&
          this.handleFormatTime(nextStartTime) < this.handleFormatTime(text)
        ) {
          this.handleUpdateTimeError(index);
          return;
        }
      }

      const range = document.getSelection().getRangeAt(0);
      const end = range.endOffset;

      if (e.inputType !== "insertCompositionText") {
        this.data[index][type] = text;
      }

      this.$nextTick(() => {
        const newRange = document.createRange();
        const selection = document.getSelection();
        const node = e.target.childNodes[0];

        if (!node) {
          this.handleUpdateTimeError(index);
          return;
        }

        newRange.setStart(node, node && end > node.length ? 0 : end);
        newRange.collapse(true);
        selection.removeAllRanges();
        selection.addRange(newRange);

        this.handleUpdateTimeError(index, false);
      });
    },
    handleUpdateTimeError(index, timeError = true) {
      this.data.splice(index, 1, {
        ...this.data[index],
        timeError,
      });
    },
    handleTranscriptBlur(id, e) {
      const index = this.handleFindDataIndex(id);

      if (index === -1) return;

      const target = e.target;
      const parent = target.closest(".transcript");
      const text = parent.textContent;

      const result = this.handleHighlight(text);

      parent.innerHTML = `<span>${result}</span>`;
      this.data[index].text = text || "";
    },
    handleTranscriptKeydown(index, e) {
      if (e.key === "Enter" && !e.target.textContent) {
        e.preventDefault();
        this.handleDelete(index);
      }
    },
    async handleStoreSpeaker({ speakers, callback }) {
      speakers.forEach((s) => {
        const { id, speaker, color, remove } = s;
        const index = this.speakers.findIndex((item) => item.id === id);

        if (index !== -1) {
          if (remove) {
            this.speakers.splice(index, 1);
          } else {
            // update subtitle speaker to new speaker
            if (this.speakers[index].speaker !== speaker) {
              this.data.forEach((item) => {
                if (item.speaker === this.speakers[index].speaker) {
                  item.speaker = speaker;
                }
              });
            }

            // update speaker info
            this.speakers[index] = { id, speaker, color };
          }
        } else {
          // if can't find speaker in original speaker list, add new speaker
          this.speakers.push({
            id,
            speaker,
            color,
          });
        }
      });

      await this.handleStoreResourceWithSpeaker({
        category: "dia",
        type: "edited",
      });
      this.handleCloseDialog();
      callback();
    },
    handleChangeSpeaker(id, e) {
      const target = e.target;
      if (target) {
        const button = target.closest(".select-button");

        const { top, left, height } = button.getBoundingClientRect();

        // scroll position
        const scrollPosition = this.$refs.virtualListRef.getOffset();

        // total scroll size
        const total = this.$refs.virtualListRef.getScrollSize();

        // wrapper position
        const { top: parentTop, left: parentLeft } =
          this.$refs.scrollerRef.getBoundingClientRect();

        const t = top + height + scrollPosition - parentTop;

        const speakerDropdownHeight = 26 * this.speakers.length;

        this.dropdownPosition.top =
          t + speakerDropdownHeight >= total
            ? t - speakerDropdownHeight - height
            : t;
        this.dropdownPosition.left = left - parentLeft;

        this.currentId = id;

        this.showDropdown = true;
      }
    },
    handleConfirmSpeaker(speakerId) {
      const idx = this.handleFindDataIndex(this.currentId);

      if (idx === -1) return;

      const { speaker } = this.speakers.find(({ id }) => id === speakerId);

      // 修改該筆資料的 speaker
      this.data[idx].speaker = speaker;
      this.showDropdown = false;
    },
    handleFindDataIndex(id) {
      return this.data.findIndex(({ id: dataId }) => dataId === id);
    },
    handleTimeUpdate(time) {
      this.currentAudioTime = time;
    },
    handleFormatTime(timeStr) {
      const [hour, min, sec] = timeStr.split(":");
      return Number(hour) * 3600 + Number(min) * 60 + Number(sec);
    },
    handlePlay(startTime, endTime) {
      this.updatedTime = this.handleFormatTime(startTime);
      this.updatedEndTime = this.handleFormatTime(endTime);
      // switch to -1 to reset updatedTime
      const timeout = setTimeout(() => {
        this.updatedTime = -1;
        clearTimeout(timeout);
      }, 400);
    },
    handleSearchDebounce: debounce(function () {
      this.handleSearch();
    }, 200),
    handleSearch() {
      this.data.forEach(({ text, id }) => {
        const result = this.handleHighlight(text);
        const dom = document.querySelector(`[data-id="${id}-transcript"]`);

        if (dom) dom.innerHTML = result;
      });
    },
    handleHighlight(str) {
      if (this.search.length === 0) return str;

      if (str.includes(this.search)) {
        const regex = new RegExp(this.search, "g");
        return str.replace(
          regex,
          `<span class="highlight">${this.search}</span>`
        );
      }

      return str;
    },
    handleStopAutoScroll() {
      const dialogVisible = Object.values(this.visibility).some(
        (v) => v === true
      );

      if (this.showDropdown || dialogVisible) return false;

      const c = document.activeElement?.classList;
      if (c) {
        const editTranscript = c.contains("transcript");
        const editTime = c.contains("time");

        if (editTranscript || editTime) return false;
      }

      return true;
    },
    handleDelete(index) {
      this.$confirm("確定刪除此行逐字稿？", "警告", {
        confirmButtonText: "確定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          if (this.data.length === 1) {
            this.$message({
              type: "error",
              message: "至少要有一筆逐字稿",
              duration: 3000,
            });

            return;
          }

          this.data.splice(index, 1);

          this.$message({
            type: "success",
            message: "刪除成功!",
            duration: 1000,
          });
        })
        .catch(() => {
          this.$message({
            type: "error",
            message: "已取消刪除",
            duration: 3000,
          });
        });
    },
    handleCloseDialog() {
      Object.keys(this.visibility).forEach((key) => {
        this.visibility[key] = false;
      });
    },
    handleAdd(index) {
      // -1 為新增在第一筆的特殊情況
      if (index === -1) {
        const firstData = this.data[0];

        if (firstData.timeError) {
          this.$message({
            type: "error",
            message: "新增失敗，第一筆資料是否沒有錯誤",
            duration: 3000,
          });

          return;
        }

        const startTime = this.handleFormatTime(firstData.st);

        if (startTime === 0) {
          this.$message({
            type: "error",
            message: "新增失敗，請確認第一筆資料起始時間不等於00:00:00",
            duration: 3000,
          });

          return;
        }

        this.data.splice(0, 0, {
          id: uuidv4(),
          text: "",
          speaker: this.data[0].speaker,
          st: "",
          startTime: "",
          et: this.data[0].st,
          endTime: this.data[0].startTime,
          timeError: true,
        });

        return;
      }

      const currentData = this.data[index];
      const nextData = this.data[index + 1];

      // meaning currentData is last item
      if (!nextData) {
        if (this.duration <= this.handleFormatTime(currentData.et)) {
          this.$message({
            type: "error",
            message: "新增失敗，請確認時間是否超過影片長度",
            duration: 3000,
          });

          return;
        }
      }

      this.data.splice(index + 1, 0, {
        id: uuidv4(),
        text: "",
        speaker: this.data[0].speaker,
        st: currentData.et,
        startTime: currentData.endTime,
        et: nextData ? nextData.st : "",
        endTime: nextData ? nextData.startTime : "",
        timeError: nextData ? false : true,
      });
    },
    handleScrollToErrorItem() {
      if (!this.dataError) return;

      const index = this.data.findIndex(
        ({ timeError, text }) => timeError || text.length === 0
      );

      if (index !== -1) {
        const { id } = this.data[index];
        const target = document.querySelector(`[data-id="${id}-st"]`);

        if (target) {
          target.scrollIntoView({ behavior: "smooth", block: "center" });
        } else {
          this.$refs.virtualListRef?.scrollToIndex(index);
        }
      }
    },
    handleVirtualListScroll() {
      if (this.search.length === 0) return;

      this.handleSearchDebounce();
    },
  },
};
</script>

<style lang="scss" scoped>
.transcript-edit-block {
  .title-block {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;

    .title {
      font-weight: bold;
      font-size: 20px;
      width: 300px;
    }
  }

  .info-block {
    padding: 20px;
    background-color: var(--main-color-gray);
    color: var(--main-font-color);
    margin-bottom: 16px;

    .el-row {
      margin-bottom: 10px;
    }

    .info-title {
      font-weight: bold;
      font-size: 16px;
      line-height: 28px;
      height: 28px;
    }

    .info {
      font-size: 14px;
      line-height: 28px;
    }

    .info-group {
      display: flex;
      align-items: center;
    }

    .info-list {
      margin-left: 12px;
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 14px;
      flex-wrap: wrap;

      .item {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .icon {
        color: #ffffff;
        border-radius: 50%;
        display: block;
        background-color: red;
        width: 18px;
        height: 18px;
        text-align: center;
        line-height: 18px;
      }
    }
  }

  .transcript-block {
    .transcript-title-block {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 2px solid #f2f2f2;
      padding-bottom: 12px;

      .control {
        display: flex;
        align-items: center;
        gap: 8px;
      }
    }

    .editor {
      .scroller {
        height: 800px;
        overflow-y: auto;
        position: relative;

        &::-webkit-scrollbar {
          display: none;
          width: 0px;
        }

        /* Track */
        &::-webkit-scrollbar-track {
          background: #f1f1f1;
        }

        /* Handle */
        &::-webkit-scrollbar-thumb {
          background: #888;
        }

        /* Handle on hover */
        &::-webkit-scrollbar-thumb:hover {
          background: #555;
        }
      }
    }
  }

  .question-dialog-content {
    color: #000000;

    .detail {
      font-size: 16px;
      margin-bottom: 4px;
      line-height: 1.6;

      .circle {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background-color: #000000;
        display: inline-block;
        margin-right: 8px;
        margin-bottom: 2px;
      }

      .title {
        font-weight: bold;
      }
    }
  }
}
</style>
