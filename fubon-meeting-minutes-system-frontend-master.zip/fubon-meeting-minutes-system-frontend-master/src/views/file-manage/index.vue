<template>
  <div class="file-manage-block">
    <div class="container">
      <search-form
        :search="search"
        :loading="loading"
        @update="handleUpdateSearch"
        @search="handleSearch"
      />

      <result-table
        :data="data"
        :page="search.pageIndex"
        :page-size="search.pageSize"
        :total="total"
        :loading="loading"
        @change-page="handleChangePage"
        @delete-task="handleDeleteTask"
        @disable-task="handleDisableTask"
      />
    </div>
  </div>
</template>

<script>
import { SearchForm, ResultTable } from "./components";
import {
  deleteTask,
  getTasks,
  getTasksTotal,
  disableTaskProcess,
} from "@/api/file-manage";

const TASK_INTERVAL = 10000;

export default {
  name: "FileManage",
  components: {
    SearchForm,
    ResultTable,
  },
  data() {
    return {
      search: {
        pageIndex: 0,
        pageSize: 20,
        taskStatus: "all",
        start: "",
        end: "",
        title: "",
      },
      data: [],
      total: 0,
      loading: true,
    };
  },
  computed: {
    progress() {
      return this.$store.getters.progress;
    },
  },
  watch: {
    progress: {
      handler: async function () {
        await this.handleGetTasks();
        await this.handleGetTasksTotal();
      },
    },
  },
  async created() {
    await this.handleReloadTasks();

    this.handleCronjobGetTasks();
  },
  methods: {
    async handleGetTasks() {
      const { data } = await getTasks(this.search);
      this.data = data;
    },
    async handleGetTasksTotal() {
      const { data } = await getTasksTotal(this.search);
      this.total = data[0].total;
    },
    handleCronjobGetTasks() {
      const timer = setInterval(async () => {
        await this.handleGetTasks();
        await this.handleGetTasksTotal();
      }, TASK_INTERVAL);

      this.$once("hook:beforeDestroy", () => {
        clearInterval(timer);
      });
    },
    async handleReloadTasks() {
      this.loading = true;
      await this.handleGetTasks();
      await this.handleGetTasksTotal();
      this.loading = false;
    },
    handleUpdateSearch({ type, value }) {
      if (Array.isArray(type)) {
        type.forEach((item, index) => {
          this.search[item] = value[index];
        });

        return;
      }

      this.search[type] = value;
    },
    async handleSearch() {
      this.search.pageIndex = 0;

      await this.handleReloadTasks();
    },
    async handleChangePage(page) {
      this.search.pageIndex = page - 1;

      await this.handleReloadTasks();
    },
    async handleDeleteTask({ id }) {
      const h = this.$createElement;
      this.$confirm("", "刪除此檔案", {
        message: h("div", null, [
          h(
            "div",
            { style: "margin-bottom: 8px;" },
            "請問是否確認刪除此檔案？"
          ),
          h("div", null, "一旦確認你的檔案將永久被刪除"),
        ]),
        confirmButtonText: "確認",
        cancelButtonText: "取消",
        confirmButtonClass: "primary-button",
      })
        .then(async () => {
          await deleteTask(id);

          this.handleUpdateToPrevPageIndex();

          await this.handleReloadTasks();

          this.$message({
            type: "success",
            message: "刪除成功",
            duration: 1000,
          });
        })
        .catch(() => {
          this.$message({
            type: "error",
            message: "刪除取消",
            duration: 3000,
          });
        });
    },
    handleUpdateToPrevPageIndex() {
      if (
        (this.total - 1) % this.search.pageSize === 0 &&
        this.search.pageIndex !== 0
      ) {
        this.search.pageIndex -= 1;
      }
    },
    async handleDisableTask({ id }) {
      const h = this.$createElement;
      this.$confirm("", "取消此檔案", {
        message: h("div", null, [
          h(
            "div",
            { style: "margin-bottom: 8px;" },
            "請問是否確認取消此檔案？"
          ),
          h("div", null, "一旦確認你的檔案將停止執行處理"),
        ]),
        confirmButtonText: "確認",
        cancelButtonText: "取消",
        confirmButtonClass: "primary-button",
      })
        .then(async () => {
          await disableTaskProcess(id);

          await this.handleReloadTasks();

          this.$message({
            type: "success",
            message: "取消成功",
            duration: 1000,
          });
        })
        .catch(() => {
          this.$message({
            type: "error",
            message: "取消失敗",
            duration: 3000,
          });
        });
    },
  },
};
</script>

<style lang="scss" scoped></style>
