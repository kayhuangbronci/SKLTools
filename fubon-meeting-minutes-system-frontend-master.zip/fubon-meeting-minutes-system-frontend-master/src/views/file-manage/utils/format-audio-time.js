const handleFormatAudioTime = (duration) => {
  let result = "";
  const hours = Math.floor(duration / 3600);
  if (hours > 0) {
    result += `${hours}`.padStart(2, "0") + ":";
  }
  duration %= 3600;
  const minutes = Math.floor(duration / 60);
  if (minutes > 0) {
    result += `${minutes}`.padStart(2, "0") + ":";
  }
  const seconds = duration % 60;
  result += `${seconds}`.padStart(2, "0");

  if (result === "00") {
    result = "-";
  } else if (result.length === 2) {
    result = "00:" + result;
  }

  return result;
};

export default handleFormatAudioTime;
