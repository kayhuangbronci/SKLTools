export const DEFAULT_COLOR = [
  "#3f8cbf",
  "#499e88",
  "#f6ca6c",
  "#dc9585",
  "#7ecdac",
  "#7cbadd",
  "#c7707f",
  "#85888e",
  "#000000",
  "#000000",
];
