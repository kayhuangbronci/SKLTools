<template>
  <div class="log-block">
    <div class="container">
      <search-form
        :search="search"
        :roles="roles"
        :loading="loading"
        :operationList="operationList"
        @update="handleUpdateSearch"
        @search="handleSearchForm"
      ></search-form>

      <result-table
        :loading="loading"
        :data="data"
        :total="total"
        :page="search.pageIndex"
        :pageSize="search.pageSize"
        @change-page="handleChangePage"
      ></result-table>
    </div>
  </div>
</template>

<script>
import SearchForm from "./components/SearchForm.vue";
import ResultTable from "./components/ResultTable.vue";
import { getLogs, getLogsTotal, getOperationList } from "@/api/log";
import { getRoles } from "@/api/user";

export default {
  name: "Log",
  components: {
    SearchForm,
    ResultTable,
  },
  data() {
    return {
      search: {
        username: "",
        role: "",
        start: "",
        end: "",
        desc: "",
        pageIndex: 0,
        pageSize: 20,
        operationType: "",
      },
      total: 0,
      roles: [{ role: "", description: "全部" }],
      operationList: [],
      data: [],
      loading: true,
    };
  },
  async created() {
    await this.handleGetRoles();
    await this.handleGetOperationList();
    await this.handleGetLogsData();
    await this.handleGetLogsTotal();
    this.loading = false;
  },
  methods: {
    async handleGetOperationList() {
      const { data } = await getOperationList();

      Object.keys(data[0].operations).forEach((el) => {
        this.operationList.push({ [el]: data[0].operations[el] });
      });
    },
    async handleGetRoles() {
      const { data } = await getRoles();

      this.roles = [...this.roles, ...data];
    },
    async handleGetLogsData() {
      const search = this.handleSearchData();

      const { data } = await getLogs(search);

      this.data = data.map((item) => ({
        ...item,
        roleName: this.handleRoleName(item.role),
        description: this.handleParseNewLine(item.description) || "",
      }));
    },
    async handleGetLogsTotal() {
      const search = this.handleSearchData();

      const { data } = await getLogsTotal(search);

      this.total = data[0].total;
    },
    handleRoleName(role) {
      return (
        this.roles.find((item) => item.role === role)?.description || "N/A"
      );
    },
    handleParseNewLine(content) {
      if (content.length !== 0) return content.replace(/\n/g, "<br />");
    },
    handleSearchData() {
      const s = { ...this.search };

      Object.keys(s).forEach((key) => {
        if (s[key] === "") {
          delete s[key];
        }
      });

      return s;
    },
    handleUpdateSearch({ type, value }) {
      if (Array.isArray(type)) {
        type.forEach((item, index) => {
          this.search[item] = value[index];
        });

        return;
      }

      this.search[type] = value;
    },
    async handleChangePage(page) {
      this.search.pageIndex = page - 1;

      this.loading = true;
      await this.handleGetLogsData();
      await this.handleGetLogsTotal();
      this.loading = false;
    },
    async handleSearchForm() {
      this.search.desc = this.search.desc.trim();
      this.search.username = this.search.username.trim();
      this.search.pageIndex = 0;

      this.loading = true;
      await this.handleGetLogsData();
      await this.handleGetLogsTotal();
      this.loading = false;
    },
  },
};
</script>

<style lang="scss" scoped></style>
