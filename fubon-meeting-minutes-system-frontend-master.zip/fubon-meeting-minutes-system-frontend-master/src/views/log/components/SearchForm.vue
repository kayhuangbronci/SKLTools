<template>
  <div class="search-form-block">
    <div class="title">
      <span>搜尋條件</span>
    </div>
    <el-form class="form" label-position="left">
      <el-row :gutter="20">
        <el-col :span="10">
          <el-form-item label-width="60px">
            <template #label>
              <span class="label">時間</span>
            </template>
            <div class="time-block">
              <el-date-picker
                :value="search.start"
                type="date"
                placeholder="請選擇"
                @input="handleSearchChange($event, 'start')"
                size="mini"
              />
              <span class="separator">至</span>
              <el-date-picker
                :value="search.end"
                type="date"
                placeholder="請選擇"
                @input="handleSearchChange($event, 'end')"
                size="mini"
              />
            </div>
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <div class="button-group">
            <el-button
              type="text"
              class="time-button"
              @click="handleTimeChange('clear')"
              >清除</el-button
            >
            <el-button
              type="text"
              class="time-button"
              @click="handleTimeChange('today')"
              >今日</el-button
            >
            <el-button
              type="text"
              class="time-button"
              @click="handleTimeChange('month')"
              >30天內</el-button
            >
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="8">
          <el-form-item label-width="60px">
            <template #label>
              <span class="label">帳號</span>
            </template>
            <el-input
              :value="search.username"
              size="mini"
              @input="handleSearchChange($event, 'username')"
              @keyup.enter.native="handleSearch"
            />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label-width="60px">
            <template #label>
              <span class="label">操作</span>
            </template>
            <el-select
              :value="search.operationType"
              @change="handleSearchChange($event, 'operationType')"
              size="mini"
              style="width: 100%"
            >
              <el-option value="" label="全部" />
              <el-option
                v-for="(operation, index) in adjustOperationList"
                :key="index"
                :value="Object.keys(operation)[0]"
                :label="Object.values(operation)[0]"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label-width="60px">
            <template #label>
              <span class="label">角色</span>
            </template>
            <el-select
              :value="search.role"
              @change="handleSearchChange($event, 'role')"
              style="width: 100%"
              size="mini"
            >
              <el-option
                v-for="({ role, description }, index) in roles"
                :key="index"
                :value="role"
                :label="description"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="8">
          <el-form-item label-width="60px">
            <template #label>
              <span class="label">描述</span>
            </template>
            <el-input
              :value="search.desc"
              @input="handleSearchChange($event, 'desc')"
              size="mini"
              @keyup.enter.native="handleSearch"
            />
          </el-form-item>
        </el-col>
        <el-col :span="8" :offset="8">
          <div class="search-block">
            <el-button
              type="info"
              icon="el-icon-search"
              @click="handleSearch"
              :disabled="loading"
              size="mini"
              >查詢</el-button
            >
          </div>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import dayjs from "dayjs";

const ROLES = [
  {
    description: "全部",
    role: "",
  },
  {
    description: "一般用戶",
    role: "user",
  },
  {
    description: "管理員",
    role: "admin",
  },
  {
    description: "模型管理員",
    role: "maintainer",
  },
  {
    description: "系統",
    role: "system",
  },
];

export default {
  name: "SearchForm",
  props: {
    search: {
      type: Object,
      default: () => ({}),
      required: true,
    },
    operationList: {
      type: Array,
      default: () => [],
      required: true,
    },
    loading: {
      type: Boolean,
      default: false,
      required: true,
    },
  },
  data() {
    return {
      roles: ROLES,
    };
  },
  computed: {
    adjustOperationList() {
      return this.operationList.reduce((acc, cur) => {
        const key = Object.keys(cur)[0];
        if (key !== "start" && key !== "stop") {
          acc.push(cur);
        }
        return acc;
      }, []);
    },
  },
  methods: {
    handleSearchChange(value, type) {
      if (type === "end") {
        value = dayjs(value)
          .set("hours", 23)
          .set("minute", 59)
          .set("second", 59)
          .toDate();
      }

      this.$emit("update", { type, value });
    },
    handleTimeChange(mode) {
      switch (mode) {
        case "clear":
          this.$emit("update", { type: ["start", "end"], value: ["", ""] });
          break;
        case "today": {
          const start = dayjs()
            .set("hours", 0)
            .set("minute", 0)
            .set("second", 0)
            .toDate();
          const end = dayjs()
            .set("hours", 23)
            .set("minute", 59)
            .set("second", 59)
            .toDate();
          this.$emit("update", { type: ["start", "end"], value: [start, end] });
          break;
        }
        case "month": {
          const end = dayjs()
            .set("hours", 23)
            .set("minute", 59)
            .set("second", 59)
            .toDate();
          const start = dayjs()
            .subtract(1, "month")
            .set("hours", 0)
            .set("minute", 0)
            .set("second", 0)
            .toDate();
          this.$emit("update", { type: ["start", "end"], value: [start, end] });
          break;
        }
        default:
          break;
      }
    },
    handleSearch() {
      this.$emit("search");
    },
  },
};
</script>

<style lang="scss" scoped>
.search-form-block {
  margin-bottom: 16px;

  .title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 14px;
    color: var(--main-font-color);
    margin-bottom: 16px;
  }

  .form {
    background-color: var(--main-color-gray);
    padding: 24px 20px 4px 20px;
  }

  .label {
    color: var(--main-font-color);
    font-weight: bold;
  }

  .time-block {
    display: flex;
    align-items: center;
    gap: 12px;

    .separator {
      font-weight: normal;
    }
  }

  .search-block {
    display: flex;
    justify-content: flex-end;
  }

  .button-group {
    button {
      position: relative;
      color: #959697;
      margin-right: 12px;
      font-weight: 400;

      &::before {
        content: "";
        position: absolute;
        top: 50%;
        right: -12px;
        transform: translateY(-50%);
        width: 1px;
        height: 12px;
        background-color: var(--main-font-color);
      }

      &:last-child::before {
        display: none;
      }
    }
  }
}
</style>
