<template>
  <div class="result-table-block">
    <div class="flex-center">
      <el-pagination
        background
        layout="prev,slot,next,jumper"
        :page-size="pageSize"
        :total="total"
        :disabled="loading"
        :current-page="page + 1"
        @prev-click="handleChangePage"
        @next-click="handleChangePage"
        @current-change="handleChangePage"
      >
        <div class="pagination-button">{{ page + 1 }}</div>
      </el-pagination>
    </div>

    <div class="title-block flex-between">
      <div class="">操作紀錄數量：{{ total }}</div>
    </div>
    <el-table
      ref="tableRef"
      :data="data"
      height="calc(100vh - 480px)"
      v-loading="loading"
      element-loading-text="載入中..."
      element-loading-custom-class="log-loading"
    >
      <template #empty>
        <div class="flex-center empty-text">目前暫無資料</div>
      </template>
      <el-table-column label="編號" prop="id" width="100">
        <template #header>
          <div class="flex-center">編號</div>
        </template>
        <template #default="{ row }">
          <div class="flex-center">{{ row.id }}</div>
        </template>
      </el-table-column>
      <el-table-column label="帳號" prop="username" width="180">
        <template #header>
          <div class="flex-center">帳號</div>
        </template>
        <template #default="{ row }">
          <div class="flex-center">{{ row.username }}</div>
        </template>
      </el-table-column>
      <el-table-column label="描述" prop="description">
        <template #default="{ row }">
          <div v-html="row.description"></div>
        </template>
      </el-table-column>
      <el-table-column label="操作" prop="type" width="100">
        <template #header>
          <div class="flex-center">操作</div>
        </template>
        <template #default="{ row }">
          <div class="flex-center">{{ row.type }}</div>
        </template>
      </el-table-column>
      <el-table-column label="時間" prop="time" width="200">
        <template #header>
          <div class="flex-center">時間</div>
        </template>
        <template #default="{ row }">
          <div class="flex-center">
            {{ $formatDate(row.createTime) }}
          </div>
        </template>
      </el-table-column>
      <el-table-column label="角色" prop="roleName" width="100">
        <template #header>
          <div class="flex-center">角色</div>
        </template>
        <template #default="{ row }">
          <div class="flex-center">
            {{ row.roleName === "維運人員" ? "模型管理員" : row.roleName }}
          </div>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  name: "ResultTable",
  props: {
    data: {
      type: Array,
      default: () => [],
      required: true,
    },
    total: {
      type: Number,
      default: 0,
      required: true,
    },
    page: {
      type: Number,
      default: 1,
      required: true,
    },
    pageSize: {
      type: Number,
      default: 20,
      required: true,
    },
    loading: {
      type: Boolean,
      default: false,
      required: true,
    },
  },
  watch: {
    loading(val) {
      if (val) this.$refs.tableRef.bodyWrapper.scrollTop = 0;
    },
  },
  methods: {
    handleChangePage(page) {
      this.$emit("change-page", page);
    },
  },
};
</script>

<style lang="scss" scoped>
.result-table-block {
  padding-bottom: 40px;

  .pagination-button {
    display: inline-block;
    text-align: center;
    min-width: 30px;
    color: #ffffff;
    margin: 0 5px;
    border-radius: 2px;
    background-color: var(--main-color-green);
    font-size: 13px;
    height: 28px;
    line-height: 28px;
    vertical-align: top;
  }

  .title-block {
    margin: 12px 0;
    font-size: 14px;
    color: var(--main-font-color);
  }

  ::v-deep .el-table__header {
    tr {
      th {
        background-color: var(--main-color-green);
        color: #ffffff;
      }
    }
  }

  .empty-text {
    font-size: 20px;
    color: #bababc;
    padding: 20px 0;
  }

  ::v-deep .log-loading {
    .el-loading-spinner {
      top: 300px;
    }
  }
}
</style>
