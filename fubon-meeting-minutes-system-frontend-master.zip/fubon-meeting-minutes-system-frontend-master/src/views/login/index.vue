<template>
  <div class="login-block">
    <header>
      <nav>
        <div class="decoration"></div>
        <div class="container">
          <ul class="menu-wrapper">
            <li>
              <img src="../../assets/nav-logo.png" alt="富邦" />
            </li>
          </ul>
        </div>
      </nav>
    </header>

    <main class="main-block">
      <div class="container wrapper">
        <div class="login-image"></div>

        <div class="login-wrapper">
          <div>
            <div class="title">登入</div>

            <el-form
              ref="formRef"
              :model="form"
              :rules="rules"
              class="login-form"
            >
              <el-form-item label="帳號" prop="username">
                <el-input
                  v-model="form.username"
                  @keyup.enter.native="handleLogin"
                  placeholder="同EIP登入帳號@fubon.com"
                ></el-input>
              </el-form-item>
              <el-form-item label="密碼" prop="password">
                <el-input
                  v-model="form.password"
                  type="password"
                  @keyup.enter.native="handleLogin"
                  placeholder="同EIP登入密碼"
                ></el-input>
              </el-form-item>
            </el-form>
          </div>

          <el-button
            @click="handleLogin"
            class="login-button"
            :loading="loading"
          >
            登入
          </el-button>
        </div>
      </div>
    </main>
  </div>
</template>

<script>
export default {
  name: "Login",
  data() {
    return {
      form: {
        username: "",
        password: "",
        rememberMe: 0,
      },
      rules: {
        username: [{ required: true, message: "請輸入帳號", trigger: "blur" }],
        password: [{ required: true, message: "請輸入密碼", trigger: "blur" }],
      },
      loading: false,
    };
  },
  methods: {
    handleLogin() {
      this.$refs.formRef.validate((valid) => {
        if (valid) {
          this.loading = true;
          this.$store
            .dispatch("user/userLogin", this.form)
            .then(() => {
              this.$router.push({ path: "/" });
            })
            .catch((error) => {
              console.log(`login error ${error}`);
            })
            .finally(() => {
              this.loading = false;
            });
        } else {
          return false;
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.login-block {
  height: 100vh;

  .decoration {
    height: 6px;
    background-color: var(--main-color-blue);
  }

  nav {
    background-color: var(--main-bg-nav);
    box-shadow: rgb(0 0 0 / 20%) 0px 3px 3px -2px,
      rgb(0 0 0 / 14%) 0px 3px 4px 0px, rgb(0 0 0 / 12%) 0px 1px 8px 0px;
  }

  .menu-wrapper {
    display: flex;
    align-items: center;
    height: 72px;
  }

  .main-block {
    padding-top: 2%;
    height: calc(100vh - 78px);

    .wrapper {
      display: flex;
    }

    .login-image {
      background-image: url("../../assets/login-bg.png");
      background-size: contain;
      background-repeat: no-repeat;
      padding-top: 42%;
      width: 66.666%;
    }

    .login-wrapper {
      width: 33.3333%;
      padding: 20px;
      border-radius: 10px;
      box-shadow: rgb(0 0 0 / 20%) 0px 3px 3px -2px,
        rgb(0 0 0 / 14%) 0px 3px 4px 0px, rgb(0 0 0 / 12%) 0px 1px 8px 0px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;

      .title {
        color: var(--main-color-blue);
        text-align: center;
        font-weight: bold;
        position: relative;
        padding-bottom: 20px;
        margin-bottom: 20px;

        &::before {
          content: "";
          position: absolute;
          left: 0;
          bottom: 0;
          width: 100%;
          height: 4px;
          background-color: var(--main-color-blue);
        }
      }

      .login-form {
        padding: 0 20px;
      }

      .show-password-button {
        position: absolute;
        right: 2%;
        top: 75%;
        transform: translateY(-50%);
        background-color: inherit;
        background-position: bottom center;
        background-image: url("../../assets/show-password.png");
        background-size: 30px 60px;
        width: 30px;
        height: 30px;
        border: none;
        cursor: pointer;

        &:hover {
          opacity: 0.7;
        }

        &.show {
          background-position: top center;
        }
      }

      .login-button {
        width: 100%;
        border-radius: 18px;
        background: linear-gradient(
          90deg,
          rgba(65, 146, 186, 1) 0%,
          rgba(67, 151, 175, 1) 35%,
          rgba(70, 157, 162, 1) 53%,
          rgba(74, 163, 150, 1) 100%
        );
        color: #ffffff;
        transition: all 0.3s;

        &:hover {
          background: linear-gradient(
            90deg,
            rgba(64, 145, 188, 1) 0%,
            rgba(64, 145, 188, 1) 100%
          );
        }

        .loading-icon {
          width: 16px;
          height: 16px;
        }
      }
    }
  }
}
</style>
