<template>
  <div class="feedback-error-block">
    <div class="container">
      <breadcrumb>
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>使用者回饋</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ name: 'FeedbackError' }"
            >錯誤字回報</el-breadcrumb-item
          >
        </el-breadcrumb>
      </breadcrumb>

      <div class="title-block">
        <p>錯誤字回報列表</p>

        <div>
          <el-button class="primary-button" @click="handleSubmit"
            >送出</el-button
          >
          <el-button class="third-button" @click="handleAdd"
            >增加新詞</el-button
          >
        </div>
      </div>

      <div class="error-table-block">
        <el-table
          ref="errataRef"
          :data="data"
          style="100%"
          :default-sort="{ prop: 'id', order: 'descending' }"
        >
          <el-table-column type="index" width="64" label="編號" prop="id">
            <template #header>
              <div class="custom-header text-center">編號</div>
            </template>
            <template #default="{ $index }">
              <div class="text-center">{{ $index + 1 }}</div>
            </template>
          </el-table-column>
          <el-table-column label="系統辨識文字">
            <template #header>
              <div class="custom-header text-center">
                修正前文字<span>(系統辨識文字)</span>
              </div>
            </template>

            <template #default="{ row }">
              <el-row :gutter="20">
                <el-col :span="24">
                  <el-input
                    v-model="row.original"
                    :class="[row.duplicate && 'duplicate']"
                    @input="handleFindDuplicate"
                    clearable
                  />
                </el-col>
              </el-row>
            </template>
          </el-table-column>
          <el-table-column label="建議正確文字">
            <template #header>
              <div class="custom-header text-center">
                修正後文字<span>(建議正確文字)</span>
              </div>
            </template>

            <template #default="{ row }">
              <el-row :gutter="20">
                <el-col :span="24">
                  <el-input v-model="row.fixed" clearable />
                </el-col>
              </el-row>
            </template>
          </el-table-column>
          <el-table-column label="刪除" width="64">
            <template #header>
              <div class="custom-header text-center">刪除</div>
            </template>

            <template #default="{ $index }">
              <div class="text-center">
                <el-button
                  class="third-button delete-button"
                  icon="el-icon-close"
                  circle
                  @click="handleDelete($index)"
                />
              </div>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
  </div>
</template>

<script>
import { createFeedbackErrata } from "@/api/feedback";

export default {
  name: "FeedbackError",
  data() {
    return {
      setup: {
        pageIndex: 0,
        pageSize: 20,
      },
      data: [
        {
          original: "",
          fixed: "",
          duplicate: false,
        },
      ],
    };
  },
  computed: {
    hasDuplicate() {
      return this.data.some(({ duplicate }) => duplicate);
    },
  },
  methods: {
    handleAdd() {
      this.data.push({
        original: "",
        fixed: "",
        duplicate: false,
      });
    },
    handleDelete(index) {
      const currentIndex = this.handleGetCurrentIndex(index);
      this.data.splice(currentIndex, 1);

      this.handleFindDuplicate();
    },
    handleGetCurrentIndex(index) {
      return this.data.length - 1 - index;
    },
    handleFindDuplicate() {
      const dataMap = new Map();

      this.data.forEach(({ original }) => {
        if (original.trim().length === 0) return;

        dataMap.has(original)
          ? dataMap.set(original, dataMap.get(original) + 1)
          : dataMap.set(original, 1);
      });

      this.data.forEach(({ original }, index) => {
        if (dataMap.get(original) > 1) {
          this.handleUpdateDuplicate(index, true);
        } else {
          this.handleUpdateDuplicate(index, false);
        }
      });
    },
    handleUpdateDuplicate(index, duplicate = true) {
      this.data.splice(index, 1, {
        ...this.data[index],
        duplicate,
      });
    },
    async handleSubmit() {
      if (this.hasDuplicate) {
        this.$message({
          type: "error",
          message: "請修正重複的資料",
          duration: 3000,
        });

        return;
      }

      try {
        const data = this.data
          .map(({ original, fixed }) => ({
            original: original.trim(),
            fixed: fixed.trim(),
          }))
          .filter(({ original, fixed }) => original && fixed);

        if (data.length === 0) {
          this.$message({
            type: "warning",
            message: "請輸入資料",
            duration: 1000,
          });

          return;
        }

        await createFeedbackErrata(data);

        this.$message({
          type: "success",
          message: "回報成功",
          duration: 1000,
        });

        this.data = [
          {
            original: "",
            fixed: "",
            duplicate: false,
          },
        ];
      } catch (error) {
        console.log(error);

        this.$message({
          type: "error",
          message: "回報失敗",
          duration: 3000,
        });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.feedback-error-block {
  .title-block {
    display: flex;
    justify-content: space-between;
    align-items: center;

    p {
      font-weight: bold;
    }
  }
  .error-table-block {
    margin-bottom: 24px;

    .text-center {
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .custom-header {
      color: #000000;

      span {
        font-weight: 400;
        padding-left: 4px;
      }
    }

    .delete-button {
      padding: 0 !important;
    }

    .button-group {
      margin-top: 12px;
      display: flex;
      justify-content: flex-end;
    }
  }

  ::v-deep .duplicate .el-input__inner {
    border-color: red !important;
  }
}
</style>
