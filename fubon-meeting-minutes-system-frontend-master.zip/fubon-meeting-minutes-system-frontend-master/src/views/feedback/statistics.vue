<template>
  <div class="feedback-satisfy-block">
    <div class="container">
      <breadcrumb>
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>使用者回饋</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ name: 'FeedbackStatistics' }"
            >回饋問卷</el-breadcrumb-item
          >
        </el-breadcrumb>
      </breadcrumb>

      <div class="feedback-block">
        <img
          src="../../assets/feedback-statistics.png"
          alt="回饋問卷"
          class="feedback-image"
        />

        <p>
          感謝您的使用，如果想要幫助我們更加完善此網站，請點選下方連結填寫問卷，給予我們寶貴建議。
        </p>

        <a href="https://survey.fubon.com/s/AMOvR" target="_blank"
          >點此前往填寫問卷</a
        >
      </div>
    </div>
  </div>
</template>

<script lang="ts">
export default {
  name: "FeedbackStatistics",
};
</script>

<style lang="scss" scoped>
.feedback-satisfy-block {
  .feedback-block {
    text-align: center;
    font-size: 14px;
    letter-spacing: 1.2px;
    color: #5b5b5b;

    .feedback-image {
      padding: 6%;
      margin-top: 12px;
      margin-bottom: 24px;
    }

    p {
      margin-bottom: 12px;
    }

    a {
      color: #3e8ab5;
      position: relative;
      padding-bottom: 6px;
      transition: all 0.3s;
      font-weight: bold;

      &::before {
        content: "";
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        border-bottom: 1px solid #3e8ab5;
      }

      &:hover {
        color: #60acd7;

        &::before {
          border-bottom: 1px solid #60acd7;
        }
      }
    }
  }
}
</style>
