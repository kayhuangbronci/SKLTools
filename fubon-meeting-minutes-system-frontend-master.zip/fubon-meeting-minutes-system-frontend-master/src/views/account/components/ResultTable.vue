<template>
  <div class="user-table-wrapper">
    <div class="pagination-block">
      <el-pagination
        background
        :page-size="setup.pageSize"
        layout="prev,slot,next,jumper"
        :total="total"
        :current-page="setup.pageIndex + 1"
        @prev-click="handleChangePage"
        @next-click="handleChangePage"
        @current-change="handleChangePage"
      >
        <div class="pagination-button">{{ setup.pageIndex + 1 }}</div>
      </el-pagination>
    </div>
    <div class="total">帳號總數量：{{ total }}</div>
    <el-table ref="tableRef" :data="users">
      <el-table-column label="帳號" prop="username"></el-table-column>
      <el-table-column label="帳號類型" prop="role">
        <template #default="{ row }">
          {{ handleFindRoleName(row.role) }}
        </template>
      </el-table-column>
      <el-table-column label="狀態" prop="status">
        <template #default="{ row }">
          <span :class="[row.status === 1 ? 'success' : 'fail']">{{
            row.status === 1 ? "啟用" : "停用"
          }}</span>
        </template>
      </el-table-column>
      <el-table-column label="創建時間" prop="createTime"></el-table-column>
      <el-table-column
        label="最後登入時間"
        prop="lastLoginTime"
      ></el-table-column>
      <el-table-column label="編輯" width="60">
        <template #default="{ row }">
          <button
            class="edit-button"
            :disabled="currentUsername === row.username || row.role === 'user'"
            @click="handleEdit(row)"
            :title="
              currentUsername === row.username
                ? '無法編輯自己的帳號角色'
                : '編輯角色'
            "
          ></button>
        </template>
      </el-table-column>
    </el-table>

    <edit-account-dialog
      v-if="visibility.editDialog && current && current.role !== 'user'"
      :dialog-visible="visibility.editDialog"
      :user="current"
      @close="handleCloseEditDialog"
    ></edit-account-dialog>
  </div>
</template>

<script>
import EditAccountDialog from "./EditAccountDialog.vue";

const ROLES = [
  {
    label: "管理員",
    value: "admin",
  },
  {
    label: "模型管理員",
    value: "maintainer",
  },
  {
    label: "一般用戶",
    value: "user",
  },
];

export default {
  name: "ResultTable",
  components: {
    EditAccountDialog,
  },
  props: {
    users: {
      type: Array,
      default: () => [],
    },
    total: {
      type: Number,
      default: 0,
    },
    setup: {
      type: Object,
      default: () => ({}),
    },
  },
  data() {
    return {
      roles: ROLES,
      visibility: {
        editDialog: false,
      },
      current: null,
    };
  },
  computed: {
    currentUsername() {
      return this.$store.getters.info.name;
    },
  },
  methods: {
    handleFindRoleName(role) {
      return this.roles.find((item) => item.value === role).label || "N/A";
    },
    handleChangePage(page) {
      this.$emit("page-change", { ...this.setup, pageIndex: page - 1 });
    },
    handleEdit(row) {
      this.visibility.editDialog = true;
      this.current = row;
    },
    handleCloseEditDialog({ update }) {
      if (update) {
        this.$emit("update");
      }

      this.visibility.editDialog = false;
    },
  },
};
</script>

<style lang="scss" scoped>
.user-table-wrapper {
  .total {
    padding-bottom: 16px;
    font-size: 14px;
    color: #585858;
  }

  .success {
    color: #67c23a;
  }
  .fail {
    color: #f56c6c;
  }

  .pagination-block {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 16px;
  }

  .pagination-button {
    display: inline-block;
    text-align: center;
    min-width: 30px;
    color: #ffffff;
    margin: 0 5px;
    border-radius: 2px;
    background-color: var(--main-color-green);
    font-size: 13px;
    height: 28px;
    line-height: 28px;
    vertical-align: top;
  }

  .edit-button {
    width: 16px;
    height: 16px;
    background-image: url("../../../assets/edit-icon.png");
    background-size: 100%;
    background-repeat: no-repeat;
    background-position: center;
    background-color: inherit;
    border: none;
    cursor: pointer;

    &:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
  }

  ::v-deep .el-table__header {
    tr {
      th {
        background-color: var(--main-color-green);
        color: #ffffff;
      }
    }
  }
}
</style>
