<template>
  <el-dialog
    title="編輯帳號"
    :visible.sync="dialogVisible"
    width="400px"
    :before-close="handleClose"
  >
    <el-form
      ref="editAccountRef"
      :model="form"
      :rules="rules"
      label-width="80px"
      label-position="right"
    >
      <el-form-item label="帳號類型" prop="role">
        <el-select v-model="form.role">
          <el-option
            v-for="{ value, label } in roles"
            :key="value"
            :value="value"
            :label="label"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="狀態" prop="status">
        <el-select v-model="form.status">
          <el-option :value="0" label="停用"></el-option>
          <el-option :value="1" label="啟用"></el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取消</el-button>
      <el-button type="primary" @click="handleSubmit">確定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { updateUserInfo } from "@/api/user";

const ROLES = [
  {
    label: "管理員",
    value: "admin",
  },
  {
    label: "模型管理員",
    value: "maintainer",
  },
];

export default {
  name: "EditAccountDialog",
  props: {
    dialogVisible: {
      required: true,
      type: Boolean,
      default: false,
    },
    user: {
      required: true,
      type: Object,
      default: () => ({}),
    },
  },
  data() {
    return {
      form: {
        role: "admin",
        status: 1,
      },
      rules: {
        role: [
          { required: true, message: "請選擇帳號類型", trigger: "change" },
        ],
        status: [{ required: true, message: "請選擇狀態", trigger: "change" }],
      },
      roles: ROLES,
    };
  },
  created() {
    const user = JSON.parse(JSON.stringify(this.user));
    this.form.role = user.role;
    this.form.status = user.status;
  },
  methods: {
    handleClose(update = false) {
      this.$emit("close", { update });
    },
    handleSubmit() {
      this.$refs.editAccountRef.validate((valid) => {
        if (valid) {
          this.$confirm("確定要修改角色，是否繼續？", "警告", {
            confirmButtonText: "確定",
            cancelButtonText: "取消",
            type: "warning",
          })
            .then(async () => {
              const params = {
                ...this.user,
                currentRole: this.user.role,
                username: this.user.username,
                newRole: this.form.role,
                status: this.form.status,
              };

              await updateUserInfo(params);

              this.$message({
                type: "success",
                message: "修改成功",
                duration: 1000,
              });

              this.handleClose(true);
            })
            .catch(console.log);
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped></style>
