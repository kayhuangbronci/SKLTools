<template>
  <el-dialog
    title="創建帳號"
    :visible.sync="dialogVisible"
    width="400px"
    :before-close="handleClose"
  >
    <el-form
      ref="createAccountRef"
      :model="form"
      :rules="rules"
      label-width="80px"
      label-position="right"
    >
      <el-form-item label="帳號" prop="username">
        <el-input v-model="form.username"></el-input>
      </el-form-item>
      <el-form-item label="帳號類型" prop="role">
        <el-select v-model="form.role">
          <el-option
            v-for="{ value, label } in roles"
            :key="value"
            :value="value"
            :label="label"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="狀態" prop="status">
        <el-select v-model="form.status">
          <el-option :value="0" label="停用"></el-option>
          <el-option :value="1" label="啟用"></el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取消</el-button>
      <el-button type="primary" @click="handleSubmit">確定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { createUser } from "@/api/user";

const ROLES = [
  {
    label: "管理員",
    value: "admin",
  },
  {
    label: "模型管理員",
    value: "maintainer",
  },
];

const DEFAULT_PASSWORD = "1qaz@WSX";

export default {
  name: "CreateAccountDialog",
  props: {
    dialogVisible: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      roles: ROLES,
      form: {
        role: "admin",
        username: "",
        status: 1,
      },
      rules: {
        username: [
          { required: true, message: "請輸入帳號", trigger: "blur" },
          {
            min: 3,
            max: 20,
            message: "長度在 3 到 20 個字元",
            trigger: "blur",
          },
        ],
        role: [
          { required: true, message: "請選擇帳號類型", trigger: "change" },
        ],
        status: [{ required: true, message: "請選擇狀態", trigger: "change" }],
      },
    };
  },
  methods: {
    handleClose(update = false) {
      this.$emit("close", { update });
    },
    handleSubmit() {
      this.$refs.createAccountRef.validate(async (valid) => {
        if (valid) {
          try {
            const data = {
              ...this.form,
              nickname: this.form.username,
              password: DEFAULT_PASSWORD,
              comment: "",
              expiredTime: "",
            };
            const { code, message } = await createUser(data);

            if (code === 200) {
              this.$message({
                type: "success",
                message: "創建帳號成功",
                duration: 1000,
              });
              this.handleClose(true);
            } else {
              throw new Error(message);
            }
          } catch (error) {
            console.error(`Create user failed: ${error}`);
            this.$message({
              type: "error",
              message: "創建帳號失敗",
              duration: 3000,
            });
          }
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped></style>
