<template>
  <div class="search-form-wrapper">
    <el-form :inline="true" class="form">
      <el-form-item label="帳號類型">
        <template #label>
          <span class="label">帳號類型</span>
        </template>
        <el-select
          :value="form.role"
          @change="$emit('update', { ...form, role: $event })"
        >
          <el-option
            v-for="role in roles"
            :key="role.label"
            :label="role.label"
            :value="role.value"
          ></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="帳號名稱">
        <template #label>
          <span class="label">帳號名稱</span>
        </template>

        <el-autocomplete
          :value="form.username"
          :fetch-suggestions="handleQueryUsername"
          placeholder="請輸入帳號"
          @input="$emit('update', { ...form, username: $event })"
          @select="({ value }) => $emit('update', { ...form, username: value })"
        ></el-autocomplete>
      </el-form-item>

      <el-button type="info" icon="el-icon-search" @click="$emit('search')"
        >查詢</el-button
      >
    </el-form>
  </div>
</template>

<script>
import { debounce } from "lodash";
import { getAllUsers } from "@/api/user";

export default {
  name: "SearchForm",
  props: {
    form: {
      type: Object,
      default: () => ({}),
    },
  },
  data() {
    return {
      roles: [
        {
          label: "全部",
          value: "not",
        },
        {
          label: "管理員",
          value: "admin",
        },
        {
          label: "模型管理員",
          value: "maintainer",
        },
      ],
    };
  },
  methods: {
    handleQueryUsername: debounce(function (username, cb) {
      if (username.length === 0) {
        cb([]);
        return;
      }

      getAllUsers({ username })
        .then(({ data }) => {
          const users = [];
          data.forEach((el) => {
            users.push({ value: el.username });
          });
          cb(users);
        })
        .catch(console.log);
    }, 500),
  },
};
</script>

<style lang="scss" scoped>
.search-form-wrapper {
  margin-bottom: 20px;

  .form {
    background-color: var(--main-color-gray);
    padding: 20px;
  }

  .label {
    color: var(--main-font-color);
    font-weight: bold;
  }
}
</style>
