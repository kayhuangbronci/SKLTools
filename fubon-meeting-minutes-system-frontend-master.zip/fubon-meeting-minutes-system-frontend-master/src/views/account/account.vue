<template>
  <div class="account-manage">
    <div class="container">
      <breadcrumb>
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ name: 'Account' }"
            >帳號管理</el-breadcrumb-item
          >
        </el-breadcrumb>

        <template #right>
          <el-button
            class="primary-button"
            icon="el-icon-plus"
            @click="visibility.createAccountDialog = true"
            size="small"
          >
            新增帳號
          </el-button>
        </template>
      </breadcrumb>

      <search-form
        :form="setup"
        @update="handleUpdateForm"
        @search="handleSearch"
      ></search-form>

      <result-table
        :users="users"
        :total="total"
        :setup="setup"
        @page-change="handleUpdate"
        @update="handleUpdate"
      ></result-table>
    </div>

    <create-account-dialog
      v-if="visibility.createAccountDialog"
      :dialog-visible="visibility.createAccountDialog"
      @close="handleCloseDialog"
    ></create-account-dialog>
  </div>
</template>

<script>
import Breadcrumb from "@/components/Breadcrumb.vue";
import SearchForm from "./components/SearchForm.vue";
import ResultTable from "./components/ResultTable.vue";
import CreateAccountDialog from "./components/CreateAccountDialog.vue";
import { getAllUsers, getAllUsersTotal } from "@/api/user";

export default {
  name: "Account",
  components: {
    Breadcrumb,
    SearchForm,
    ResultTable,
    CreateAccountDialog,
  },
  data() {
    return {
      setup: {
        role: "not",
        username: "",
        pageSize: 20,
        pageIndex: 0,
      },
      users: [],
      total: 0,
      visibility: {
        createAccountDialog: false,
      },
    };
  },
  async created() {
    await this.handleGetUsers();
    await this.handleGetUsersTotal();
  },
  methods: {
    async handleGetUsers() {
      const form = JSON.parse(JSON.stringify(this.setup));

      Object.keys(form).forEach((key) => {
        if (key === "role" && form[key] === "not") {
          delete form[key];
          return;
        }

        if (form[key].length === 0) delete form[key];
      });

      const { data } = await getAllUsers(form);
      this.users = data;
    },
    async handleGetUsersTotal() {
      const role = this.setup.role === "not" ? "" : this.setup.role;

      const { data } = await getAllUsersTotal({
        role,
        username: this.setup.username,
      });

      this.total = data[0].total;
    },
    handleUpdateForm(value) {
      this.setup = { ...value };
    },
    async handleSearch() {
      this.setup.username = this.setup.username.trim();
      this.setup.pageIndex = 0;

      await this.handleGetUsers();
      await this.handleGetUsersTotal();
    },
    async handleUpdate(setup) {
      if (setup) this.setup = { ...setup };

      await this.handleGetUsers();
      await this.handleGetUsersTotal();
    },
    handleCloseDialog() {
      this.visibility.createAccountDialog = false;

      this.handleUpdate();
    },
  },
};
</script>

<style lang="scss" scoped></style>
