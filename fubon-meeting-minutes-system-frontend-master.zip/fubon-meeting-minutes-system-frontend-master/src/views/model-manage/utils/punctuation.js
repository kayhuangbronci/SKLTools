export const punctuationLayerOue = [
  "ㄅ",
  "ㄆ",
  "ㄇ",
  "ㄈ",
  "ㄉ",
  "ㄊ",
  "ㄋ",
  "ㄌ",
  "ㄍ",
  "ㄎ",
  "ㄏ",
  "ㄐ",
  "ㄑ",
  "ㄒ",
  "ㄓ",
  "ㄔ",
  "ㄕ",
  "ㄖ",
  "ㄗ",
  "ㄘ",
  "ㄙ",
];

export const punctuationLayerTwo = ["ㄧ", "ㄨ", "ㄩ"];

export const punctuationLayerThree = [
  "ㄚ",
  "ㄛ",
  "ㄜ",
  "ㄝ",
  "ㄞ",
  "ㄟ",
  "ㄠ",
  "ㄡ",
  "ㄢ",
  "ㄣ",
  "ㄤ",
  "ㄥ",
  "ㄦ",
];

export const tones = [
  {
    display: "ㄧ聲",
    value: "",
  },
  {
    display: "二聲",
    value: "ˊ",
  },
  {
    display: "三聲",
    value: "ˇ",
  },
  {
    display: "四聲",
    value: "ˋ",
  },
  {
    display: "輕聲",
    value: "˙",
  },
];
