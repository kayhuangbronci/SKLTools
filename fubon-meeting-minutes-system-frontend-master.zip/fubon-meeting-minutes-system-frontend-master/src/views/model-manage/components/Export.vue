<template>
  <div class="export-block">
    <div class="title">錯誤字回報</div>

    <div class="form-wrapper">
      <el-form ref="formRef" :model="form" :rules="rules">
        <el-row :gutter="20">
          <el-col :span="10">
            <el-form-item label-width="60px" prop="time">
              <template #label>
                <span class="label">時間</span>
              </template>
              <div class="time-block">
                <el-date-picker
                  :value="form.start"
                  type="date"
                  placeholder="請選擇"
                  @input="handleFormTimeChange($event, 'start')"
                />
                <span class="separator">至</span>
                <el-date-picker
                  :value="form.end"
                  type="date"
                  placeholder="請選擇"
                  @input="handleFormTimeChange($event, 'end')"
                />
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="11">
            <div class="button-group">
              <el-button
                type="text"
                class="time-button"
                @click="handleTimeChange('clear')"
                >清除</el-button
              >
              <el-button
                type="text"
                class="time-button"
                @click="handleTimeChange('today')"
                >今日</el-button
              >
              <el-button
                type="text"
                class="time-button"
                @click="handleTimeChange('month')"
                >30天內</el-button
              >
            </div>
          </el-col>
          <el-col :span="3">
            <div class="flex-end">
              <el-button class="primary-button" @click="handleExport"
                >匯出錯誤字回報檔案</el-button
              >
            </div>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>

<script>
import { downloadFeedbackErrata } from "@/api/feedback";
import dayjs from "dayjs";

export default {
  name: "Export",
  data() {
    return {
      form: {
        start: "",
        end: "",
      },
      rules: {
        time: [
          {
            validator: (_rule, _value, callback) => {
              if (this.form.start && this.form.end) {
                const start = dayjs(this.form.start).valueOf();
                const end = dayjs(this.form.end).valueOf();
                if (start > end) {
                  callback(new Error("開始時間不可大於結束時間"));
                } else {
                  callback();
                }
              } else {
                callback();
              }
            },
            trigger: "change",
          },
        ],
      },
    };
  },
  computed: {
    token() {
      return this.$store.getters.token;
    },
  },
  methods: {
    handleFormTimeChange(val, key) {
      if (key === "end") {
        val = dayjs(val)
          .set("hours", 23)
          .set("minute", 59)
          .set("second", 59)
          .toDate();
      }
      this.form[key] = val;
    },
    handleTimeChange(mode) {
      switch (mode) {
        case "clear":
          this.form.start = "";
          this.form.end = "";
          break;
        case "today": {
          const start = dayjs()
            .set("hours", 0)
            .set("minute", 0)
            .set("second", 0)
            .toDate();
          const end = dayjs()
            .set("hours", 23)
            .set("minute", 59)
            .set("second", 59)
            .toDate();
          this.form.start = start;
          this.form.end = end;
          break;
        }
        case "month": {
          const end = dayjs()
            .set("hours", 23)
            .set("minute", 59)
            .set("second", 59)
            .toDate();
          const start = dayjs()
            .subtract(1, "month")
            .set("hours", 0)
            .set("minute", 0)
            .set("second", 0)
            .toDate();
          this.form.start = start;
          this.form.end = end;
          break;
        }
        default:
          break;
      }
    },
    handleExport() {
      this.$refs.formRef.validate(async (valid) => {
        if (valid) {
          const { start, end } = JSON.parse(JSON.stringify(this.form));
          let params = {};
          if (start && end) {
            params = { start, end };
          }
          const { data } = await downloadFeedbackErrata(params);
          const { url } = data[0];
          const link = document.createElement("a");
          link.href = `${url}?token=${this.token}`;
          link.target = "_blank";
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.export-block {
  margin-bottom: 30px;

  .title {
    font-weight: bold;
    font-size: 16px;
    margin-bottom: 20px;
  }

  .form-wrapper {
    padding: 20px 20px 0 20px;
    background-color: var(--main-color-gray);

    .label {
      color: var(--main-font-color);
      font-weight: bold;
    }

    .time-block {
      display: flex;
      align-items: center;
      gap: 12px;

      .separator {
        font-weight: normal;
      }
    }

    .button-group {
      button {
        position: relative;
        color: #959697;
        margin-right: 12px;
        font-weight: 400;

        &::before {
          content: "";
          position: absolute;
          top: 50%;
          right: -12px;
          transform: translateY(-50%);
          width: 1px;
          height: 12px;
          background-color: var(--main-font-color);
        }

        &:last-child::before {
          display: none;
        }
      }
    }
  }
}
</style>
