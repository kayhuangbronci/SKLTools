<template>
  <el-dialog
    class="sound-adjust-dialog"
    title="音調調整"
    width="600px"
    :visible.sync="dialogVisible"
    :before-close="handleClose"
  >
    <div class="word-wrapper">
      <div v-for="(word, index) in vocabularyArr" :key="index">
        <div class="word">{{ word }}</div>
        <ul v-if="result[index]" class="punctuation-group">
          <li>
            <el-select v-model="result[index].punctuation1">
              <el-option value="" label=""></el-option>
              <el-option
                v-for="(punc, index) in punctuationLayerOue"
                :key="index"
                :label="punc"
                :value="punc"
              ></el-option>
            </el-select>
          </li>
          <li>
            <el-select v-model="result[index].punctuation2">
              <el-option value="" label=""></el-option>
              <el-option
                v-for="(punc, index) in punctuationLayerTwo"
                :key="index"
                :label="punc"
                :value="punc"
              ></el-option>
            </el-select>
          </li>
          <li>
            <el-select v-model="result[index].punctuation3">
              <el-option value="" label=""></el-option>
              <el-option
                v-for="(punc, index) in punctuationLayerThree"
                :key="index"
                :label="punc"
                :value="punc"
              ></el-option>
            </el-select>
          </li>
          <li>
            <div class="tone">聲調</div>
            <el-select v-model="result[index].tone">
              <el-option
                v-for="({ display, value }, index) in tones"
                :key="index"
                :label="display"
                :value="value"
              ></el-option>
            </el-select>
          </li>
        </ul>
      </div>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取消</el-button>
      <el-button class="primary-button" @click="handleSubmit">確認</el-button>
    </span>
  </el-dialog>
</template>

<script>
import {
  tones,
  punctuationLayerOue,
  punctuationLayerTwo,
  punctuationLayerThree,
} from "../utils/punctuation";

export default {
  name: "SoundAdjustDialog",
  props: {
    dialogVisible: {
      type: Boolean,
      required: true,
      default: false,
    },
    data: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      result: [],
      tones,
      punctuationLayerOue,
      punctuationLayerTwo,
      punctuationLayerThree,
    };
  },
  computed: {
    vocabularyArr() {
      if (this.data.word) {
        return this.data.word.replaceAll(" ", "").split("");
      } else {
        return [];
      }
    },
  },
  created() {
    if (this.data.spell) {
      this.result = [...this.result, ...this.data.spell];
    }
  },
  methods: {
    handleClose() {
      this.$emit("close");
    },
    handleSubmit() {
      const error = this.result.some(
        (item) => !item.punctuation1 && !item.punctuation2 && !item.punctuation3
      );

      if (error) {
        this.$message({
          type: "error",
          message: "請選擇完整的標點符號",
          duration: 3000,
        });
        return;
      }

      this.$emit("submit", {
        result: this.result,
        index: this.data.index,
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.sound-adjust-dialog {
  .word-wrapper {
    display: flex;
    flex-wrap: wrap;

    .word {
      margin: 8px 0;
    }

    .tone {
      margin-bottom: 8px;
    }

    .punctuation-group {
      display: flex;
      flex-direction: column;
      gap: 8px;

      li {
        margin-right: 12px;
      }

      .el-select {
        width: 100px;
      }
    }
  }
}
</style>
