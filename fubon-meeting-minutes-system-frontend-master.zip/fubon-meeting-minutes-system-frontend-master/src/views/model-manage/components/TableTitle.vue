<template>
  <div class="table-title">
    <div class="left">
      <p class="title">
        <slot name="title" />
      </p>
      <span class="total">
        <slot name="total" />
      </span>
    </div>

    <slot></slot>
  </div>
</template>

<script>
export default {
  name: "TableTitle",
};
</script>

<style scoped lang="scss">
.table-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  color: #606266;
  box-sizing: border-box;
  padding: 12px 0;

  .title {
    margin-right: 8px;
  }

  .total {
    font-size: 14px;
  }
}
</style>
