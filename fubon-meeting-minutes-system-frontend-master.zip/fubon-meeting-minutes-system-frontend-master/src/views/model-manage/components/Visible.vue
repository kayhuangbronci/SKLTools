<template>
  <transition name="slide-fade">
    <div v-show="shouldDisplay">
      <slot></slot>
    </div>
  </transition>
</template>

<script>
export default {
  name: "Visible",
  props: {
    whenHidden: {
      required: true,
      type: String,
      default: "",
    },
  },
  data() {
    return {
      shouldDisplay: false,
    };
  },
  created() {
    window.addEventListener("scroll", this.trigger, { passive: true });
  },
  beforeDestroy() {
    window.removeEventListener("scroll", this.trigger);
  },
  methods: {
    trigger() {
      this.shouldDisplay = !this.inViewport(this.whenHidden);
    },
    inViewport(el) {
      const rect = document.querySelector(el);
      if (rect === null) {
        return false;
      }
      const rectPosition = rect.getBoundingClientRect();
      const windowHeight =
        window.innerHeight || document.documentElement.clientHeight;
      const windowWidth =
        window.innerWidth || document.documentElement.clientWidth;

      const vertInView =
        rectPosition.top <= windowHeight &&
        rectPosition.top + rectPosition.height >= 0;
      const horInView =
        rectPosition.left <= windowWidth &&
        rectPosition.left + rectPosition.width >= 0;

      return vertInView && horInView;
    },
  },
};
</script>

<style scoped></style>
