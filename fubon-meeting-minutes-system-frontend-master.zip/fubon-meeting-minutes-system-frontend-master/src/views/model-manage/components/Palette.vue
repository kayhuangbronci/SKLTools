<template>
  <div
    class="palette-component"
    :style="{ bottom: bottom + 'px', width: width + 'px' }"
  >
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: "Palette",
  props: {
    width: {
      type: Number,
      default: 198,
    },
  },
  data() {
    return {
      bottom: 150,
    };
  },
  computed: {
    progress() {
      return this.$store.getters.progress;
    },
  },
  watch: {
    progress() {
      this.changePosition();
    },
  },
  created() {
    if (this.progress) {
      this.changePosition();
    }
  },
  methods: {
    changePosition() {
      this.bottom = 120 + this.progress.length * 36;
    },
  },
};
</script>

<style scoped lang="scss">
.palette-component {
  position: fixed;
  padding: 6px 12px;
  right: 36px;
  border-radius: 12px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  background-color: #f7f7f7;
  z-index: 10001;
  transition: bottom 0.3s;
}
</style>
