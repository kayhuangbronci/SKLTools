<template>
  <p>
    {{
      isFloat(to) ? count.toFixed(2).toLocaleString() : count.toLocaleString()
    }}
  </p>
</template>

<script>
export default {
  name: "Count",
  props: {
    to: {
      required: true,
      type: Number,
      default: 0,
    },
  },
  data() {
    return {
      count: 0,
      interval: null,
    };
  },
  computed: {
    increment() {
      return Math.ceil(this.to / 20);
    },
  },
  mounted() {
    this.interval = setInterval(this.tick, 20);
  },
  methods: {
    tick() {
      if (this.count + this.increment >= this.to) {
        this.count = this.to;
        return clearInterval(this.interval);
      }

      return (this.count += this.increment);
    },
    isFloat(n) {
      return Number(n) === n && n % 1 !== 0;
    },
  },
};
</script>

<style scoped></style>
