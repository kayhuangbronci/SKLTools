<template>
  <div class="empty-block">
    <div class="title">{{ !loading ? "目前暫無資料" : "努力讀取中..." }}</div>
    <div>
      <img
        v-if="!loading"
        src="../../../assets/no-data.png"
        alt="No data available"
      />
      <img v-else src="../../../assets/loading.png" alt="No data available" />
    </div>
  </div>
</template>

<script>
export default {
  name: "NoData",
  props: {
    loading: {
      default: false,
      type: Boolean,
      required: true,
    },
  },
};
</script>

<style scoped lang="scss">
.empty-block {
  padding: 36px 0;
  text-align: center;

  .title {
    font-size: 36px;
    color: #909399;
  }
}
</style>
