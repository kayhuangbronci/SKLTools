<template>
  <div class="vocabulary-block">
    <div class="container">
      <breadcrumb>
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>模型管理</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ name: 'ModelManageVocabulary' }"
            >用戶詞庫</el-breadcrumb-item
          >
        </el-breadcrumb>

        <template #right>
          <el-button
            type="text"
            class="el-icon-question question-button"
            @click="visibility.questionDialog = true"
          />
        </template>
      </breadcrumb>

      <div class="breadcrumb-wrapper flex-between">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>用戶詞庫列表</el-breadcrumb-item>
        </el-breadcrumb>

        <div id="js-button-group">
          <el-button aria-label="重新讀取" @click="handleReset">
            重新讀取
          </el-button>
        </div>
      </div>

      <div class="vocabulary-wrapper">
        <el-tabs
          v-model="active"
          type="border-card"
          @tab-click="handleTabChange"
        >
          <template>
            <el-tab-pane
              v-for="(model, i) in models"
              :key="i"
              :label="model.displayName"
            >
              <el-row :gutter="20">
                <el-col :span="6">
                  <div class="card">
                    <div
                      v-if="status !== null && status.combinerStatus === 0"
                      class="icon icon-0"
                    >
                      <i class="el-icon-error" />
                    </div>
                    <div v-else class="icon icon-0-1">
                      <i class="el-icon-success" />
                    </div>
                    <div class="display-block">
                      <p class="name">合成模組狀態</p>
                      <div v-if="status !== null" class="data">
                        {{ status.combinerStatusDesc }}
                      </div>
                    </div>
                  </div>
                </el-col>

                <el-col :span="6">
                  <div class="card">
                    <div class="icon icon-1">
                      <i class="el-icon-s-marketing" />
                    </div>
                    <div class="display-block">
                      <p class="name">新模型狀態</p>
                      <div class="data">
                        {{ model.modelCombinedStatusDisplay }}
                      </div>
                    </div>
                  </div>
                </el-col>

                <el-col :span="6">
                  <div class="card">
                    <div class="icon icon-2">
                      <i class="el-icon-user-solid" />
                    </div>
                    <div class="display-block">
                      <p class="name">{{ handleUser(model).label }}</p>
                      <div class="data">
                        {{ handleUser(model).user }}
                      </div>
                    </div>
                  </div>
                </el-col>

                <el-col :span="6">
                  <div class="card">
                    <div class="icon icon-3">
                      <i class="el-icon-alarm-clock" />
                    </div>
                    <div class="display-block">
                      <p class="name">最新完成模型合成耗時</p>
                      <div v-if="model.modelCombinedTime === null" class="data">
                        未完成
                      </div>
                      <div v-else-if="model.modelCombinedTime < 0" class="data">
                        N/A
                      </div>
                      <div v-else class="data">
                        <count
                          v-if="key === 1"
                          :to="model.modelCombinedTime"
                        ></count>
                        <template v-else>{{
                          model.modelCombinedTime
                        }}</template>
                      </div>
                    </div>
                  </div>
                </el-col>
              </el-row>

              <table-title>
                <template slot="title">新詞彙</template>
                <div>
                  <el-button
                    type="success"
                    aria-label="創建字詞"
                    :disabled="!currentState.can"
                    @click="handleAdd"
                  >
                    創建字詞
                  </el-button>
                  <el-button
                    type="primary"
                    aria-label="儲存詞彙"
                    :class="[showNeedSaveMessage ? 'flash' : '', 'save-button']"
                    :disabled="!currentState.can"
                    @click="handleAddNewVocabulary"
                    >儲存詞彙
                  </el-button>
                  <el-button
                    v-if="currentState.can"
                    :class="[
                      showNeedStartCombineMessage && !showNeedSaveMessage
                        ? 'flash'
                        : '',
                      'submit-button',
                    ]"
                    aria-label="開始合成"
                    :disabled="
                      !showNeedStartCombineMessage || showNeedSaveMessage
                    "
                    @click="handleSubmit"
                  >
                    {{ currentState.buttonName }}
                  </el-button>
                  <el-button v-else type="danger" @click="handleStop">
                    {{ currentState.buttonName }} <i class="el-icon-warning" />
                  </el-button>
                </div>
              </table-title>

              <div id="js-warning">
                <transition name="fade">
                  <div v-if="showNeedSaveMessage" class="warning">
                    <i class="el-icon-warning"></i>
                    詞庫內容已變更，請確認並點擊「儲存詞彙」套用變更。
                  </div>
                  <div
                    v-else-if="
                      showNeedStartCombineMessage && !showNeedSaveMessage
                    "
                    class="warning"
                  >
                    <i class="el-icon-warning"></i>
                    詞庫內容尚未合成，請確認並點擊「開始合成」。
                  </div>
                </transition>
              </div>

              <div
                class="new-vocabulary-table"
                :class="!currentState.can ? 'mask' : ''"
              >
                <el-table
                  ref="newVocabularyTable"
                  :data="newVocabulary"
                  :default-sort="{ prop: 'id', order: 'descending' }"
                  :default-expand-all="true"
                >
                  <el-table-column type="expand">
                    <template #default="{ row, $index }">
                      <div>
                        <div
                          v-if="row.word.length === 0"
                          style="min-height: 36px; line-height: 36px"
                        >
                          尚未輸入詞彙
                        </div>
                        <div v-else class="sound-block">
                          <el-button
                            class="primary-button"
                            @click="handleSoundAdjust(row, $index)"
                            >音調調整</el-button
                          >
                          <div class="word-block">
                            <div
                              class="word"
                              v-for="(w, index) in row.word
                                .replaceAll(' ', '')
                                .split('')"
                              :key="index"
                            >
                              <span>{{ w }}</span>
                              <el-input
                                :value="`${row.spell[index].punctuation1}${row.spell[index].punctuation2}${row.spell[index].punctuation3}${row.spell[index].tone}`"
                                style="width: 80px"
                                disabled
                              ></el-input>
                            </div>
                          </div>
                        </div>
                      </div>
                    </template>
                  </el-table-column>

                  <el-table-column
                    type="index"
                    :index="handleIndex"
                    prop="id"
                    label="ID"
                  />
                  <el-table-column prop="word" label="詞彙">
                    <template #default="{ row, $index }">
                      <el-row :gutter="20">
                        <el-col :span="24">
                          <el-input
                            v-model="row.word"
                            clearable
                            :disabled="!currentState.can"
                            @input="handleUpdateVocabulary(row, $index)"
                          />
                        </el-col>
                      </el-row>
                    </template>
                  </el-table-column>

                  <el-table-column label="詞彙目前狀態">
                    等待加入
                  </el-table-column>

                  <el-table-column label="刪除" width="64">
                    <template #default="{ $index }">
                      <el-button
                        size="mini"
                        type="danger"
                        icon="el-icon-delete"
                        circle
                        aria-label="刪除資料"
                        :disabled="!currentState.can"
                        @click="handleDelete($index)"
                      />
                    </template>
                  </el-table-column>
                </el-table>
              </div>

              <table-title>
                <template slot="title"
                  >{{ models[+active].displayName }}詞彙</template
                >
                <div>
                  <el-button
                    v-if="deleteStatus !== 0"
                    class="seventh-background-color"
                    @click="handleRestoreVocabulary"
                  >
                    取消刪除
                  </el-button>
                  <el-button
                    v-else
                    type="danger"
                    :disabled="!currentState.can"
                    @click="handleDeleteVocabulary"
                    >全部刪除</el-button
                  >
                </div>
              </table-title>

              <div
                class="vocabulary-table"
                :class="!currentState.can ? 'mask' : ''"
              >
                <el-table
                  :data="
                    vocabulary.filter(
                      (data) =>
                        !vocabularySearch ||
                        data.word
                          .toLowerCase()
                          .includes(vocabularySearch.toLowerCase())
                    )
                  "
                  :row-class-name="handleRowClass"
                >
                  <el-table-column width="60px" label="刪除">
                    <template #default="{ row }">
                      <el-checkbox
                        :value="row.state === 2"
                        @change="handleChangeStatus(row)"
                      />
                    </template>
                  </el-table-column>
                  <el-table-column
                    type="index"
                    :index="handleVocabularyIndex"
                    prop="id"
                    label="ID"
                  />
                  <el-table-column label="詞彙" prop="word" />
                  <el-table-column label="現在詞彙狀態" prop="state" sortable>
                    <template #default="{ row }">
                      <div
                        :class="
                          row.currentState === 2
                            ? 'state-color'
                            : row.currentState === 0
                            ? 'state-color-2'
                            : ''
                        "
                      >
                        {{
                          vocabularyStatus.find(
                            (el) => el.state === row.currentState
                          ).display || "-"
                        }}
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="state">
                    <template #header="{}">
                      <div class="search-header">
                        <div class="header">編輯詞彙狀態</div>
                        <div>
                          <el-input
                            v-model="vocabularySearch"
                            placeholder="請搜尋"
                            size="mini"
                          />
                        </div>
                      </div>
                    </template>
                    <template #default="{ row }">
                      <el-select
                        v-model="row.state"
                        :disabled="!currentState.can"
                      >
                        <el-option
                          v-if="row.currentState !== 1"
                          :value="0"
                          label="等待加入"
                        />
                        <el-option
                          v-if="row.currentState === 1"
                          :value="1"
                          label="已加入"
                        />
                        <el-option :value="2" label="等待移除" />
                      </el-select>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
            </el-tab-pane>
          </template>
        </el-tabs>
      </div>
    </div>

    <visible when-hidden="#js-warning">
      <div v-if="showNeedSaveMessage" class="warning active">
        <i class="el-icon-warning" />
        詞庫內容已變更，請確認並點擊「儲存詞彙」套用變更。
      </div>
      <div
        v-else-if="showNeedStartCombineMessage && !showNeedSaveMessage"
        class="warning active"
      >
        <i class="el-icon-warning" />
        詞彙已有變更但尚未進行合成，請確認後點擊開始合成。
      </div>
    </visible>

    <visible when-hidden="#js-button-group">
      <palette :width="240">
        <el-button
          icon="el-icon-top"
          circle
          class="fifth-background-color custom-button"
          aria-label="置頂"
          @click="handleScrollToTop"
        />
        <el-button
          icon="el-icon-refresh"
          class="primary-background-color custom-button"
          circle
          aria-label="重新讀取"
          @click="handleReset"
        />
        <el-button
          icon="el-icon-plus"
          type="success"
          aria-label="創建字詞"
          :disabled="!currentState.can"
          circle
          @click="handleAdd"
        />
        <el-button
          type="primary"
          icon="el-icon-position"
          aria-label="儲存詞彙"
          :class="[showNeedSaveMessage ? 'flash' : '', 'save-button']"
          :disabled="!currentState.can"
          circle
          @click="handleAddNewVocabulary"
        />
        <el-button
          v-if="currentState.can"
          icon="el-icon-s-promotion"
          :class="[
            showNeedStartCombineMessage && !showNeedSaveMessage ? 'flash' : '',
            'submit-button',
            'sixth-background-color',
          ]"
          circle
          :disabled="showNeedSaveMessage"
          aria-label="開始合成"
          @click="handleSubmit"
        />
        <el-button
          v-else
          circle
          icon="el-icon-warning"
          type="danger"
          aria-label="取消合成"
          @click="handleStop"
        />
      </palette>
    </visible>

    <question-dialog
      :dialog-visible="visibility.questionDialog"
      title="用戶詞庫說明"
      @close="visibility.questionDialog = false"
    />

    <sound-adjust-dialog
      v-if="visibility.soundAdjustDialog"
      :dialog-visible="visibility.soundAdjustDialog"
      @close="visibility.soundAdjustDialog = false"
      @submit="handleSoundAdjustSubmit"
      :data="currentVocabulary"
    />
  </div>
</template>

<script>
import {
  Palette,
  Visible,
  TableTitle,
  Count,
  SoundAdjustDialog,
} from "./components";
import QuestionDialog from "@/components/QuestionDialog.vue";
import {
  getVocabularyList,
  getVocabulary,
  updateVocabulary,
  updateVocabularyModel,
} from "@/api/model-manage";
import throttle from "lodash/throttle";
import { getWorkers } from "@/api/system";

export default {
  name: "Vocabulary",
  components: {
    Palette,
    Visible,
    TableTitle,
    Count,
    QuestionDialog,
    SoundAdjustDialog,
  },
  data() {
    return {
      stateMachine: [
        // combineState 0: 未建立 1: 就緒 2: 等待合成 3: 合成中 4: 更新中 5: 等待取消
        { combineState: [0, 1], buttonName: "開始合成", can: true },
        {
          combineState: [2, 3, 4, 5],
          buttonName: "取消合成",
          can: false,
        },
      ],
      models: [],
      newVocabulary: [],
      vocabulary: [],
      vocabularyStatus: [],
      vocabularySearch: "",
      active: "0",
      timer: null,
      key: 0,
      deleteStatus: 0,
      status: null,
      visibility: {
        soundAdjustDialog: false,
        questionDialog: false,
      },
      currentVocabulary: {
        index: -1,
        word: "",
        spell: [],
      },
    };
  },
  computed: {
    currentNewVocabularyLength() {
      return this.newVocabulary.length;
    },
    currentVocabularyLength() {
      return this.vocabulary.length;
    },
    currentModel() {
      return this.models[+this.active];
    },
    currentState() {
      return (
        this.stateMachine.find((el) =>
          el.combineState.includes(this.currentModel?.modelCombinedStatus)
        ) || this.stateMachine[0]
      );
    },
    showNeedSaveMessage() {
      // Edit new vocabulary table or update original table will show message
      return (
        this.newVocabulary.filter((el) => el.word.length !== 0).length > 0 ||
        this.vocabulary.filter((el) => el.currentState !== el.state).length > 0
      );
    },
    showNeedStartCombineMessage() {
      return this.currentModel?.needStartCombine === 1;
    },
  },
  beforeDestroy() {
    if (this.timer !== null) {
      clearTimeout(this.timer);
    }
  },
  created() {
    this.key++;
    setTimeout(() => (this.key = 0), 3000);
    this.handleInit();
    this.handleGetServices();
    this.handleTimeout();
  },
  methods: {
    handleTimeout() {
      // Refresh model state
      this.timer = setTimeout(() => {
        this.handleInit(false);
        this.handleGetServices();
        this.handleTimeout();
      }, 10000);
    },
    async handleInit(addVocabulary = true) {
      const { data } = await getVocabularyList();
      this.models = data;
      if (addVocabulary) {
        await this.handleGetVocabulary();
      }
    },
    async handleGetServices() {
      const { data } = await getWorkers();
      const { combinerStatusDesc, combinerStatus } = data[0];
      this.status = { combinerStatus, combinerStatusDesc };
    },
    async handleGetVocabulary() {
      const { data } = await getVocabulary({
        modelName: this.currentModel.modelName,
      });
      data[0].vocabs.forEach((el) => (el.currentState = el.state));
      this.vocabulary = data[0].vocabs.reverse();
      this.vocabularyStatus = data[0].vocabStates;
      this.handleAdd();
    },
    handleAdd() {
      if (this.currentNewVocabularyLength + this.currentVocabularyLength < 64) {
        this.newVocabulary.push({ word: "", state: 0, prob: 1.0, spell: [] });
        this.handleFocusRow();
      } else {
        this.$message({
          message: "已達總數量上限64，請移除詞詞彙才可進行新增。",
          type: "warning",
          duration: 1000,
        });
      }
    },
    handleFocusRow() {
      this.$nextTick(() => {
        const firstChildLayer =
          this.$refs.newVocabularyTable[+this.active].$children;
        const secondChildLayer =
          firstChildLayer?.[firstChildLayer.length - 1]?.$children[1]
            ?.$children[0]?.$children[0]?.$children[0];
        setTimeout(() => {
          secondChildLayer?.$refs?.input?.focus();
        }, 600);
      });
    },
    handleIndex(index) {
      return this.currentNewVocabularyLength - index;
    },
    handleVocabularyIndex(index) {
      return this.currentVocabularyLength - index;
    },
    handleDelete(index) {
      this.newVocabulary.splice(this.currentNewVocabularyLength - 1 - index, 1);
    },
    handleRowClass({ row }) {
      if (row.currentState !== row.state) return "diff-color";
    },
    handleTabChange() {
      this.handleReset();
    },
    handleReset: throttle(function () {
      this.newVocabulary = [];
      this.handleInit();
    }, 800),
    async handleAddNewVocabulary() {
      const newVocabulary = this.newVocabulary.filter(
        (el) => el.word.length !== 0
      );
      const v = this.vocabulary.filter((el) => el.currentState !== el.state);
      v.forEach(() => delete v.currentState);
      const vocabulary = [...newVocabulary, ...v];
      const modelName = this.currentModel.modelName;
      const { data, code } = await updateVocabulary({
        modelName,
        vocabs: vocabulary,
      });
      data[0].vocabs.forEach((el) => (el.currentState = el.state));
      this.vocabulary = data[0].vocabs;

      if (code === 200) {
        this.handleReset();
        this.$message({
          message: "儲存成功",
          type: "success",
          duration: 1000,
        });
        return;
      }

      this.$message({
        message: "儲存失敗",
        type: "error",
        duration: 3000,
      });
    },
    handleUpdateVocabulary(data, index) {
      const idx = this.handleGetNewVocabularyIndex(index);

      if (!this.newVocabulary[idx]) return;

      const { word } = data;

      const res = [];
      for (let w of word.replaceAll(" ", "")) {
        res.push({
          word: w,
          punctuation1: "",
          punctuation2: "",
          punctuation3: "",
          tone: "",
        });
      }

      this.newVocabulary[idx].spell = res;
    },
    async handleSubmit() {
      const modelName = this.currentModel.modelName;
      const { code } = await updateVocabularyModel({
        modelName,
        newStatus: "start",
      });

      if (code === 200) {
        this.handleReset();
        this.$message({
          message: "提交成功",
          type: "success",
          duration: 1000,
        });
      } else {
        this.$message({
          message: "提交失敗",
          type: "error",
          duration: 3000,
        });
      }
    },
    async handleStop() {
      const { code } = await updateVocabularyModel({
        modelName: this.currentModel.modelName,
        newStatus: "cancel",
      });
      if (code === 200) {
        this.handleReset();

        this.$message({
          message: "取消成功",
          type: "success",
          duration: 1000,
        });
      } else {
        this.$message({
          message: "取消失敗",
          type: "error",
          duration: 3000,
        });
      }
    },
    handleChangeStatus(row) {
      row.state = row.state === 2 ? row.currentState : 2;
    },
    handleRestoreVocabulary() {
      this.deleteStatus = 0;
      this.vocabulary.map((el) => (el.state = el.currentState));
    },
    handleDeleteVocabulary() {
      this.deleteStatus = 1;
      this.vocabulary.map((el) => (el.state = 2));
    },
    handleTime(time) {
      if (time === null) return "未完成";
      return time;
    },
    handleUser(model) {
      const {
        lastCombSubmitTime,
        lastCombCancelTime,
        lastCombSubmitUser,
        lastCombCancelUser,
      } = model;

      if (lastCombCancelTime === null && lastCombSubmitTime === null) {
        return { label: "提交模型合成用戶", user: "未建立" };
      }

      if (lastCombCancelTime !== null && lastCombSubmitTime !== null) {
        return Date.parse(lastCombSubmitTime) > Date.parse(lastCombCancelTime)
          ? { label: "提交模型合成用戶", user: lastCombSubmitUser }
          : { label: "取消模型合成用戶", user: lastCombCancelUser };
      }

      if (lastCombSubmitTime !== null && lastCombCancelTime === null) {
        return { label: "提交模型合成用戶", user: lastCombSubmitUser };
      } else {
        return { label: "取消模型合成用戶", user: lastCombCancelUser };
      }
    },
    handleScrollToTop() {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    },
    handleSoundAdjust(data, index) {
      this.currentVocabulary.word = data.word;
      this.currentVocabulary.index = index;
      this.currentVocabulary.spell = data.spell;
      this.visibility.soundAdjustDialog = true;
    },
    handleSoundAdjustSubmit({ index, result }) {
      const idx = this.handleGetNewVocabularyIndex(index);

      if (this.newVocabulary[idx]) {
        this.newVocabulary[idx].spell = result;
        this.visibility.soundAdjustDialog = false;
      }
    },
    handleGetNewVocabularyIndex(index) {
      return this.currentNewVocabularyLength - 1 - index;
    },
  },
};
</script>

<style scoped lang="scss">
.vocabulary-block {
  position: relative;
}

#js-button-group {
  margin-bottom: 12px;
}

.custom-button {
  color: #ffffff;

  .is-disabled {
    background-color: #ffa025;
  }

  &:hover {
    color: #ffffff;
  }
}

.vocabulary-wrapper {
  padding-bottom: 36px;
}

.card {
  background-color: #ffffff;
  height: 90px;
  margin-bottom: 12px;
  box-shadow: 4px 4px 40px rgba(0, 0, 0, 0.06);
  display: flex;
  justify-content: space-between;

  .display-block {
    color: #5c5c5c;
    font-weight: bold;
    display: flex;
    justify-content: center;
    flex-direction: column;
    padding-left: 12px;
    padding-right: 12px;
    min-width: 180px;
    max-width: 240px;
    box-sizing: border-box;

    .name {
      color: #8c8c8c;
      padding-bottom: 8px;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
      font-size: 14px;
    }

    .data {
      font-family: Helvetica Neue, sans-serif;
      letter-spacing: 1px;
      min-height: 18px;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
    }
  }

  .icon {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 64px;
    padding: 16px;
    transition: all 0.3s;

    &.icon-0 {
      color: #e1abff;
    }

    &.icon-0-1 {
      color: #70f18a;
    }

    &.icon-1 {
      color: #66a7e7;
    }

    &.icon-2 {
      color: #2eb799;
    }

    &.icon-3 {
      color: #f3d08e;
    }
  }

  &:hover {
    .icon {
      color: #ffffff !important;

      &.icon-0 {
        background-color: #e1abff;
      }

      &.icon-0-1 {
        background-color: #70f18a;
      }

      &.icon-1 {
        background-color: #66a7e7;
      }

      &.icon-2 {
        background-color: #2eb799;
      }

      &.icon-3 {
        background-color: #f3d08e;
      }
    }
  }
}

.sixth-background-color,
.seventh-background-color {
  color: #ffffff;
}

.new-vocabulary-table {
  box-shadow: 4px 4px 40px rgba(0, 0, 0, 0.06);
  margin-bottom: 24px;
  padding: 12px 24px;
}

.vocabulary-table {
  box-shadow: 4px 4px 40px rgba(0, 0, 0, 0.06);
  padding: 12px 24px;
}

.sound-block {
  display: flex;
  align-items: flex-start;
  gap: 12px;

  .word-block {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
  }

  .word {
    display: flex;
    align-items: center;
    gap: 4px;

    span {
      display: block;
      width: 16px;
    }
  }
}

.warning {
  height: 24px;
  font-size: 12px;
  line-height: 24px;
  margin-bottom: 12px;
  padding-left: 8px;
  background-color: #fceeed;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
  color: #ff4949;

  i {
    vertical-align: middle;
  }

  &.active {
    position: fixed;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 1160px;
    margin-top: 12px;
  }
}

.state-color {
  color: #f988a6;
}

.state-color-2 {
  color: #66a7e7;
}

.search-header {
  display: flex;
  justify-content: space-between;
  align-items: center;

  .header {
    width: 200px;
  }
}

@keyframes changeSaveButton {
  from {
    transform: scale(0.98);
    background-color: #38659f;
    border-color: #38659f;
  }
  to {
    transform: scale(1.02);
    background-color: #a8d9ff;
    border-color: #a8d9ff;
  }
}

@keyframes changeSubmitButton {
  from {
    transform: scale(0.98);
    background-color: #88655a;
    border-color: #88655a;
  }
  to {
    transform: scale(1.02);
    background-color: #e5a996;
    border-color: #e5a996;
  }
}

.submit-button {
  &.flash {
    animation-duration: 0.5s;
    animation-name: changeSubmitButton;
    animation-iteration-count: infinite;
    animation-direction: alternate;
  }
}

.save-button {
  &.flash {
    animation-duration: 0.5s;
    animation-name: changeSaveButton;
    animation-iteration-count: infinite;
    animation-direction: alternate;
  }
}

.mask {
  position: relative;

  &:after {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: #f3f6f9;
    opacity: 0.6;
    cursor: not-allowed;
  }
}

::v-deep .el-tabs__header {
  background-color: var(--main-color-green);
  color: #ffffff;

  .el-tabs__item {
    color: #ffffff;

    &:hover {
      color: #ffffff;
    }
  }

  .el-tabs__item.is-active {
    color: var(--main-color-green);

    &:hover {
      color: var(--main-color-green);
    }
  }
}
</style>
