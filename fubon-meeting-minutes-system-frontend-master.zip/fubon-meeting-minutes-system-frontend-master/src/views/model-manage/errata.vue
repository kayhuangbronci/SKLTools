<template>
  <div class="errata-block">
    <div class="container">
      <breadcrumb>
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>模型管理</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ name: 'ModelManageErrata' }"
            >勘誤表</el-breadcrumb-item
          >
        </el-breadcrumb>
      </breadcrumb>

      <export></export>

      <div class="title-block flex-between">
        <p>勘誤字列表</p>

        <div id="js-button-group">
          <el-button
            :disabled="resetDisable"
            aria-label="重新讀取"
            @click="handleReset"
          >
            重新讀取
          </el-button>
          <el-button
            :disabled="submitDisable"
            aria-label="儲存變更"
            @click="handleSubmit"
            class="primary-button"
          >
            儲存變更
          </el-button>
          <el-button
            type="success"
            aria-label="創建字詞"
            @click="handleAdd"
            class="third-button"
          >
            創建字詞
          </el-button>
        </div>
      </div>

      <div class="errata-wrapper">
        <el-tabs
          v-model="active"
          type="border-card"
          @tab-click="handleTabChange"
        >
          <no-data v-if="loading" :loading="loading" />
          <template v-else>
            <el-tab-pane
              v-for="(d, key) in errata"
              :key="key"
              :label="d.displayName"
            >
              <div class="total">
                數量 {{ currentErrataLength }} / {{ d.maxFixbookSize }}
              </div>
              <el-table
                ref="errataTableRef"
                :data="d.fixbook"
                style="width: 100%"
                :default-sort="{ prop: 'id', order: 'descending' }"
              >
                <el-table-column
                  type="index"
                  :index="handleIndex"
                  prop="id"
                  label="編號"
                  width="64"
                />
                <el-table-column prop="data" width="500" label="修正前文字">
                  <template #default="{ row }">
                    <el-input
                      :class="[row.duplicate && 'duplicate']"
                      v-model="row.x"
                      @input="handleFindDuplicate"
                      clearable
                    />
                  </template>
                </el-table-column>
                <el-table-column prop="data" width="500" label="修正後文字">
                  <template #default="{ row }">
                    <el-input v-model="row.o" clearable />
                  </template>
                </el-table-column>
                <el-table-column label="刪除" width="64">
                  <template #default="{ $index }">
                    <el-button
                      size="mini"
                      icon="el-icon-close"
                      circle
                      aria-label="刪除資料"
                      class="third-button"
                      style="padding: 0 !important; font-size: 14px"
                      @click="handleDelete($index)"
                    />
                  </template>
                </el-table-column>
              </el-table>
            </el-tab-pane>
          </template>
        </el-tabs>
      </div>
    </div>

    <visible when-hidden="#js-button-group">
      <palette>
        <el-button
          icon="el-icon-top"
          circle
          class="fifth-button"
          style="color: #ffffff"
          aria-label="置頂"
          title="置頂"
          @click="handleScrollToTop"
        />
        <el-button
          icon="el-icon-refresh"
          :disabled="resetDisable"
          circle
          aria-label="重新讀取"
          title="重新讀取"
          @click="handleReset"
        />
        <el-button
          icon="el-icon-position"
          class="primary-button"
          circle
          :disabled="submitDisable"
          title="儲存變更"
          aria-label="儲存變更"
          @click="handleSubmit"
        />
        <el-button
          icon="el-icon-plus"
          class="third-button"
          type="success"
          circle
          title="創建創建"
          aria-label="創建字詞"
          @click="handleAdd"
        />
      </palette>
    </visible>
  </div>
</template>

<script>
import { Palette, Visible, NoData, Export } from "./components";
import { getErrata, updateErrata } from "@/api/model-manage";

export default {
  name: "Errata",
  components: { Palette, Visible, NoData, Export },
  data() {
    return {
      errata: [],
      active: "0",
      resetDisable: false,
      submitDisable: false,
      loading: true,
    };
  },
  computed: {
    currentErrata() {
      return this.errata[+this.active];
    },
    currentErrataLength() {
      return this.currentErrata.fixbook.length;
    },
    currentErrataDuplicate() {
      return this.currentErrata.fixbook.some(({ duplicate }) => duplicate);
    },
  },
  created() {
    this.handleInit();
  },
  methods: {
    async handleInit() {
      const { data } = await getErrata();
      const errata = data.map((item) => ({
        ...item,
        fixbook: item.fixbook.map((fixbookItem) => ({
          ...fixbookItem,
          duplicate: false,
        })),
      }));
      this.errata = errata;
      this.loading = false;
      this.handleAdd();
      this.handleFindDuplicate();
    },
    handleAdd() {
      if (this.currentErrataLength === 0) {
        this.currentErrata.fixbook.push({
          id: 1,
          o: "",
          x: "",
          duplicate: false,
        });
        this.handleFocusRow();

        return;
      }
      const maxIndex = this.currentErrataLength - 1;
      const nextIndex = this.currentErrata.fixbook[maxIndex].id + 1;
      // check exceed the maxSize
      if (this.currentErrata.maxFixbookSize < nextIndex) return;

      this.currentErrata.fixbook.push({
        id: nextIndex,
        o: "",
        x: "",
        duplicate: false,
      });

      this.handleFocusRow();
    },
    handleScrollToTop() {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    },
    handleFocusRow() {
      this.$nextTick(() => {
        const firstChildLayer =
          this.$refs.errataTableRef[+this.active].$children;
        const secondChildLayer =
          firstChildLayer[firstChildLayer.length - 1].$children;
        setTimeout(() => {
          if (secondChildLayer[0].$children[0]) {
            secondChildLayer[0].$children[0]?.focus();
            return;
          }

          secondChildLayer[1].$children[0]?.focus();
        }, 600);
      });
    },
    handleReset() {
      this.resetDisable = true;
      this.handleInit();
      setTimeout(() => (this.resetDisable = false), 400);
    },
    async handleSubmit() {
      this.submitDisable = true;
      const result = this.handleCheckData();

      if (result === null) {
        this.submitDisable = false;

        return;
      }

      const { code } = await updateErrata(result);
      if (code === 200) {
        this.$message({
          type: "success",
          message: "更新成功",
          duration: 1000,
        });
      } else {
        this.$message({
          type: "error",
          message: "更新失敗",
          duration: 3000,
        });
      }

      this.submitDisable = false;
    },
    handleCheckData() {
      if (this.currentErrataDuplicate) {
        this.$message({
          type: "error",
          message: "勘誤表有重複的字詞",
          duration: 3000,
        });

        return null;
      }
      const updateData = JSON.parse(JSON.stringify(this.currentErrata)); // deep clone
      const maxSize = updateData.maxFixbookSize;

      if (updateData.fixbook.length > maxSize) {
        this.$message({
          type: "error",
          message: `${updateData.displayName}勘誤表最大上限為${maxSize}`,
          duration: 3000,
        });
      }

      // remove redundant parameters
      delete updateData.description;
      delete updateData.maxFixbookSize;
      delete updateData.displayName;

      // expect getting false callback, callback is true means got whitespace
      const check = updateData.fixbook.some((el, index) => {
        el.o = el.o.trim();
        el.x = el.x.trim();
        if (el.o.length === 0 || el.x.length === 0) {
          updateData.fixbook.splice(index, 1);
        }
        const condition = el.o.search(" ") !== -1 || el.x.search(" ") !== -1;
        if (condition) {
          this.$message({
            type: "error",
            message: `ID:${index + 1}含有空格，不符合格式`,
            duration: 3000,
          });
        }

        return condition;
      });

      if (!check) {
        return updateData;
      }

      return null;
    },
    handleDelete(index) {
      this.errata[+this.active].fixbook.splice(
        this.currentErrataLength - 1 - index,
        1
      );
      this.handleFindDuplicate();
    },
    handleTabChange() {
      const errata = this.currentErrata;
      if (
        this.currentErrataLength !== 0 &&
        errata.fixbook[this.currentErrataLength - 1].o !== "" &&
        errata.fixbook[this.currentErrataLength - 1].x !== ""
      ) {
        this.handleAdd();
        return;
      }
      if (this.currentErrataLength === 0) {
        errata.fixbook.push({ id: 1, o: "", x: "", duplicate: false });
        this.handleFocusRow();
        return;
      }
      this.handleFocusRow();
    },
    handleIndex(index) {
      return this.currentErrataLength - index;
    },
    handleFindDuplicate() {
      const errataMap = new Map();

      this.currentErrata.fixbook.forEach(({ x }) => {
        if (x.trim().length === 0) return;

        errataMap.has(x)
          ? errataMap.set(x, errataMap.get(x) + 1)
          : errataMap.set(x, 1);
      });

      this.currentErrata.fixbook.forEach(({ x }, index) => {
        if (errataMap.get(x) > 1) {
          this.handleUpdateDuplicate(index, true);
        } else {
          this.handleUpdateDuplicate(index, false);
        }
      });
    },
    handleUpdateDuplicate(index, duplicate = true) {
      this.currentErrata.fixbook.splice(index, 1, {
        ...this.currentErrata.fixbook[index],
        duplicate,
      });
    },
  },
};
</script>

<style scoped lang="scss">
.errata-block {
  min-height: 100vh;
  position: relative;

  .title-block {
    p {
      font-size: 16px;
      font-weight: bold;
    }
  }

  .total {
    font-size: 14px;
    color: #606266;
    text-align: left;
    margin-bottom: 4px;
  }

  .container {
    min-height: 100vh;
  }

  #js-button-group {
    margin-bottom: 12px;
  }

  .custom-button {
    color: #ffffff;

    .is-disabled {
      background-color: #ffa025;
    }

    &:hover {
      color: #ffffff;
    }
  }

  .errata-wrapper {
    margin-bottom: 32px;
  }

  .errata-content {
    width: 100%;
  }

  ::v-deep .el-tabs__header {
    background-color: var(--main-color-green);
    color: #ffffff;

    .el-tabs__item {
      color: #ffffff;

      &:hover {
        color: #ffffff;
      }
    }

    .el-tabs__item.is-active {
      color: var(--main-color-green);

      &:hover {
        color: var(--main-color-green);
      }
    }
  }

  ::v-deep .duplicate .el-input__inner {
    border-color: red !important;
  }
}
</style>
