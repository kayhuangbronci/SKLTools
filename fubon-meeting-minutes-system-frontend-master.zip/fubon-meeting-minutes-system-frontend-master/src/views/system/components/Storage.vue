<template>
  <div class="storage-block">
    <div class="title">儲存空間</div>

    <div class="storage-count">
      儲存容量：已使用 {{ handleStorageTransform(total - free) }}
      {{ handleUnitTransform(total - free) }} 共 ({{
        handleStorageTransform(total)
      }}
      {{ handleUnitTransform(total) }})
    </div>

    <div class="progress-bar" :style="usageColor">
      <div class="percent-min" :style="{ left: minStorageTH + '%' }" />
      <div class="percent-max" :style="{ left: maxStorageTH + '%' }" />
      <div class="percent" :style="percentTextPosition">{{ usage }}%</div>
    </div>

    <el-divider></el-divider>
  </div>
</template>

<script>
import { getStorage } from "@/api/system";

export default {
  name: "Storage",
  data() {
    return {
      total: 0,
      free: 0,
      status: 0,
      usage: 0,
      maxStorageTH: 0,
      minStorageTH: 0,
    };
  },
  computed: {
    percentTextPosition() {
      const usage = this.usage;
      if (usage <= 2.5) {
        return {
          left: usage + "%",
          top: "50%",
          transform: `translate(20%, -45%)`,
          color: "#606266",
        };
      }
      return {
        left: usage + "%",
        top: "50%",
        transform: `translate(-105%, -45%)`,
        color: "#ffffff",
      };
    },
    usageColor() {
      const color =
        this.usage >= this.maxStorageTH
          ? "#f56c6c"
          : this.usage >= this.minStorageTH
          ? "#e6a23c"
          : "#459b9c";

      return {
        "background-image": `linear-gradient(to right,
          ${color} ${this.usage}%,
          #efefef ${this.usage + 0.1}%,
          #efefef 100%)`,
      };
    },
  },
  created() {
    this.handleGetStorage();
  },
  methods: {
    async handleGetStorage() {
      const { data } = await getStorage();
      Object.keys(data[0]).forEach((key) => {
        this[key] = data[0][key];
      });
    },
    handleStorageTransform(value) {
      if (value / 1024 / 1024 > 1) {
        return (value / 1024 / 1024).toFixed(2);
      }

      return (value / 1024).toFixed(2);
    },
    handleUnitTransform(value) {
      if (value / 1024 / 1024 > 1) {
        return "TB";
      }
      return "GB";
    },
  },
};
</script>

<style scoped lang="scss">
.storage-block {
  .title {
    font-size: 16px;
    color: #000000;
    font-weight: bold;
    margin-bottom: 12px;
  }

  .progress-bar {
    border-radius: 4px;
    height: 20px;
    border: 1px solid #dcdfe6;
    position: relative;

    .percent {
      position: absolute;
      color: white;
      font-size: 12px;
      line-height: 20px;
    }

    .percent-min,
    .percent-max {
      position: absolute;
      top: 0;
      width: 2px;
      height: 100%;
    }

    .percent-min {
      background-color: #e6a23c;
    }

    .percent-max {
      background-color: #f56c6c;
    }
  }

  .storage-count {
    font-size: 12px;
    margin-bottom: 12px;
    color: #606266;
  }
}
</style>
