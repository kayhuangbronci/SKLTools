<template>
  <div class="text-export-block">
    <div class="title">逐字稿輸出</div>

    <el-form ref="textFormRef" :model="textForm" label-position="top">
      <el-form-item prop="time">
        <template #label>
          <span class="label">啟用段落時間(設定逐字稿輸出段落時間之間距)</span>
        </template>
        <div style="margin-bottom: 8px">
          <el-switch
            v-model="active"
            active-color="#459b9c"
            inactive-color="#ff4949"
            :inactive-value="false"
            :active-value="true"
          />
        </div>
        <el-time-picker
          v-model="textForm.time"
          :disabled="!active"
          :picker-options="{ selectableRange: '00:00:00 - 08:59:59' }"
          placement="bottom-start"
        />
      </el-form-item>
      <el-form-item>
        <el-button
          type="success"
          aria-label="送出"
          size="small"
          class="secondary-button"
          @click="handleSubmit"
        >
          套用
        </el-button>
      </el-form-item>
    </el-form>

    <el-divider></el-divider>
  </div>
</template>

<script>
import { updateTextExportDuration } from "@/api/system";
import dayjs from "dayjs";

export default {
  name: "TextExport",
  props: {
    duration: {
      required: true,
      type: Number,
      default: 0,
    },
  },
  data() {
    return {
      active: false,
      textForm: {
        time: "",
      },
    };
  },
  created() {
    this.handleTime();
    if (this.duration > 0) {
      this.active = true;
    }
  },
  methods: {
    handleTime() {
      const d = dayjs();
      let duration = this.duration;
      const hours = Math.floor(duration / 3600);
      duration %= 3600;
      const minutes = Math.floor(duration / 60);
      const seconds = duration % 60;
      this.textForm.time = d
        .hour(hours)
        .minute(minutes)
        .second(seconds)
        .toDate();
    },
    handleSubmit() {
      this.$refs.textFormRef.validate(async (valid) => {
        if (valid) {
          const time = this.textForm.time;
          if (!time) return;

          let duration =
            time.getHours() * 3600 + time.getMinutes() * 60 + time.getSeconds();

          const { code } = await updateTextExportDuration({ duration });
          const successCode = [200, 202];
          if (successCode.includes(code)) {
            this.$message({
              type: "success",
              message: "新增成功",
              duration: 1000,
            });
          } else {
            this.$message({
              type: "error",
              message: "新增失敗",
              duration: 3000,
            });
          }
        }
      });
    },
  },
};
</script>

<style scoped lang="scss">
.text-export-block {
  .title {
    font-size: 16px;
    font-weight: 500;
    margin-bottom: 10px;
  }

  ::v-deep .el-form-item__label {
    padding-bottom: 0;
    .tip {
      margin-bottom: 0;
    }

    .label {
      font-size: 12px;
    }
  }
}
</style>
