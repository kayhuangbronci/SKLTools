<template>
  <div class="version-block">
    <div class="title">版本資訊</div>

    <div>
      <ul class="version-list">
        <li>前端版本：{{ frontendVersion }}</li>
        <li>後端版本：{{ backendVersion }}</li>
        <li>ASR核心：{{ asrKernelVersion }}</li>
        <li>字幕模組：{{ captionMakerVersion }}</li>
      </ul>
    </div>

    <el-divider></el-divider>
  </div>
</template>

<script>
import { getVersion } from "@/api/system";
import constants from "@/utils/constants";

export default {
  name: "Version",
  data() {
    return {
      serverVersion: "",
      asrKernelVersion: "",
      captionMakerVersion: "",
      backendVersion: "",
    };
  },
  computed: {
    frontendVersion() {
      return constants.version || "N/A";
    },
  },
  created() {
    this.handleVersion();
  },
  methods: {
    async handleVersion() {
      const { data } = await getVersion();
      this.serverVersion = data[0].serverVersion;
      this.asrKernelVersion = data[0].asrKernelVersion;
      this.captionMakerVersion = data[0].captionMakerVersion;
      this.backendVersion = data[0].backendVersion;
    },
  },
};
</script>

<style lang="scss" scoped>
.version-block {
  font-size: 14px;
  color: #606266;
  line-height: 24px;

  .title {
    font-size: 16px;
    color: #000000;
    font-weight: bold;
    margin-bottom: 8px;
  }
}
</style>
