<template>
  <div class="task-block">
    <div class="title">任務設定</div>

    <el-form ref="formRef" :model="form" :rules="rules" label-position="top">
      <el-form-item prop="taskPreservedDay" label="保存天數">
        <template #label>
          <span class="label"
            >保存天數<span>&nbsp;&nbsp;(保存最小天數為4)</span></span
          >
        </template>
        <el-input-number
          size="small"
          style="width: 15%"
          :min="4"
          type="number"
          v-model="form.taskPreservedDay"
        ></el-input-number>
      </el-form-item>
      <el-form-item prop="taskCleanUpHour" label="過期任務刪除時間">
        <template #label>
          <span class="label"
            >過期任務刪除時間<span
              >&nbsp;&nbsp;ex: (2表示凌晨兩點會進行刪除)</span
            ></span
          >
        </template>
        <el-input-number
          size="small"
          style="width: 15%"
          :min="0"
          :max="23"
          type="number"
          v-model="form.taskCleanUpHour"
        ></el-input-number>
      </el-form-item>

      <el-button size="small" class="secondary-button" @click="handleSubmit"
        >套用</el-button
      >
    </el-form>

    <el-divider></el-divider>
  </div>
</template>

<script>
import { updateTaskPreservation } from "@/api/system";

export default {
  name: "Task",
  props: {
    task: {
      required: true,
      type: Object,
      default: () => ({}),
    },
  },
  data() {
    return {
      form: {
        taskPreservedDay: 0,
        taskCleanUpHour: 2,
      },
      rules: {
        taskPreservedDay: [
          { required: true, message: "請輸入任務保存天數", trigger: "blur" },
          { type: "number", message: "請輸入數字", trigger: "blur" },
        ],
        taskCleanUpHour: [
          { required: true, message: "請輸入任務保存天數", trigger: "blur" },
          { type: "number", message: "請輸入數字", trigger: "blur" },
        ],
      },
    };
  },
  created() {
    this.form = { ...this.form, ...this.task };
  },
  methods: {
    handleSubmit() {
      this.$refs.formRef.validate(async (valid) => {
        if (valid) {
          const { code } = await updateTaskPreservation(this.form);

          if (code === 200 || code === 202) {
            this.$message({
              type: "success",
              message: "修改成功",
              duration: 1000,
            });
          } else {
            this.$message({
              type: "error",
              message: "修改失敗",
              duration: 3000,
            });
          }
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.task-block {
  .title {
    font-size: 16px;
    font-weight: 500;
    margin-bottom: 10px;
  }

  ::v-deep .el-form-item__label {
    padding-bottom: 0;
    .tip {
      margin-bottom: 0;
    }

    .label {
      span {
        font-size: 12px;
      }
    }
  }
}
</style>
