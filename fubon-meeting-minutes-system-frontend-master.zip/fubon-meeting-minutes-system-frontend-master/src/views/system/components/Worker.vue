<template>
  <div class="worker-block">
    <div class="title">服務狀態</div>

    <ul v-if="!loading" class="worker-list">
      <li>
        <span class="list-name">可執行任務總數：</span
        >{{ service.totalWorkers }}
      </li>
      <li>
        <span class="list-name">現可執行任務數：</span
        >{{ service.availableWorkers }}
      </li>
      <li>
        <span class="list-name">服務執行狀態：</span>
        <span
          :class="
            service.status === 0
              ? 'color-pending'
              : service.status === 1
              ? 'color-success'
              : 'color-fail'
          "
        >
          {{ handleStatus(service.status) }}
        </span>
      </li>
      <li>
        <span class="list-name">可啟用帳號數：</span
        >{{
          service.maxActivatedUsers === 0 ? "無限制" : service.maxActivatedUsers
        }}
      </li>
      <li>
        <span class="list-name">授權有效時間：</span>
        {{ expiredTime }}
      </li>
    </ul>

    <el-skeleton v-else :row="6" style="width: 50%"></el-skeleton>
  </div>
</template>

<script>
import { getWorkers } from "@/api/system";

export default {
  name: "Worker",
  data() {
    return {
      service: {
        totalWorkers: 0,
        availableWorkers: 0,
        status: 3,
        statusDesc: "",
        failureDesc: "",
        licenseExpiredTime: null,
        maxActivatedUsers: 0,
      },
      workerTimer: null,
      loading: true,
    };
  },
  computed: {
    expiredTime() {
      let message = this.service.licenseExpiredTime;

      if (message) {
        const m = new Date(message);
        if (m.getFullYear() >= 2050) {
          return "永久授權";
        } else {
          return m;
        }
      } else {
        return "N/A";
      }
    },
  },
  created() {
    this.handleGetWorkers(1);
    this.handleSetTimeout();
  },
  beforeDestroy() {
    if (this.workerTimer !== null) {
      clearTimeout(this.workerTimer);
      this.workerTimer = null;
    }
  },
  methods: {
    handleSetTimeout() {
      this.workerTimer = setTimeout(() => {
        this.handleGetWorkers();
        this.handleSetTimeout();
      }, 10000);
    },
    async handleGetWorkers() {
      const { data } = await getWorkers();
      Object.keys(this.$data.service).forEach((el) => {
        this.service[el] = data[0][el];
      });
      this.loading = false;
    },
    handleStatus(status) {
      let word = "";
      switch (status) {
        case 0:
          word = "等待服務啟動";
          break;
        case 1:
          word = "服務就緒";
          break;
        case 2:
          word = "服務發生異常";
          break;
        case 3:
          word = "服務重置中";
          break;
        case 4:
          word = "授權認證失敗";
          break;
        default:
          word = "未定義狀態";
          break;
      }
      return word;
    },
  },
};
</script>

<style lang="scss" scoped>
.worker-block {
  .title {
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 8px;
  }

  .worker-list {
    font-size: 14px;
    color: #606266;
    line-height: 24px;

    li {
      display: flex;
      align-items: center;
    }

    .list-name {
      display: block;
      width: 115px;
    }
  }

  .loading-text {
    height: 72px;
    width: 150px;
    font-size: 20px;
    color: #606266;
    line-height: 72px;
    text-align: center;
  }

  .color-success {
    color: var(--main-color-green);
  }

  .color-pending {
    color: #e6a23c;
  }

  .color-progress {
    color: #409eff;
  }
}
</style>
