<template>
  <div class="space-block">
    <div class="title">儲存空間設置</div>

    <el-form
      ref="spaceFormRef"
      :model="spaceForm"
      :rules="spaceRules"
      label-position="top"
    >
      <el-form-item label="自動釋放儲存空間" prop="autoTaskRemove">
        <template #label>
          <span class="label">自動釋放儲存空間</span>
        </template>
        <el-switch
          v-model="spaceForm.autoTaskRemove"
          active-color="#459b9c"
          inactive-color="#ff4949"
          :inactive-value="0"
          :active-value="1"
        />
      </el-form-item>
      <el-form-item v-if="!loading" prop="minStorageTH">
        <template #label>
          <span class="label"
            >告警值：當使用之儲存空間超過以下設定值，系統將進入「儲存空間不足」之狀態。</span
          >
        </template>
        <el-select
          :value="spaceForm.minStorageTH + '%'"
          @change="handleChangeStorage"
        >
          <el-option v-for="l in limit" :key="l" :label="l" :value="l">
            {{ l + "%" }}
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <div class="progress-bar" :style="usageColor">
          <div
            class="percent-min"
            :style="{ left: spaceForm.minStorageTH + '%' }"
          ></div>
          <div
            class="percent-max"
            :style="{ left: spaceForm.maxStorageTH + '%' }"
          ></div>
          <div class="percent" :style="percentTextPosition">
            {{ storageStatus.usage }}%
          </div>
        </div>
      </el-form-item>
      <el-form-item>
        <el-button
          class="secondary-button"
          aria-label="送出"
          size="small"
          @click="handleSubmit"
          >套用</el-button
        >
      </el-form-item>
    </el-form>

    <el-divider></el-divider>
  </div>
</template>

<script>
import { updateLimit, updateAutoReleaseStorage } from "@/api/system";

export default {
  name: "Space",
  props: {
    limits: {
      required: true,
      type: Object,
    },
    storageStatus: {
      required: true,
      type: Object,
    },
    autoTaskRemove: {
      required: true,
      type: Number,
    },
  },
  data() {
    return {
      type: "1",
      spaceForm: {
        minStorageTH: 60,
        maxStorageTH: 90,
        autoTaskRemove: 1,
      },
      spaceRules: {
        minStorageTH: [
          { required: true, message: "請選擇字幕格式", trigger: "change" },
        ],
        autoTaskRemove: [
          {
            required: true,
            message: "請選擇是否自動釋放儲存空間",
            trigger: "change",
          },
        ],
      },
      limit: [60, 65, 70, 75, 80, 85, 90],
      total: 0,
      free: 0,
      status: null,
      loading: false,
    };
  },
  computed: {
    percentTextPosition() {
      const usage = this.storageStatus.usage;
      if (usage <= 2.5) {
        return {
          left: usage + "%",
          top: "50%",
          transform: `translate(20%, -45%)`,
          color: "#606266",
        };
      }
      return {
        left: usage + "%",
        top: "50%",
        transform: `translate(-105%, -45%)`,
        color: "#ffffff",
      };
    },
    usageColor() {
      const usage = this.storageStatus.usage;
      return {
        "background-image": `linear-gradient(to right,
        #459b9c ${usage}%,
        #efefef ${usage + 0.1}%,
        #efefef 100%)`,
      };
    },
  },
  created() {
    this.spaceForm.minStorageTH = this.limits.minStorageTH;
    this.spaceForm.maxStorageTH = this.limits.maxStorageTH;
    this.spaceForm.autoTaskRemove = this.autoTaskRemove;
    this.total = this.storageStatus.total;
    this.free = this.storageStatus.free;
    this.status = this.storageStatus.status;
  },
  methods: {
    handleChangeStorage(val) {
      this.spaceForm.minStorageTH = val;
    },
    async handleSubmit() {
      this.$refs.spaceFormRef.validate(async (valid) => {
        if (valid) {
          const form = this.spaceForm;
          const [resLimit, resAutoRelease] = await Promise.all([
            updateLimit({
              minStorageTH: form.minStorageTH,
              maxStorageTH: form.maxStorageTH,
            }),
            updateAutoReleaseStorage({
              enable: form.autoTaskRemove,
            }),
          ]);
          const successCode = [200, 202];
          if (
            successCode.includes(resLimit.code) &&
            successCode.includes(resAutoRelease.code)
          ) {
            this.$message({
              type: "success",
              message: "修改成功",
              duration: 1000,
            });
          } else {
            this.$message({
              type: "error",
              message: "修改失敗",
              duration: 3000,
            });
          }
        }
      });
    },
  },
};
</script>

<style scoped lang="scss">
.space-block {
  .title {
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 12px;
  }

  ::v-deep .el-form-item__label {
    padding-bottom: 0;
    .tip {
      margin-bottom: 0;
    }

    .label {
      font-size: 12px;
    }
  }

  .progress-bar {
    border-radius: 4px;
    height: 20px;
    border: 1px solid #dcdfe6;
    position: relative;
    box-sizing: border-box;

    .percent {
      position: absolute;
      color: white;
      font-size: 12px;
      line-height: 20px;
    }

    .percent-min,
    .percent-max {
      position: absolute;
      top: 0;
      width: 2px;
      height: 100%;
    }

    .percent-min {
      background-color: #e6a23c;
    }

    .percent-max {
      background-color: #f56c6c;
    }
  }
}
</style>
