<template>
  <div class="restart-block">
    <div class="title">重啟服務</div>

    <p class="tip">
      <span>*</span>
      注意：重啟服務將導致正在進行之任務被強制終止。若確定要繼續進行，請於下方輸入
      <b>“重啟服務”</b> 後點選送出。
    </p>

    <el-form ref="restartFormRef" :rules="restartRules" :model="restartForm">
      <el-form-item prop="check">
        <el-input v-model="restartForm.check" style="width: 200px" />
      </el-form-item>
      <el-form-item>
        <el-button
          v-loading.fullscreen.lock="fullscreenLoading"
          class="danger-button"
          element-loading-background="rgba(0, 0, 0, 0.8)"
          element-loading-spinner="el-icon-loading"
          element-loading-text="重啟中，請耐心等候。"
          aria-label="重啟"
          size="small"
          @click="handleSubmit"
        >
          重啟
        </el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import { restartRequest } from "@/api/system";

export default {
  name: "Restart",
  data() {
    const validateCheck = (_rule, value, callback) => {
      if (value !== "重啟服務") {
        callback(new Error("輸入錯誤"));
      } else {
        callback();
      }
    };
    return {
      restartForm: {
        check: "",
      },
      restartRules: {
        check: [{ required: true, trigger: "blur", validator: validateCheck }],
      },
      fullscreenLoading: false,
    };
  },
  methods: {
    handleSubmit() {
      this.$refs.restartFormRef.validate(async (valid) => {
        if (valid) {
          this.fullscreenLoading = true;
          const { code } = await restartRequest();
          if (code === 200) {
            this.$message({
              type: "success",
              message: "重啟成功",
              duration: 1000,
            });
          } else {
            this.$message({
              type: "error",
              message: "重啟失敗",
              duration: 3000,
            });
          }
          this.restartForm.check = "";
          this.fullscreenLoading = false;
        }
      });
    },
  },
};
</script>

<style scoped lang="scss">
.restart-block {
  .title {
    font-size: 16px;
    font-weight: 500;
    margin-bottom: 10px;
  }
}
</style>
