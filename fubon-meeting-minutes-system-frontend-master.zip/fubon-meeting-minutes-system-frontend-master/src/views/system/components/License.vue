<template>
  <div class="license-block">
    <div class="title">更新授權</div>

    <div class="content">授權核心數：{{ worker === 0 ? "N/A" : worker }}</div>
    <div class="content">授權有效時間：{{ expiredTime }}</div>

    <el-form ref="formRef" :model="form" :rules="rules" label-position="top">
      <el-form-item prop="license">
        <template #label>
          <span class="label">上傳授權檔</span>
        </template>
        <el-row :gutter="4">
          <el-col :span="1.5">
            <el-upload
              ref="uploadRef"
              action=""
              :before-upload="handleBeforeUpload"
              :http-request="handleUpload"
              :file-list="form.license"
              :on-remove="handleRemove"
            >
              <el-button size="small" class="primary-button" aria-label="上傳">
                選擇檔案
              </el-button>
            </el-upload>
          </el-col>
        </el-row>
      </el-form-item>

      <el-form-item>
        <el-button
          v-loading.fullscreen.lock="loading"
          element-loading-text="授權載入中..."
          element-loading-spinner="el-icon-loading"
          element-loading-background="rgba(0, 0, 0, 0.8)"
          class="secondary-button"
          size="small"
          @click="handleSubmit"
          >套用
        </el-button>
      </el-form-item>
    </el-form>

    <el-divider></el-divider>
  </div>
</template>

<script>
import { getLicenseInfo, updateLicenseInfo } from "@/api/system";

export default {
  name: "License",
  data() {
    return {
      licenseExpiredTime: null,
      worker: 0,
      form: {
        license: [],
      },
      rules: {
        license: [
          { required: true, message: "請上傳授權檔", trigger: "change" },
        ],
      },
      loading: false,
      timeout: null,
    };
  },
  computed: {
    expiredTime() {
      let message = this.licenseExpiredTime;

      if (message) {
        const m = new Date(message);
        if (m.getFullYear() >= 2050) {
          return "永久授權";
        } else {
          return m;
        }
      } else {
        return "N/A";
      }
    },
  },
  created() {
    this.handleGetLicenseInfo();
  },
  beforeDestroy() {
    this.handleClearTimeout();
  },
  methods: {
    async handleGetLicenseInfo() {
      this.licenseExpiredTime = null;
      this.worker = 0;
      const { data } = await getLicenseInfo();
      this.licenseExpiredTime = data[0].licenseExpiredTime;
      this.worker = data[0].totalWorkers;
    },
    handleBeforeUpload(file) {
      const fileExtension = /[^.]+$/.exec(file.name)[0];

      if (fileExtension !== "lcs") {
        this.$message({
          type: "error",
          message: "請上傳正確的檔案格式",
          duration: 3000,
        });
        return false;
      }

      this.handleRemove();
      this.$refs.formRef.clearValidate();
    },
    handleUpload({ file }) {
      this.form.license[0] = file;
    },
    handleRemove() {
      this.form.license = [];
    },
    handleSubmit() {
      this.$refs.formRef.validate((valid) => {
        if (valid) {
          this.$confirm(
            "更新授權將會覆寫原有授權內容，更新過程中會中斷正在執行的轉檔任務。是否繼續？",
            "警告",
            {
              confirmButtonText: "確定",
              cancelButtonText: "取消",
              type: "warning",
            }
          )
            .then(async () => {
              this.loading = true;
              const formData = new FormData();
              formData.append("license", this.form.license[0]);
              await updateLicenseInfo(formData);

              this.form.license = [];
              this.$refs.uploadRef.clearFiles();

              this.$message({
                type: "success",
                message: "上傳成功",
                duration: 1000,
              });

              this.timeout = setTimeout(() => {
                this.loading = false;
                this.handleGetLicenseInfo();
                this.handleClearTimeout();
              }, 10000);
            })
            .catch(() => {
              this.$message({
                type: "error",
                message: "已取消更新",
                duration: 3000,
              });

              this.loading = false;
            });
        }
      });
    },
    handleClearTimeout() {
      if (this.timeout) {
        clearTimeout(this.timeout);
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.license-block {
  .title {
    font-size: 16px;
    font-weight: 500;
    margin-bottom: 10px;
  }

  .content {
    font-size: 12px;
    color: #606266;
    line-height: 24px;
    margin-bottom: 12px;
  }

  ::v-deep .el-upload-list__item.is-ready,
  ::v-deep .el-upload-list__item.is-success {
    width: 300px;

    .el-icon-close {
      display: inline-block;
    }
  }

  ::v-deep .el-form-item__label {
    padding-bottom: 0;
    .tip {
      margin-bottom: 0;
    }

    .label {
      font-size: 12px;
    }
  }

  .refresh-button {
    font-size: 20px;
    padding: 0;
    margin-top: 8px;
    color: var(--main-color-green);
  }
}
</style>
