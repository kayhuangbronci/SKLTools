<template>
  <div class="system-status-block">
    <div class="container">
      <breadcrumb>
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>系統管理</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ name: 'SystemStatus' }"
            >系統狀態</el-breadcrumb-item
          >
        </el-breadcrumb>
      </breadcrumb>

      <storage></storage>

      <version></version>

      <worker></worker>
    </div>
  </div>
</template>

<script>
import { Storage, Version, Worker } from "./components";

export default {
  name: "SystemStatus",
  components: {
    Storage,
    Version,
    Worker,
  },
};
</script>

<style lang="scss" scoped>
.system-status-block {
  min-height: calc(100vh - 98px);
}
</style>
