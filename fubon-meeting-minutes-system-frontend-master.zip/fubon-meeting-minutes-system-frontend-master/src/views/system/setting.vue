<template>
  <div class="system-setting-block" v-loading="loading">
    <div class="container">
      <breadcrumb>
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>系統管理</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ name: 'SystemSetting' }"
            >系統設置</el-breadcrumb-item
          >
        </el-breadcrumb>
      </breadcrumb>

      <template v-if="!loading">
        <space
          :limits="{
            minStorageTH: settings.minStorageTH,
            maxStorageTH: settings.maxStorageTH,
          }"
          :storage-status="settings.storageStatus"
          :auto-task-remove="settings.autoTaskRemove"
        ></space>

        <task
          :task="{
            taskPreservedDay: settings.taskPreservedDay,
            taskCleanUpHour: settings.taskCleanUpHour,
          }"
        ></task>

        <license></license>

        <restart></restart>
      </template>
    </div>
  </div>
</template>

<script>
import { getSystemSetting } from "@/api/system";
import { Space, License, Restart, Task } from "./components";

export default {
  name: "SystemSetting",
  components: {
    Space,
    License,
    Restart,
    Task,
  },
  data() {
    return {
      settings: {
        autoTaskRemove: 1,
        storageStatus: {},
        taskPreservedDay: 0,
        taskCleanUpHour: 2,
      },
      loading: true,
    };
  },
  created() {
    this.handleSettingInit();
  },
  methods: {
    async handleSettingInit() {
      const { data } = await getSystemSetting();
      this.settings = data[0];
      this.loading = false;
    },
  },
};
</script>

<style lang="scss" scoped>
.system-setting-block {
  min-height: calc(100vh - 98px);
  padding-bottom: 20px;
}
</style>
