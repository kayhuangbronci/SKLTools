<template>
  <div class="error-page-block">
    <header>
      <nav>
        <div class="container">
          <img src="../../assets/nav-logo.png" alt="Logo" />
        </div>
      </nav>
    </header>
    <div class="content">
      <img src="../../assets/error-page-404.png" alt="Error page 404" />
      <div class="info">網址錯誤或頁面出現問題</div>
      <el-button
        class="redirect-button secondary-button"
        @click="handleRedirect"
        >逐字稿生成系統首頁 &rarr;</el-button
      >
    </div>
  </div>
</template>

<script>
export default {
  name: "Error404",
  computed: {
    role() {
      return this.$store.getters.info.role;
    },
  },
  methods: {
    handleRedirect() {
      if (this.role === "admin") {
        this.$router.push({ path: "/account" });
      } else if (this.role === "maintainer") {
        this.$router.push({ path: "/model-manage/errata" });
      } else {
        this.$router.push({ path: "/generate" });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.error-page-block {
  .content {
    margin-top: 8%;
    display: flex;
    align-items: center;
    flex-direction: column;

    .info {
      margin: 12px 0;
      color: var(--main-font-color);
      font-size: 18px;
    }

    .redirect-button {
      margin-top: 12px;
    }
  }
}
</style>
