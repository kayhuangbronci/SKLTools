<template>
  <div class="file-item-block">
    <ul class="file-item">
      <li class="file-name text-overflow" :title="file?.name">
        {{ file?.name || "-" }}
      </li>
      <li class="transcript-name">
        <el-input
          :value="title"
          @input="handleChange($event, 'title')"
          show-word-limit
          :maxlength="64"
          :disabled="!file"
        />
      </li>
      <li class="speakers">
        <el-select
          :value="speaker"
          @change="handleChange($event, 'speaker')"
          disabled
        >
          <el-option :value="-1" label="不區分語者"></el-option>
          <el-option :value="0" label="自動辨識"></el-option>
          <el-option v-for="n in speakers" :key="n" :label="n" :value="n">{{
            n
          }}</el-option>
        </el-select>
      </li>
      <li class="delete">
        <el-button
          type="text"
          icon="el-icon-error"
          class="delete-button"
          @click="handleClear"
          :disabled="!file"
        />
      </li>
    </ul>
  </div>
</template>

<script>
import constants from "@/utils/constants";

export default {
  name: "FileItem",
  props: {
    index: {
      type: Number,
      required: true,
    },
    title: {
      type: String,
      default: "",
    },
    file: {
      type: File || null,
    },
    speaker: {
      type: Number,
      default: 1,
    },
  },
  data() {
    return {
      speakers: constants.speakers,
    };
  },
  methods: {
    handleChange(value, type) {
      this.$emit("update-item", {
        index: this.index,
        title: type === "title" ? value : this.title,
        speaker: type === "speaker" ? value : this.speaker,
      });
    },
    handleClear() {
      this.$emit("clear-item", {
        index: this.index,
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.file-item-block {
  .file-item {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 12px 0;
  }

  .file-name {
    width: 300px;
  }

  .transcript-name {
    width: 400px;
  }

  .speakers {
    width: 300px;
  }

  .delete {
    width: 80px;
  }

  .delete-button {
    color: #ababab;
    font-size: 20px;
    transition: all 0.3s;

    &:hover {
      color: #d3cece;
    }
  }
}
</style>
