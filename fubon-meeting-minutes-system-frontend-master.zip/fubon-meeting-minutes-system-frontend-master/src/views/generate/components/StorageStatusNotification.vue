<template>
  <div class="error-message" v-if="statusShow">
    <div class="message-box">
      <div class="warning">
        <i class="el-icon-warning"></i>
        {{ statusMessage }}
      </div>
    </div>
    <i class="el-icon-close" aria-label="關閉" @click="statusShow = 0"></i>
  </div>
</template>

<script>
import { getStorage } from "@/api/system";

export default {
  name: "StorageStatusNotification",
  data() {
    return {
      storage: { usage: 0, status: 0 },
      timeout: null,
    };
  },
  computed: {
    statusShow: {
      get() {
        const storage = this.storage;
        return storage.status === 1 || storage.status === 2;
      },
      set(newValue) {
        this.storage.status = newValue;
      },
    },
    statusMessage() {
      const storage = this.storage;
      return storage.status === 1
        ? `儲存空間已使用 ${storage.usage}%`
        : storage.status === 2
        ? `儲存空間即將耗盡，請聯絡管理人員`
        : "";
    },
  },
  created() {
    this.handleGetStorage();
    this.handleRecursiveGetStorage();
  },
  beforeDestroy() {
    if (this.timeout !== null) {
      clearTimeout(this.timeout);
    }
  },
  methods: {
    handleRecursiveGetStorage() {
      this.timeout = setTimeout(async () => {
        await this.handleGetStorage();
        this.handleRecursiveGetStorage();
      }, 60000);
    },
    async handleGetStorage() {
      const { data } = await getStorage();
      this.storage.usage = data[0].usage;
      this.storage.status = data[0].status;
    },
  },
};
</script>

<style lang="scss" scoped>
.error-message {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
  background-color: var(--main-color-green);
  padding: 4px;
  font-size: 14px;
  color: #ffffff;
  border-radius: 4px;

  .el-icon-close {
    cursor: pointer;
  }
}
</style>
