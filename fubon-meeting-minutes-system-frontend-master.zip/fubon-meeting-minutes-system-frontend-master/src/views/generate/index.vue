<template>
  <div class="generate-block">
    <div class="container">
      <storage-status-notification></storage-status-notification>

      <el-form ref="formRef" :model="form" :rules="rule" label-position="top">
        <div class="top-block">
          <div class="title">上傳檔案</div>

          <el-upload
            ref="uploadRef"
            action=""
            :accept="dataTypes.join(',')"
            :show-file-list="false"
            :before-upload="handleBeforeUpload"
            :http-request="handleUpload"
            multiple
          >
            <el-button class="primary-button upload-button">選擇檔案</el-button>
          </el-upload>
          <el-button
            type="text"
            class="question-button"
            @click="visibility.questionDialog = true"
            >音檔上傳規範</el-button
          >
        </div>

        <div class="main-block">
          <ul class="upload-title-block">
            <li class="file-name">檔案名稱</li>
            <li class="transcript-name">
              逐字稿標題
              <span class="info">(如未填寫, 將使用原檔案名稱作為標題)</span>
            </li>
            <li class="speakers">
              語者人數
              <span class="info">(後續可修改)</span>
            </li>
            <li class="delete">刪除</li>
          </ul>

          <file-item
            v-for="(_, index) in 5"
            :key="index"
            :index="index"
            :file="form.files[index]"
            :title="form.titles[index]"
            :speaker="form.speakers[index]"
            @update-item="handleUpdateItem"
            @clear-item="handleClearItem"
          />
        </div>

        <div class="bottom-block">
          <el-row :gutter="20">
            <el-col :span="4">
              <el-form-item>
                <template #label>
                  <span class="label">處理順序</span>
                </template>
                <el-select value="normal" disabled>
                  <el-option value="normal" label="一般">一般</el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="4">
              <el-form-item>
                <template #label>
                  <span class="label">辨識模型</span>
                </template>
                <el-select value="meeting" disabled>
                  <el-option value="meeting" label="會議模型"
                    >會議模型</el-option
                  >
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>

          <el-row>
            <el-col :span="24">
              <el-form-item prop="description">
                <template #label>
                  <span class="label">描述&nbsp;</span>
                  <span class="info">(非必填)</span>
                </template>
                <el-input
                  type="textarea"
                  :rows="3"
                  :maxlength="200"
                  v-model="form.description"
                  show-word-limit
                />
              </el-form-item>
            </el-col>
          </el-row>
        </div>

        <div class="button-group">
          <el-button class="clear-button" type="info" @click="handleClear"
            >取消</el-button
          >
          <el-button
            class="secondary-button submit-button"
            :disabled="loading"
            @click="handleSubmit"
            >執行</el-button
          >
        </div>
      </el-form>
    </div>

    <question-dialog
      :dialog-visible="visibility.questionDialog"
      title="音檔規範"
      @close="visibility.questionDialog = false"
    >
      <template #title-inner>
        <a
          href="http://eip.fubon.com/sites/fintech/DocLib8/Forms/AllItems.aspx"
          target="_blank"
          class="question-dialog-title-link"
          >點我閱覽平台使用說明書</a
        >
      </template>

      <template #content>
        <div class="question-dialog-content">
          <ul class="content">
            <li>
              <span class="circle"></span
              ><span class="title">一次最多五個音檔</span>
            </li>
            <li>
              <span class="circle"></span>
              <span class="title">語音檔格式：</span>支援
              MP3、WMV、M4A、WMA、WAV
            </li>
            <li>
              <span class="circle"></span
              ><span class="title">影音檔格式：</span>MP4、MPV
            </li>
            <li>
              <span class="circle"></span>
              <span class="title">語言：</span
              >不支持全英文音檔，僅支持中文、中文及部分英文單字片語
            </li>
            <li>
              <span class="circle"></span
              ><span class="title">音檔時間長度：</span>需小於3小時
            </li>
            <li>
              <span class="circle"></span
              ><span class="title">音檔大小：</span>不超過4GB
            </li>
          </ul>
        </div>
      </template>
    </question-dialog>
  </div>
</template>

<script>
import FileItem from "./components/FileItem.vue";
import StorageStatusNotification from "./components/StorageStatusNotification.vue";
import { v4 as uuidv4 } from "uuid";

export default {
  name: "Generate",
  components: { FileItem, StorageStatusNotification },
  data() {
    return {
      form: {
        files: [null, null, null, null, null],
        titles: ["", "", "", "", ""],
        description: "",
        speakers: [-1, -1, -1, -1, -1],
        taskPriority: 1,
      },
      rule: {
        description: [{ max: 200, message: "最大長度為200", trigger: "blur" }],
      },
      visibility: {
        questionDialog: false,
      },
      loading: false,
      fileList: [],
      dataTypes: [
        "video/mp4",
        "video/wmv",
        "video/mpeg",
        "video/x-ms-wma",
        "video/x-ms-wmv",
        "audio/mp3",
        "audio/wav",
        "audio/x-wav",
        "audio/m4a",
        "audio/mpeg",
        "audio/x-m4a",
        "audio/x-ms-wma",
        "audio/x-ms-wmv",
      ],
    };
  },
  computed: {
    progress() {
      return this.$store.getters.progress;
    },
  },
  methods: {
    handleBeforeUpload(file) {
      if (file.name.length > 64) {
        this.$message({
          type: "error",
          message: "檔名長度不得超過64字",
          duration: 3000,
        });

        return false;
      }

      if (this.dataTypes.indexOf(file.type) === -1) {
        this.$message({
          type: "error",
          message: "請上傳正確的檔案格式",
          duration: 3000,
        });

        return false;
      }

      // kb -> mb -> gb * 4
      if (file.size > 4 * 1024 * 1024 * 1024) {
        this.$message({
          type: "error",
          message: "檔案大小不得超過4GB",
          duration: 3000,
        });

        return false;
      }

      return true;
    },
    handleUpload(file) {
      const index = this.form.files.findIndex((item) => item === null);

      if (index === -1) {
        this.$message({
          type: "error",
          message: "上傳檔案數量超過限制",
          duration: 3000,
        });
        return;
      }

      this.form.files.splice(index, 1, file.file);
    },
    handleClear() {
      if (this.form.files.some((file) => file !== null)) {
        this.$confirm("確定要清除所有檔案嗎？", "警告", {
          confirmButtonText: "確定",
          cancelButtonText: "取消",
          type: "warning",
        }).then(() => {
          this.handleReset();

          this.$message({
            type: "success",
            message: "清除成功",
            duration: 1000,
          });
        });
      } else {
        this.handleReset();
      }
    },
    handleUpdateItem({ index, title, speaker }) {
      this.form.titles.splice(index, 1, title);
      this.form.speakers.splice(index, 1, speaker);
    },
    handleClearItem({ index }) {
      this.form.files.splice(index, 1, null);
      this.form.titles.splice(index, 1, "");
      this.form.speakers.splice(index, 1, -1);
    },
    handleReset() {
      this.form = {
        files: [null, null, null, null, null],
        titles: ["", "", "", "", ""],
        description: "",
        speakers: [-1, -1, -1, -1, -1],
        taskPriority: 1,
      };
    },
    async handleFormData() {
      const arr = [];

      for (let i = 0; i < this.form.files.length; i++) {
        if (this.form.files[i] === null) continue;

        const formData = new FormData();

        formData.append("sourceType", "2"); // 1 -> youtube, 2 -> file
        formData.append("sourceWebLink", this.form.files[i]); // string type -> youtube, File type -> File
        let title = this.form.titles[i].replaceAll(" ", "");
        if (title.length === 0) {
          formData.append(
            "title",
            this.form.files[i].name.split(".").slice(0, -1).join(".") // extract file name without extension
          );
        } else {
          formData.append("title", title);
        }

        formData.append("audioChannel", "0"); // 0 -> 雙聲道, 1 -> 左聲道, 2 -> 右聲道
        formData.append(
          "speakerNum",
          this.form.speakers[i] === -1 ? 1 : this.form.speakers[i]
        ); // 語者人數
        formData.append("description", this.form.description.trim());
        formData.append("taskPriority", this.form.taskPriority); // 1
        formData.append("sessionId", uuidv4());

        arr.push(formData);
      }

      return arr;
    },
    async handleSubmit() {
      this.$refs.formRef.validate(async (valid) => {
        if (valid) {
          this.loading = true;

          const files = this.form.files.filter((file) => file !== null);

          if (files.length === 0) {
            this.loading = false;
            return;
          }

          if (this.progress.length + files.length > 5) {
            this.$message({
              type: "error",
              message: "已達最大同時上傳數量5，請等待上傳完成後再新增",
              duration: 3000,
            });
            return;
          }

          // 開始上傳
          const formDataGroup = await this.handleFormData();
          this.$store.dispatch("upload/execute", formDataGroup);

          // reset all upload status
          this.loading = false;
          this.handleReset();
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.generate-block {
  .top-block {
    display: flex;
    align-items: center;
    margin-bottom: 16px;
  }

  .title {
    color: var(--main-color-blue);
    font-weight: bold;
    display: flex;
    align-items: center;

    span {
      color: var(--main-font-color);
      font-weight: normal;
      font-size: 14px;
    }
  }

  ::v-deep .question-button {
    margin-left: 18px;
    font-size: 16px;
    color: #b32518;
  }

  ::v-deep .question-dialog-title-link {
    color: #b32518;
    font-size: 16px;
    margin-left: 20px;
    display: inline-block;
  }

  .upload-button {
    padding: 8px 24px;
    margin-left: 20px;
  }

  .main-block {
    background-color: var(--main-color-gray);
    padding: 12px;
  }

  .upload-title-block {
    display: flex;
    align-items: center;
    gap: 12px;
    color: #525051;
    font-weight: bold;

    .file-name {
      width: 300px;
    }

    .transcript-name {
      width: 400px;
    }

    .speakers {
      width: 300px;
    }

    .delete {
      width: 80px;
    }

    .info {
      font-weight: normal;
      font-size: 12px;
    }
  }

  .bottom-block {
    margin-top: 20px;

    .label {
      color: var(--main-color-blue);
      font-weight: bold;
      font-size: 16px;
    }
  }

  .clear-button {
    padding: 8px 24px;
    margin-right: 40px;
  }

  .submit-button {
    padding: 8px 24px;
  }
}

.question-dialog-content {
  font-size: 16px;
  font-weight: 400;
  color: #000000;

  .title {
    color: #000000;
  }

  .circle {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: #000000;
    display: inline-block;
    margin-right: 8px;
    margin-bottom: 2px;
  }

  li {
    margin: 12px 0;
    display: flex;
    align-items: center;
  }
}
</style>
