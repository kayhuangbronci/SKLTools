<template>
  <div ref="menuDropdownRef" class="menu-dropdown-block" @click="show = !show">
    <slot></slot>

    <div v-if="show" class="menu-dropdown-list">
      <slot name="item"></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: "MenuDropdown",
  data() {
    return {
      show: false,
    };
  },
  created() {
    document.addEventListener("mousedown", this.handleClickOutside);
  },
  beforeDestroy() {
    document.removeEventListener("mousedown", this.handleClickOutside);
  },
  methods: {
    handleClickOutside(event) {
      const menuRef = this.$refs.menuDropdownRef;

      if (menuRef && !menuRef.contains(event.target)) {
        this.show = false;
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.menu-dropdown-block {
  position: relative;

  .menu-dropdown-list {
    position: absolute;
    z-index: 999;
    left: 50%;
    top: 45px;
    transform: translateX(-50%);
    background-color: #ffffff;
    width: 113px;
    text-align: center;
    border: 1px solid #d7dada;
    border-radius: 4px;
    box-shadow: 0px 4px 11px 0px rgba(0, 0, 0, 0.2);
  }
}
</style>
