<template>
  <transition name="slide-fade">
    <div id="js-upload-box" class="upload-box">
      <div class="top">上傳檔案中...</div>
      <div class="progress-bar-block">
        <div v-for="p in progress" :key="p.sessionId" class="progress-bar">
          <p class="title">檔案：{{ p.title }}</p>
          <div class="wrapper">
            <i class="el-icon-upload" aria-label="上傳"></i>
            <el-progress
              v-if="p.progress !== 100"
              :percentage="p.progress"
              :format="format"
              :color="customColors"
            />
            <div v-else class="loading-bar"></div>
            <i
              aria-label="取消上傳"
              class="el-icon-circle-close cancel"
              @click="cancelTasks(p.sessionId)"
            ></i>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
import store from "@/store";

export default {
  name: "UploadBox",
  data() {
    return {
      customColors: [
        { color: "#f56c6c", percentage: 20 },
        { color: "#e6a23c", percentage: 40 },
        { color: "#6f7ad3", percentage: 60 },
        { color: "#1989fa", percentage: 80 },
        { color: "#5cb87a", percentage: 100 },
      ],
    };
  },
  computed: {
    progress() {
      return this.$store.getters.progress;
    },
    cancelProgress() {
      return this.$store.getters.cancelProgress;
    },
  },
  created() {
    window.addEventListener("beforeunload", this.handleReload, false);
  },
  beforeDestroy() {
    window.removeEventListener("beforeunload", this.handleReload);

    // Remove all promises and using setTimeout make notify shows correctly. Not folding together.
    this.cancelProgress.forEach((el) =>
      setTimeout(() => {
        el.cancel("檔案取消上傳");
        this.notify(el.sessionId);
      }, 400)
    );
  },
  methods: {
    format(percentage) {
      return percentage === 100 ? "" : `${percentage}%`;
    },
    cancelTasks(sessionId) {
      this.cancelProgress
        .find((el) => el.sessionId === sessionId)
        .cancel("檔案取消上傳");
      this.notify(sessionId);
    },
    notify(sessionId) {
      store
        .dispatch("upload/removeProgress", sessionId)
        .then(() => {
          this.$message({
            type: "error",
            message: "檔案取消上傳",
            duration: 3000,
          });
        })
        .catch(console.error);
    },
    handleReload(e) {
      e.returnValue = "上傳中的檔案即將遺失，是否繼續";
    },
  },
};
</script>

<style scoped lang="scss">
.upload-box {
  position: fixed;
  bottom: 36px;
  right: 36px;
  width: 365px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  background-color: #f7f7f7;
  z-index: 10000;

  .top {
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    padding: 12px 0 12px 16px;
    background-color: #333333;
    color: #ffffff;
    font-size: 12px;
  }

  .progress-bar-block {
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    padding: 12px 0;

    .progress-bar {
      .title {
        font-size: 12px;
        padding: 0 12px;
        margin-bottom: 4px;
        color: #606266;
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
      }

      .wrapper {
        margin-bottom: 8px;
        display: flex;
        align-items: center;

        i {
          font-size: 14px;
          line-height: 1;
          padding: 0 6px 0 12px;
          color: #606266;
        }
      }

      .el-progress {
        width: 100%;
      }

      .el-progress__text {
        font-size: 14px !important;
      }

      .cancel {
        cursor: pointer;
      }
    }

    .loading-bar {
      width: 100%;
      height: 6px;
      position: relative;
      overflow: hidden;
      background-color: var(--main-color-green);
      border-radius: 100px;

      &::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        display: block;
        width: 100%;
        height: 100%;
        background: linear-gradient(
          -45deg,
          rgba(255, 255, 255, 0.2) 25%,
          transparent 25%,
          transparent 50%,
          rgba(255, 255, 255, 0.2) 50%,
          rgba(255, 255, 255, 0.2) 75%,
          transparent 75%,
          transparent
        );
        background-size: 50px 50px;
        z-index: 1;
        animation: loading 0.6s infinite;
      }
    }
  }
}

@keyframes loading {
  0% {
    background-position: 0 0;
  }
  100% {
    background-position: 50px 50px;
  }
}
</style>
