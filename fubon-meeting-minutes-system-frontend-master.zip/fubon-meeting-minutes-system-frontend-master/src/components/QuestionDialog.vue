<template>
  <el-dialog
    :width="width"
    :visible.sync="dialogVisible"
    :before-close="handleClose"
    class="question-dialog"
  >
    <div slot="title">
      <div class="el-dialog__title">
        {{ title }}
        <slot name="title-inner"></slot>
      </div>
    </div>

    <slot name="content"></slot>
  </el-dialog>
</template>

<script>
export default {
  name: "QuestionDialog",
  props: {
    dialogVisible: {
      type: Boolean,
      required: true,
      default: false,
    },
    title: {
      type: String,
      required: true,
      default: "Title",
    },
    width: {
      type: String,
      default: "600px",
    },
  },
  methods: {
    handleClose() {
      this.$emit("close");
    },
  },
};
</script>

<style lang="scss" scoped>
::v-deep.question-dialog {
  .el-dialog__body {
    padding-top: 10px;
  }

  .el-dialog__title {
    color: #000000;
    font-weight: 700;
  }
}
</style>
