<template>
  <div class="breadcrumb-block">
    <slot></slot>

    <slot name="right"></slot>
  </div>
</template>

<script>
export default {
  name: "Breadcrumb",
};
</script>

<style lang="scss" scoped>
.breadcrumb-block {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 2px solid #f2f2f2;
  padding-bottom: 8px;
  margin-bottom: 16px;
}
</style>
