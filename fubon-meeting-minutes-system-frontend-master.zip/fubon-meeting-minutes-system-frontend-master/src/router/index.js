import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

// Remove uncaught (in promise) undefined error
const routerPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location, resolve, reject) {
  if (resolve || reject)
    return routerPush.call(this, location, resolve, reject);
  return routerPush.call(this, location).catch((error) => error);
};

import Layout from "@/layout/index.vue";

export const constantRoutes = [
  {
    path: "/login",
    component: () => import("../views/login/index.vue"),
    meta: {
      title: "登入",
    },
  },

  {
    path: "/404",
    component: () => import("../views/error/404.vue"),
    meta: {
      title: "404",
    },
  },
];

export const asyncRoutes = [
  {
    path: "/generate",
    component: Layout,
    meta: {
      role: ["user"],
    },
    children: [
      {
        path: "/generate",
        name: "Generate",
        component: () => import("../views/generate/index.vue"),
        meta: {
          title: "逐字稿生成",
        },
      },
    ],
  },

  {
    path: "/file-manage",
    component: Layout,
    meta: {
      role: ["user"],
    },
    children: [
      {
        path: "/file-manage",
        name: "FileManage",
        component: () => import("../views/file-manage/index.vue"),
        meta: {
          title: "檔案管理",
        },
      },
      {
        path: "/file-manage/edit/:id",
        name: "TranscriptEdit",
        component: () => import("../views/file-manage/edit.vue"),
        meta: {
          title: "逐字稿編輯",
        },
      },
    ],
  },

  {
    path: "/feedback",
    component: Layout,
    meta: {
      role: ["user"],
    },
    children: [
      {
        path: "/feedback/statistics",
        name: "FeedbackStatistics",
        component: () => import("../views/feedback/statistics.vue"),
        meta: {
          title: "回饋問卷",
        },
      },
      {
        path: "/feedback/error",
        name: "FeedbackError",
        component: () => import("../views/feedback/error.vue"),
        meta: {
          title: "錯誤字回報",
        },
      },
    ],
  },

  {
    path: "/log",
    component: Layout,
    meta: {
      role: ["admin"],
    },
    children: [
      {
        path: "/log",
        name: "Log",
        component: () => import("../views/log/index.vue"),
        meta: {
          title: "操作記錄",
        },
      },
    ],
  },

  {
    path: "/account",
    component: Layout,
    meta: {
      role: ["admin"],
    },
    children: [
      {
        path: "/account",
        name: "Account",
        component: () => import("../views/account/account.vue"),
        meta: {
          title: "帳號管理",
        },
      },
    ],
  },

  {
    path: "/system",
    component: Layout,
    meta: {
      role: ["admin"],
    },
    children: [
      {
        path: "/system/status",
        name: "SystemStatus",
        component: () => import("@/views/system/status.vue"),
        meta: {
          title: "系統狀態",
        },
      },
      {
        path: "/system/setting",
        name: "SystemSetting",
        component: () => import("@/views/system/setting.vue"),
        meta: {
          title: "系統設置",
        },
      },
    ],
  },

  {
    path: "/model-manage",
    component: Layout,
    meta: {
      role: ["maintainer"],
    },
    children: [
      {
        path: "/model-manage/errata",
        name: "ModelManageErrata",
        component: () => import("@/views/model-manage/errata.vue"),
        meta: {
          title: "勘誤表",
        },
      },
      // {
      //   path: "/model-manage/vocabulary",
      //   name: "ModelManageVocabulary",
      //   component: () => import("@/views/model-manage/vocabulary.vue"),
      //   meta: {
      //     title: "用戶詞庫",
      //   },
      // },
    ],
  },

  {
    path: "*",
    meta: { role: ["admin", "user", "maintainer"] },
    redirect: "/404",
  },
];

function createRouter() {
  return new VueRouter({
    mode: "history",
    routes: constantRoutes,
    scrollBehavior: () => ({ y: 0 }),
  });
}

const router = createRouter();

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter();
  router.matcher = newRouter.matcher;
}

export default router;
