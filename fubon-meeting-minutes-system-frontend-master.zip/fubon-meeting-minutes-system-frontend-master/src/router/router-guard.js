import router from "@/router";
import store from "@/store";
import getPageTitle from "@/utils/get-page-title";
import { getToken } from "@/utils/auth";

const whiteList = ["/login"];

router.beforeEach(async (to, _from, next) => {
  if (to.meta.title) {
    document.title = getPageTitle(to.meta.title);
  }

  const hasToken = getToken();

  function handleRedirect(role) {
    if (role === "admin") {
      next({ path: "/account", replace: true });
    } else if (role === "maintainer") {
      next({ path: "/model-manage/errata" });
    } else {
      next({ path: "/generate" });
    }
  }

  if (hasToken) {
    const role = store.getters.info.role;

    if (to.path === "/login") {
      if (role.length > 0) {
        handleRedirect(role);
      } else {
        next({ path: "/" });
      }
    } else {
      if (role.length > 0) {
        if (to.path === "/login" || to.path === "/404") {
          handleRedirect(role);
        } else {
          next();
        }
      } else {
        try {
          const { role } = await store.dispatch("user/userInfo");

          const accessRoutes = await store.dispatch(
            "permission/generateRoutes",
            role
          );

          accessRoutes.forEach((route) => {
            router.addRoute(route);
          });

          if (to.path === "/") {
            handleRedirect(role);
          } else {
            next({ ...to, replace: true });
          }
        } catch (error) {
          console.log(`router error ${error}`);
          await store.dispatch("user/resetToken");
          next({ path: `/login?redirect=${to.path}` });
        }
      }
    }
  } else {
    if (whiteList.indexOf(to.path) !== -1) {
      next();
    } else {
      next({ path: `/login?redirect=${to.path}` });
    }
  }
});

router.afterEach((_to, _from) => {
  // ...
});

router.onError((error) => {
  console.log(`router onError error ${error}`);
});
