import request from "@/utils/request";

/**
 * Get logs.
 */
export function getLogs(params) {
  return request({
    url: "/api/v1/audit",
    method: "get",
    params,
  });
}

/**
 * Get logs total.
 */
export function getLogsTotal(params) {
  return request({
    url: "/api/v1/audit/total",
    method: "get",
    params,
  });
}

/**
 * Get operation log list.
 */
export function getOperationList() {
  return request({
    url: "/api/v1/audit/operation-list",
    method: "get",
  });
}
