import request from "@/utils/request";

/**
 * Get tasks.
 */
export function getTasks(params) {
  return request({
    url: `/api/v1/subtitle/tasks`,
    method: "get",
    params,
  });
}

/**
 * Get tasks total.
 */
export function getTasksTotal(params) {
  return request({
    url: `/api/v1/subtitle/tasks/total`,
    method: "get",
    params,
  });
}

/**
 * Get task by id.
 */
export function getTask(id) {
  return request({
    url: `/api/v1/subtitle/tasks/${id}`,
    method: "get",
  });
}

/**
 * Disable task process by id.
 */
export function disableTaskProcess(id) {
  return request({
    url: `/api/v1/subtitle/tasks/${id}?operation=cancel`,
    method: "put",
  });
}

/**
 * Delete task by id.
 */
export function deleteTask(id) {
  return request({
    url: `/api/v1/subtitle/tasks/${id}`,
    method: "delete",
  });
}

/**
 * Get task status list.
 */
export function getTaskStatus() {
  return request({
    url: `/api/v1/subtitle/tasks/status-list`,
    method: "get",
  });
}

/**
 * Download task transcript file.
 */
export function downloadTaskTranscriptFile(id, params) {
  return request({
    url: `/api/v1/subtitle/tasks/${id}/extra-file-path`,
    method: "get",
    params,
  });
}

/**
 * Get task resource.
 */
export function getTaskResource(id, params) {
  return request({
    url: `/api/v1/subtitle/tasks/${id}/editor-resource`,
    method: "get",
    params,
  });
}

/**
 * Get task resource with speaker info.
 *
 * @param {number} id - 指定任務id
 */
export function getTaskResourceWithSpeakerInfo(id, params) {
  return request({
    url: `/api/v1/subtitle/tasks/${id}/subtitle-json`,
    method: "get",
    params,
  });
}

/**
 * Update task resource with speaker info.
 *
 * @param {number} id
 * @param {object} data
 */
export function updateTaskResourceWithSpeakerInfo(id, data) {
  return request({
    url: `/api/v1/subtitle/tasks/${id}/subtitle-json`,
    method: "put",
    data,
  });
}

/**
 * Get task download path.
 *
 * @param {number} id - 指定任務id
 */
export function getTaskDownloadPath(id, params) {
  return request({
    url: `/api/v1/subtitle/tasks/${id}/file-path`,
    method: "get",
    params,
  });
}

/**
 * Get audio download link path.
 *
 * @param {number} id - 指定任務id
 */
export function getAudioDownloadLinkPath(id, params) {
  return request({
    url: `/api/v1/subtitle/tasks/${id}/audio-link`,
    method: "get",
    params,
  });
}

/**
 * Create speaker info.
 */
export function createSpeakerInfo(id, data) {
  return request({
    url: `/api/v1/subtitle/tasks/${id}/speaker-info`,
    method: "post",
    data,
  });
}

/**
 * Update speaker info
 */
export function updateSpeakerInfo(id, data) {
  return request({
    url: `/api/v1/subtitle/tasks/${id}/speaker-info`,
    method: "post",
    data,
  });
}
