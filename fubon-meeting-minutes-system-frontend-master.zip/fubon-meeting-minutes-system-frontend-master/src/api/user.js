import request from "@/utils/request";

/**
 * @description Login the user.
 *
 * @param {Object} data
 * @param {string} data.username
 * @param {string} data.password
 * @param {boolean} data.rememberMe
 */
export function login(data) {
  return request({
    url: "/api/v1/login",
    method: "post",
    data,
  });
}

/**
 * @description Get user info.
 */
export function getUserInfo() {
  return request({
    url: "/api/v1/user/info",
    method: "get",
  });
}

/**
 * @description Logout the user.
 */
export function logout() {
  return request({
    url: "/api/v1/logout",
    method: "post",
  });
}

/**
 * @description Get roles options.
 */
export function getRoles() {
  return request({
    url: "/api/v1/user/role-options",
    method: "get",
  });
}

/**
 * @description Get users data.
 */
export function getAllUsers(params = {}) {
  return request({
    url: "/api/v1/users",
    method: "get",
    params,
  });
}

/**
 * @description Get users total.
 */
export function getAllUsersTotal(params = {}) {
  return request({
    url: "/api/v1/users/total",
    method: "get",
    params,
  });
}

/**
 * @description Create user.
 */
export function createUser(data) {
  return request({
    url: "/api/v1/user",
    method: "post",
    data,
  });
}

/**
 * @description Update user role.
 */
export function updateUserRole(params) {
  return request({
    url: "/api/v1/user/role",
    method: "put",
    params,
  });
}

/**
 * @description Update user profile.
 */
export function updateUserInfo(params) {
  return request({
    url: "/api/v1/user/profile",
    method: "put",
    params,
  });
}
