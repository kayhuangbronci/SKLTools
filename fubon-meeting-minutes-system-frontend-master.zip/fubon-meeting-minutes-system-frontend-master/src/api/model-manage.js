import request from "@/utils/request";

/**
 * @description Get model manage errata.
 */
export function getErrata() {
  return request({
    url: "/api/v1/fixbook/text",
    method: "get",
  });
}

/**
 * @description Update model mange errata.
 */
export function updateErrata(data) {
  return request({
    url: "/api/v1/fixbook/text",
    method: "post",
    data,
  });
}

/**
 * @description Get vocabulary list.
 */
export function getVocabularyList() {
  return request({
    url: "/api/v1/models/combiner/info",
    method: "get",
  });
}

/**
 * @description Get vocabulary.
 */
export function getVocabulary(params) {
  return request({
    url: "/api/v1/models/combiner/vocabulary",
    method: "get",
    params,
  });
}

/**
 * @description Update vocabulary.
 */
export function updateVocabulary(data) {
  return request({
    url: "/api/v1/models/combiner/vocabulary",
    method: "put",
    data,
  });
}

/**
 * @description Update vocabulary model.
 */
export function updateVocabularyModel(params) {
  return request({
    url: "/api/v1/models/combiner/status",
    method: "put",
    params,
  });
}
