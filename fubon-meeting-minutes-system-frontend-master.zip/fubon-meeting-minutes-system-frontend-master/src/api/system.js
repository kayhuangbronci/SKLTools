import request from "@/utils/request";

/**
 * Get system setting.
 */
export function getSystemSetting() {
  return request({
    url: "/api/v1/config/system-settings",
    method: "get",
  });
}

/**
 * Update system setting space limit range.
 */
export function updateLimit(params) {
  return request({
    url: "/api/v1/config/storage-threshold",
    method: "put",
    params,
  });
}

/**
 * Update system setting auto release storage.
 */
export function updateAutoReleaseStorage(params) {
  return request({
    url: "/api/v1/config/auto-task-remove",
    method: "put",
    params,
  });
}

/**
 * Update system setting text export duration.
 */
export function updateTextExportDuration(params) {
  return request({
    url: "/api/v1/config/transcript-segment-duration",
    method: "put",
    params,
  });
}

/**
 * Get license information.
 */
export function getLicenseInfo() {
  return request({
    url: "/api/v1/config/license-info",
    method: "get",
  });
}

/**
 * Update license information.
 */
export function updateLicenseInfo(data) {
  return request({
    url: "/api/v1/config/service-license",
    method: "post",
    headers: { "Content-Type": "multipart/form-data" },
    data,
  });
}

/**
 * Restart request.
 */
export function restartRequest() {
  return request({
    url: "/api/v1/config/reset",
    method: "post",
  });
}

/**
 * Get system status storage.
 */
export function getStorage() {
  return request({
    url: "/api/v1/status/storage",
    method: "get",
  });
}

/**
 * Get system status version.
 */
export function getVersion() {
  return request({
    url: "/api/v1/status/version",
    method: "get",
  });
}

/**
 * Get system status workers.
 */
export function getWorkers() {
  return request({
    url: "/api/v1/status/service",
    method: "get",
  });
}

/**
 * Update task preservation.
 */
export function updateTaskPreservation(params) {
  return request({
    url: "/api/v1/config/task-preservation",
    method: "put",
    params,
  });
}
