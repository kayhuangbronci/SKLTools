import request from "@/utils/request";

/**
 * Get errata.
 *
 * @param {Object} [params]
 * @param {Number} params.pageIndex
 * @param {Number} params.pageSize
 * @param {String} params.start
 * @param {String} params.end
 * @param {String} params.username
 * @param {String} params.order
 */
export function getFeedbackErrata(params) {
  return request({
    url: "/api/v1/errata/feedback",
    method: "get",
    params,
  });
}

/**
 * Update errata.
 *
 * @param {Array.<{original: String, fixed: String}>} data
 */
export function createFeedbackErrata(data) {
  return request({
    url: "/api/v1/errata/feedback",
    method: "post",
    data,
  });
}

/**
 * Get errata download link.
 *
 * @param {Object} params
 * @param {String} params.start
 * @param {String} params.end
 * @param {String} [params.username]
 * @param {String} [params.order]
 */
export function downloadFeedbackErrata(params) {
  return request({
    url: "/api/v1/errata/feedback/download-link",
    method: "get",
    params,
  });
}
