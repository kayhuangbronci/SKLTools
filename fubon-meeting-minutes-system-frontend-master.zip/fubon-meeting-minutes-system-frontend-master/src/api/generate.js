import request from "@/utils/request";
import axios from "axios";
import store from "@/store";

/**
 * Add task to ASR.
 */
export function addTask(data, groupId) {
  const CancelToken = axios.CancelToken;
  let cancel;
  const title = data.get("title");
  const sessionId = data.get("sessionId");

  return request({
    url: "/api/v1/subtitle/tasks",
    method: "post",
    headers: { "Content-Type": "multipart/form-data" },
    cancelToken: new CancelToken(function executor(c) {
      cancel = c;
      store
        .dispatch("upload/cancelProgress", { cancel, sessionId, groupId })
        .then(console.log, console.err);
    }),
    data,
    onUploadProgress: function (progressEvent) {
      const percentCompleted = Math.round(
        (progressEvent.loaded * 100) / progressEvent.total
      );
      store
        .dispatch("upload/addProgress", {
          progress: percentCompleted,
          title,
          sessionId,
          groupId,
        })
        .then(console.log, console.err);
    },
  });
}
