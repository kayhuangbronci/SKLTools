<template>
  <main>
    <router-view :key="key" />

    <upload-box v-if="progress.length !== 0"></upload-box>
  </main>
</template>

<script>
import { UploadBox } from "@/components";

export default {
  name: "AppMain",
  components: {
    UploadBox,
  },
  computed: {
    key() {
      return this.$route.path;
    },
    progress() {
      return this.$store.getters.progress;
    },
  },
};
</script>

<style lang="scss" scoped></style>
