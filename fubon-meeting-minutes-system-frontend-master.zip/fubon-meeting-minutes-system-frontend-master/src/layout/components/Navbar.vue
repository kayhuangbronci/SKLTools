<template>
  <header>
    <nav>
      <div class="decoration" />
      <div class="container">
        <ul class="menu-wrapper">
          <li @click="handleRedirect">
            <img class="logo" src="../../assets/nav-logo.png" alt="富邦" />
          </li>
          <li v-if="role === 'user'">
            <router-link :to="{ name: 'Generate' }" class="menu-link"
              >逐字稿生成</router-link
            >
          </li>

          <li v-if="role === 'user'">
            <router-link :to="{ name: 'FileManage' }" class="menu-link"
              >檔案管理</router-link
            >
          </li>

          <li v-if="role === 'user'">
            <menu-dropdown>
              <div
                class="menu-link"
                :class="
                  routerPath.startsWith('/feedback') && 'router-link-active'
                "
              >
                使用者回饋
              </div>

              <template #item>
                <router-link
                  :to="{ name: 'FeedbackStatistics' }"
                  class="menu-link dropdown"
                  >回饋問卷</router-link
                >
                <router-link
                  :to="{ name: 'FeedbackError' }"
                  class="menu-link dropdown"
                  >錯誤字回報</router-link
                >
              </template>
            </menu-dropdown>
          </li>

          <li v-if="role === 'admin'">
            <router-link to="/account" class="menu-link">帳號管理</router-link>
          </li>

          <li v-if="role === 'admin'">
            <router-link to="/log" class="menu-link">操作紀錄</router-link>
          </li>

          <li v-if="role === 'admin'">
            <menu-dropdown>
              <div
                class="menu-link"
                :class="
                  routerPath.startsWith('/system') && 'router-link-active'
                "
              >
                系統管理
              </div>

              <template #item>
                <router-link
                  :to="{ name: 'SystemStatus' }"
                  class="menu-link dropdown"
                  >系統狀態</router-link
                >
                <router-link
                  :to="{ name: 'SystemSetting' }"
                  class="menu-link dropdown"
                  >系統設置</router-link
                >
              </template>
            </menu-dropdown>
          </li>

          <li v-if="role === 'maintainer'">
            <router-link to="/model-manage/errata" class="menu-link"
              >模型管理</router-link
            >
          </li>

          <li class="right">
            <el-button type="text" class="logout-button" @click="handleLogout">
              <span style="margin-right: 8px">{{ nickname }}</span>
              <i class="el-icon-user-solid"></i>
              登出
            </el-button>
          </li>
        </ul>
      </div>
    </nav>
  </header>
</template>

<script>
import { MenuDropdown } from "@/components";

export default {
  name: "Navbar",
  components: {
    MenuDropdown,
  },
  computed: {
    routerPath() {
      return this.$route.path;
    },
    role() {
      return this.$store.getters.info?.role;
    },
    nickname() {
      return this.$store.getters.info?.nickname || "";
    },
  },
  methods: {
    handleRedirect() {
      if (this.role === "admin") {
        this.$router.push({ path: "/account" });
      } else if (this.role === "maintainer") {
        this.$router.push({ path: "/model-manage/errata" });
      } else {
        this.$router.push({ path: "/generate" });
      }
    },
    handleLogout() {
      this.$confirm("確定要登出嗎？", "提示", {
        confirmButtonText: "確定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(async () => {
        await this.$store.dispatch("user/userLogout");

        this.$router.push(`/login?redirect=${this.$route.fullPath}`);
      });
    },
  },
};
</script>

<style lang="scss" scoped>
header {
  margin-bottom: 20px;
}

nav {
  background-color: var(--main-bg-nav);
  box-shadow: rgb(0 0 0 / 20%) 0px 3px 3px -2px,
    rgb(0 0 0 / 14%) 0px 3px 4px 0px, rgb(0 0 0 / 12%) 0px 1px 8px 0px;
}

.decoration {
  height: 6px;
  background-color: var(--main-color-blue);
}

.menu-wrapper {
  display: flex;
  align-items: center;
  height: 72px;

  li {
    padding: 0 16px;
    border-right: 1px solid #d7dada;
    position: relative;

    .logo {
      cursor: pointer;
    }

    a {
      display: block;
    }

    &:first-child {
      padding-left: 0;
      border-right: none;

      img {
        height: 80px;
      }
    }

    &:nth-last-child(2) {
      border-right: none;
    }

    &:last-child {
      padding: 0;
      border-right: none;
    }

    .menu-link {
      transition: all 0.3s;
      cursor: pointer;

      &:hover,
      &.router-link-active,
      &.router-link-exact-active {
        color: var(--main-color-blue);
      }

      &.dropdown {
        width: 100%;
        padding: 12px 12px;

        &:last-child {
          margin-bottom: 0;
        }

        &:hover {
          background-color: #f5f5f5;
        }
      }
    }

    &.right {
      margin-left: auto;
    }
  }

  .logout-button {
    color: var(--main-font-color);
    font-size: 16px;
  }

  .el-dropdown-link {
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s;

    &:hover {
      color: var(--main-color-blue);
    }

    .el-icon-user-solid {
      font-size: 20px;
    }
  }
}
</style>
