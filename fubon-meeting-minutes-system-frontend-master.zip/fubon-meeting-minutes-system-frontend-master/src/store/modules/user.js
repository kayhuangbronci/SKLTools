import { login, getUserInfo, logout } from "@/api/user";
import { getToken, setToken, removeToken } from "@/utils/auth";
import { resetRouter } from "@/router";

const state = {
  token: getToken() || "",
  info: {
    ableToAccessAllTasks: 0,
    capability: 0,
    name: "",
    nickname: "",
    perms: [],
    role: "",
  },
};

const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token;
  },
  SET_INFO: (state, info) => {
    state.info = info;
  },
};

const actions = {
  userLogin({ commit }, data) {
    return new Promise((resolve, reject) => {
      login(data)
        .then((response) => {
          const { code, expiration, token } = response;

          if (code !== 200) {
            reject(`login error`);
          }
          commit("SET_TOKEN", token);
          setToken(token, expiration / 3600 / 24);
          resolve();
        })
        .catch((error) => {
          console.log(error);
          reject(error);
        });
    });
  },
  userInfo({ commit }) {
    return new Promise((resolve, reject) => {
      getUserInfo()
        .then((response) => {
          const { code, data } = response;

          if (code !== 200) {
            reject(`get user info error`);
          }

          if (data) {
            commit("SET_INFO", data[0]);
          }

          resolve({ role: data[0].role });
        })
        .catch((error) => {
          console.log(error);
          reject(error);
        });
    });
  },
  userLogout({ commit }) {
    return new Promise((resolve, reject) => {
      logout()
        .then((response) => {
          const { code } = response;

          if (code !== 200) {
            reject(`logout error`);
          }

          commit("SET_TOKEN", "");
          commit("SET_INFO", {
            ableToAccessAllTasks: 0,
            capability: 0,
            name: "",
            nickname: "",
            perms: [],
            role: "",
          });
          removeToken();
          resetRouter();

          resolve();
        })
        .catch((error) => {
          console.log(error);
          reject(error);
        });
    });
  },
  resetToken({ commit }) {
    return new Promise((resolve) => {
      commit("SET_TOKEN", "");
      commit("SET_INFO", {
        ableToAccessAllTasks: 0,
        capability: 0,
        name: "",
        nickname: "",
        perms: [],
        role: "",
      });
      removeToken();
      resolve();
    });
  },
};

export default {
  namespaced: true,
  state,
  mutations,
  actions,
};
