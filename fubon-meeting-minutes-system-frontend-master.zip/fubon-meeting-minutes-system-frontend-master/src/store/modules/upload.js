import { addTask } from "@/api/generate";
import { Notification, Message } from "element-ui";
import { v4 as uuidv4 } from "uuid";

const state = {
  progress: [
    // {
    //   progress: 20,
    //   title: "hello world",
    //   groupId: "88F0B98F-E907-42DC-BC79-7B956DE9BC48",
    //   sessionId: "1494D0B3-AE18-446D-9F46-23CBAB9ADF3F",
    // },
    // {
    //   progress: 100,
    //   title: "hello world",
    //   groupId: "88F0B98F-E907-42DC-BC79-7B956DE9BC48",
    //   sessionId: "1494D0B3-AE18-446D-9F46-23CBAB9ADF3F"
    // },
  ],
  cancel: [
    // {
    //   cancel: () => {},
    //   groupId: "88F0B98F-E907-42DC-BC79-7B956DE9BC48",
    //   sessionId: "1494D0B3-AE18-446D-9F46-23CBAB9ADF3F",
    // },
  ],
};

const mutations = {
  SET_PROGRESS: (state, progress) => {
    const index = state.progress.findIndex(
      (el) => el.sessionId === progress.sessionId
    );

    if (index === -1) {
      // cannot find the index of sessionId means it's new sessionId
      state.progress.push(progress);
      return;
    }

    // update progress
    state.progress[index].progress = progress.progress;
  },
  REMOVE_PROGRESS: (state, sessionId) => {
    state.progress = state.progress.filter((el) => el.sessionId !== sessionId);
    state.cancel = state.cancel.filter((el) => el.sessionId !== sessionId);
  },
  REMOVE_PROGRESS_FROM_API: (state, data) => {
    if (data.sessionId) {
      const groupId = state.progress.find(
        (el) => el.sessionId === data.sessionId
      )?.groupId;

      state.progress = state.progress.filter(
        (el) => el.sessionId !== data.sessionId
      );
      state.cancel = state.cancel.filter(
        (el) => el.sessionId !== data.sessionId
      );

      if (groupId) {
        const res = state.progress.some((el) => el.groupId === groupId);

        if (!res) {
          Notification.success({
            title: "成功",
            message: "新增成功",
          });
        }
      }
    }
  },
  CANCEL_PROGRESS: (state, cancel) => {
    state.cancel.push(cancel);
  },
};

const actions = {
  execute({ commit }, formDataGroup) {
    const groupId = uuidv4();

    for (let i = 0; i < formDataGroup.length; i++) {
      const formData = formDataGroup[i];
      addTask(formData, groupId)
        .then((response) => {
          commit("REMOVE_PROGRESS_FROM_API", response);
        })
        .catch((error) => {
          Message({
            type: "error",
            message: `檔案 ${formData.get("title")} 上傳失敗`,
            duration: 0,
            showClose: true,
          });

          commit("REMOVE_PROGRESS", formData.get("sessionId"));
          console.error("add task error", error);
        });
    }
  },
  addProgress({ commit }, progress) {
    return new Promise((resolve) => {
      commit("SET_PROGRESS", progress);
      resolve("update progress");
    });
  },
  removeProgress({ commit }, sessionId) {
    return new Promise((resolve) => {
      commit("REMOVE_PROGRESS", sessionId);
      resolve("remove success");
    });
  },
  cancelProgress({ commit }, cancel) {
    return new Promise((resolve) => {
      commit("CANCEL_PROGRESS", cancel);
      resolve("cancel success");
    });
  },
};

export default {
  namespaced: true,
  state,
  mutations,
  actions,
};
