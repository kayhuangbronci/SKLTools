const getters = {
  token: (state) => state.user.token,
  info: (state) => state.user.info,
  routes: (state) => state.permission.routes,
  progress: (state) => state.upload.progress, // upload progress bar
  cancelProgress: (state) => state.upload.cancel,
};

export default getters;
