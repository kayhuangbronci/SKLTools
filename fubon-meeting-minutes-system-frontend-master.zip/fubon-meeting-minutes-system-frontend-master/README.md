# fubon-frontend-v2

file resources
image [link](https://drive.google.com/drive/u/2/folders/1ieHENSI6CpMlpkaGBGMMaYgRPONWKd7f)
layout [link](https://drive.google.com/drive/u/2/folders/1JB2mCFKQ7_pwnRKOoJRG0oRNH0R9jtzA)

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
